import os
from enum import IntEnum
from functools import partial
from typing import Optional, Tuple
import chex
import jax
import jax.lax
import jax.numpy as jnp
import numpy as np
from jax.flatten_util import ravel_pytree
from flax import struct

import jaxtari.spaces as spaces

from jaxtari.environment import JaxtariAction as Action, JaxEnvironment, ObjectObservation
from jaxtari.renderers import JAXGameRenderer
from jaxtari.rendering import jax_rendering_utils as render_utils


def _counter_array(value):
    counter_dtype = jnp.int64 if jax.config.jax_enable_x64 else jnp.int32
    return jnp.asarray(value, dtype=counter_dtype)


def _build_blue_line_table(rows, indices):
    rows_arr = jnp.array(rows, dtype=jnp.int32)
    idx_arr = jnp.array(indices, dtype=jnp.int32)
    return rows_arr[idx_arr]

_BLUE_LINE_INIT_ROWS = (
    (45, 54, 64, 78, 98, 132, -1),
    (44, 52, 62, 76, 98, 132, -1),
    (44, 52, 62, 76, 96, 130, -1),
    (44, 52, 62, 76, 96, 128, -1),
    (44, 52, 62, 76, 94, 128, -1),
    (44, 52, 62, 74, 94, 126, -1),
    (44, 52, 62, 74, 94, 124, -1),
    (44, 50, 60, 74, 92, 122, -1),
    (44, 50, 60, 72, 92, 120, -1),
    (44, 50, 60, 72, 90, 118, -1),
    (44, 50, 58, 72, 90, 118, -1),
    (44, 50, 58, 70, 88, 116, -1),
    (44, 50, 58, 70, 86, 114, 160),
    (44, 48, 58, 68, 86, 110, 156),
    (44, 48, 56, 68, 84, 108, 152),
    (44, 48, 56, 66, 82, 106, 148),
    (45, 56, 66, 82, 104, 144, -1),
    (45, 54, 64, 80, 102, 138, -1),
    (45, 54, 64, 78, 100, 136, -1),
    (44, 52, 60, 74, 92, 124, -1),
    (44, 50, 60, 72, 90, 120, -1),
    (44, 48, 58, 70, 86, 112, 158),
    (44, 48, 56, 68, 84, 108, 150),
    (44, 48, 56, 66, 82, 106, 146),
    (44, 48, 56, 68, 82, 108, 148),
    (45, 54, 66, 80, 104, 142, -1),
    (45, 54, 64, 78, 98, 134, -1),
    (45, 54, 64, 78, 100, 138, -1),
)

_BLUE_LINE_INIT_IDX = (
    0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
    3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10,
    11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 18,
    1, 1, 4, 4, 19, 19, 20, 20, 11, 11, 21, 21, 22, 22, 23, 23,
    17, 17, 0, 0, 4, 4, 7, 7, 11, 11, 21, 21, 24, 24, 25, 25,
    26, 26, 4, 4, 8, 8, 11, 11, 14, 14, 16, 16, 26, 26, 4, 4,
    20, 20, 12, 12, 24, 24, 17, 17, 3, 3, 8, 8, 12, 12, 24, 24,
    27, 27, 4, 4, 9, 9, 13, 13, 25, 25, 1, 1, 8, 8, 12, 12,
    23, 23, 0, 0, 23, 23, 12, 12, 8, 8, 1, 1, 25, 25, 13, 13,
    9, 9, 4, 4, 27, 27, 24, 24, 12, 12, 8, 8, 3, 3, 17, 17,
    24, 24, 12, 12, 20, 20, 4, 4, 26, 26, 16, 16, 14, 14, 11, 11,
    8, 8, 4, 4, 26, 26, 25, 25, 24, 24, 21, 21, 11, 11, 7, 7,
    4, 4, 0, 0, 17, 17, 23, 23, 22, 22, 21, 21, 11, 11, 20, 20,
    19, 19, 4, 4, 1, 1, 18, 18, 17, 17, 16, 16, 15, 15, 14, 14,
    13, 13, 12, 12, 11, 11, 10, 10, 9, 9, 8, 8, 7, 7, 6, 6,
)

_BLUE_LINE_LOOP_ROWS = (
    (44, 52, 62, 74, 94, 126, -1),
    (44, 52, 62, 76, 94, 128, -1),
    (44, 52, 62, 76, 96, 128, -1),
    (44, 52, 62, 76, 96, 130, -1),
    (44, 52, 62, 76, 98, 132, -1),
    (45, 54, 64, 78, 98, 132, -1),
    (45, 54, 64, 78, 98, 134, -1),
    (45, 54, 64, 78, 100, 138, -1),
    (45, 54, 64, 80, 102, 138, -1),
    (45, 54, 66, 80, 102, 140, -1),
    (45, 54, 66, 80, 104, 142, -1),
    (44, 48, 56, 66, 82, 106, 146),
    (44, 48, 56, 66, 82, 106, 148),
    (44, 48, 56, 68, 82, 108, 148),
    (44, 48, 56, 68, 84, 108, 150),
    (44, 48, 56, 68, 84, 110, 154),
    (44, 48, 58, 68, 86, 110, 156),
    (44, 48, 58, 70, 86, 112, 158),
    (44, 50, 58, 70, 86, 114, 160),
    (44, 50, 58, 70, 88, 114, 162),
    (44, 50, 58, 70, 88, 116, -1),
    (44, 50, 58, 72, 90, 118, -1),
    (44, 50, 60, 72, 90, 120, -1),
    (44, 50, 60, 72, 92, 120, -1),
    (44, 50, 60, 74, 92, 122, -1),
    (44, 52, 60, 74, 92, 124, -1),
    (45, 54, 64, 78, 100, 136, -1),
    (45, 56, 66, 82, 104, 144, -1),
    (44, 48, 56, 68, 84, 108, 152),
    (44, 50, 60, 72, 90, 118, -1),
    (44, 52, 62, 74, 94, 124, -1),
)

_BLUE_LINE_LOOP_IDX = (
    0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7,
    8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15,
    16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 20, 20, 21, 21, 22, 22,
    23, 23, 24, 24, 25, 25, 0, 0, 1, 1, 2, 2, 3, 3, 5, 5,
    6, 6, 26, 26, 7, 7, 8, 8, 9, 9, 10, 10, 27, 27, 12, 12,
    13, 13, 14, 14, 28, 28, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20,
    21, 21, 29, 29, 22, 22, 23, 23, 24, 24, 25, 25, 30, 30, 1, 1,
    2, 2, 3, 3, 4, 4, 6, 6, 26, 26, 7, 7, 8, 8, 10, 10,
    27, 27, 11, 11, 12, 12, 13, 13, 14, 14, 28, 28, 15, 15, 17, 17,
    18, 18, 19, 19, 20, 20, 21, 21, 29, 29, 22, 22, 23, 23, 25, 25,
    30, 30, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 26, 26,
    7, 7, 8, 8, 9, 9, 27, 27, 11, 11, 12, 12, 13, 13, 28, 28,
    15, 15, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 20, 20, 29, 29,
    22, 22, 23, 23, 24, 24, 30, 30, 0, 0, 1, 1, 2, 2, 4, 4,
    5, 5, 6, 6, 26, 26, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11,
    12, 12, 13, 13, 14, 14, 15, 15, 16, 16, 17, 17, 18, 18, 20, 20,
)

BLUE_LINE_INIT_TABLE = _build_blue_line_table(_BLUE_LINE_INIT_ROWS, _BLUE_LINE_INIT_IDX)
BLUE_LINE_LOOP_TABLE = _build_blue_line_table(_BLUE_LINE_LOOP_ROWS, _BLUE_LINE_LOOP_IDX)

# Threshold arrays for index calculation
UFO_THRESHOLDS = jnp.array([0, 48, 57, 62, 69, 86, 121])
REJUVENATOR_THRESHOLDS = jnp.array([0, 65, 86, 112])
FALLING_ROCK_THRESHOLDS = jnp.array([43, 65, 86, 112])
LANE_BLOCKER_THRESHOLDS = jnp.array([43, 64, 84, 111])
KAMIKAZE_THRESHOLDS = jnp.array([43, 65, 72, 95])
UFO_ALIGNMENT_THRESHOLDS = jnp.array([0, 48, 57, 69, 121])
BULLET_THRESHOLDS = jnp.array([56, 79])

# lookup table for speedup
_Y_COORDS = jnp.arange(805)
_UFO_INDEX_TABLE = jnp.searchsorted(UFO_THRESHOLDS, _Y_COORDS, side='right')
_REJUVENATOR_INDEX_TABLE = jnp.searchsorted(REJUVENATOR_THRESHOLDS, _Y_COORDS, side='right')
_FALLING_ROCK_INDEX_TABLE = jnp.searchsorted(FALLING_ROCK_THRESHOLDS, _Y_COORDS, side='right')
_LANE_BLOCKER_INDEX_TABLE = jnp.searchsorted(LANE_BLOCKER_THRESHOLDS, _Y_COORDS, side='right')
_KAMIKAZE_INDEX_TABLE = jnp.searchsorted(KAMIKAZE_THRESHOLDS, _Y_COORDS, side='right')
_UFO_ALIGNMENT_TABLE = 4 - jnp.searchsorted(UFO_ALIGNMENT_THRESHOLDS, _Y_COORDS, side='right')
_BULLET_INDEX_TABLE = jnp.searchsorted(BULLET_THRESHOLDS, _Y_COORDS, side='right')

PROJECTILE_STEP_FRAMES = 2
PROJECTILE_Y_TABLE_LASER = jnp.array(
    [155, 141, 129, 118, 109, 102, 95, 89, 84, 79, 75, 71, 67, 64],
    dtype=jnp.float32,
)
PROJECTILE_Y_TABLE_TORPEDO = jnp.array(
    [155, 141, 129, 118, 109, 102, 95, 89, 84, 79, 75, 71, 67, 64, 61, 58, 56, 53, 51, 49],
    dtype=jnp.float32,
)
LASER_PROJECTILE_FRAMES = PROJECTILE_Y_TABLE_LASER.shape[0] * PROJECTILE_STEP_FRAMES
TORPEDO_PROJECTILE_FRAMES = PROJECTILE_Y_TABLE_TORPEDO.shape[0] * PROJECTILE_STEP_FRAMES


class WhiteUFOPattern(IntEnum):
    """Behavioral patterns used by the white UFO enemies."""

    IDLE = 0
    DROP_STRAIGHT = 1
    DROP_RIGHT = 2
    DROP_LEFT = 3
    RETREAT = 4
    SHOOT = 5
    MOVE_BACK = 6
    KAMIKAZE = 7
    TRIPLE_SHOT_RIGHT = 8
    TRIPLE_SHOT_LEFT = 9


class BouncerState(IntEnum):
    SWITCHING = 0  # Also used for entry
    DOWN = 1
    UP = 2


class LaneBlockerState(IntEnum):
    DESCEND = 0
    HOLD = 1
    SINK = 2
    RETREAT = 3


class StandbyPhase(IntEnum):
    NONE = 0
    DECEL = 1
    WAIT = 2
    SECTOR_DONE = 3


@struct.dataclass
class BeamriderConstants(struct.PyTreeNode):
    STARTING_SECTOR: int = struct.field(pytree_node=False, default=1)
    STARTING_LIVES: int = struct.field(pytree_node=False, default=3)
    MAX_LIVES: int = struct.field(pytree_node=False, default=14)
    WHITE_UFOS_PER_SECTOR: int = struct.field(pytree_node=False, default=15)

    RENDER_SCALE_FACTOR: int = struct.field(pytree_node=False, default=4)
    SCREEN_WIDTH: int = struct.field(pytree_node=False, default=160)
    SCREEN_HEIGHT: int = struct.field(pytree_node=False, default=210)
    PLAYER_COLOR: Tuple[int, int, int] = struct.field(pytree_node=False, default=(223, 183, 85))
    LEFT_CLIP_PLAYER: int = struct.field(pytree_node=False, default=27)
    RIGHT_CLIP_PLAYER: int = struct.field(pytree_node=False, default=142)
    BOTTOM_OF_LANES: Tuple[int, int, int, int, int] = struct.field(pytree_node=False, default=(27, 52, 77, 102, 127))
    TOP_OF_LANES: Tuple[int, int, int, int, int] = struct.field(pytree_node=False, default=(38, 61, 71, 81, 91, 102, 123))  #lane 0,6 are connected to points in middle of the map, not to bottom lane points

    TOP_TO_BOTTOM_LANE_VECTORS: Tuple[
        Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[
            float, float], Tuple[float, float]] = struct.field(pytree_node=False,
                                                               default=((-2, 4), (-1, 4), (-0.52, 4), (0, 4), (0.52, 4),
                                                                        (1, 4), (2, 4)))

    MAX_LASER_Y: int = struct.field(pytree_node=False, default=64)
    MIN_BULLET_Y: int = struct.field(pytree_node=False, default=155)
    MAX_TORPEDO_Y: int = struct.field(pytree_node=False, default=49)
    MAX_TORPEDO_Y_MOTHERSHIP_SCENE: int = struct.field(pytree_node=False, default=45)
    BOTTOM_TO_TOP_LANE_VECTORS: Tuple[
        Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[float, float], Tuple[
            float, float]] = struct.field(pytree_node=False, default=((-1, 4), (-0.52, 4), (0, 4), (0.52, 4), (1, 4)))
    PLAYER_POS_Y: int = struct.field(pytree_node=False, default=164)
    PLAYER_SPEED: float = struct.field(pytree_node=False, default=2.5)
    # ALE immediately re-arms after a clean despawn at the horizon.
    # Impacts add an 8-frame recovery window before a new launch can be queued.
    PLAYER_SHOT_RECOVERY: int = struct.field(pytree_node=False, default=8)
    # After gameplay starts, ALE spawns the projectile on the next frame.
    PLAYER_SHOT_LAUNCH_DELAY: int = struct.field(pytree_node=False, default=1)

    BOTTOM_CLIP: int = struct.field(pytree_node=False, default=164)
    TOP_CLIP: int = struct.field(pytree_node=False, default=43)
    LASER_ID: int = struct.field(pytree_node=False, default=1)
    TORPEDO_ID: int = struct.field(pytree_node=False, default=2)
    BULLET_OFFSCREEN_POS: Tuple[float, float] = struct.field(pytree_node=False, default=(800.0, 800.0))
    ENEMY_OFFSCREEN_POS: Tuple[int, int] = struct.field(pytree_node=False, default=(-100, -100))
    MIN_BLUE_LINE_POS: int = struct.field(pytree_node=False, default=46)
    MAX_BLUE_LINE_POS: int = struct.field(pytree_node=False, default=160)
    WHITE_UFO_RETREAT_DURATION: int = struct.field(pytree_node=False, default=28)
    # Don't peel at all until roughly mid-upper board.
    WHITE_UFO_RETREAT_MIN_Y: float = struct.field(pytree_node=False, default=95.0)
    # Fire peels: available from upper-mid board, common by mid-range.
    WHITE_UFO_FIRE_MIN_Y: float = struct.field(pytree_node=False, default=95.0)
    WHITE_UFO_FIRE_FULL_Y: float = struct.field(pytree_node=False, default=125.0)
    # Unreachable beams 0/6 are approach-only.
    # Shoot-path merge: cut onto 1/5 around here (mid diagonal).
    WHITE_UFO_EDGE_MERGE_Y: float = struct.field(pytree_node=False, default=98.0)
    # Collision/overshoot merge: deeper than shoot-path for a steeper angle, but still
    # on-screen (lane 0/6 geometry leaves the playfield if this is much past ~120).
    WHITE_UFO_EDGE_COLLISION_MERGE_Y: float = struct.field(pytree_node=False, default=118.0)
    # Enemy fire unlocks after ~2 kills (15→13 left). Matches ALE sector-1 play log.
    WHITE_UFO_SHOOT_UNLOCK_LEFT: int = struct.field(pytree_node=False, default=13)
    # Fraction of finished deep dives that commit to a full flythrough past the player (~1/6).
    # Flythroughs happen on reachable beams (1/5), often with a shot, not on 0/6.
    WHITE_UFO_FLYTHROUGH_P: float = struct.field(pytree_node=False, default=0.17)
    # Late-sector edge play: approaches via 0/6 then merge to 1/5 (not the whole sector).
    WHITE_UFO_OUTER_EDGE_UNLOCK_LEFT: int = struct.field(pytree_node=False, default=10)
    # Lane-switch (DROP_L/R) boost while remaining ≤ this (OC: especially lively near ~10).
    WHITE_UFO_LANE_SWITCH_LEFT_MAX: int = struct.field(pytree_node=False, default=13)

    ####PATTERNS (matches pattern_choices order): DROP_STRAIGHT, DROP_LEFT, DROP_RIGHT, SHOOT, MOVE_BACK, KAMIKAZE, TRIPLE_SHOT_RIGHT, TRIPLE_SHOT_LEFT
    WHITE_UFO_PATTERN_DURATIONS: Tuple[int, ...] = struct.field(pytree_node=False,
                                                                # DROP_L/R: short enough to settle one adjacent beam, not roam.
                                                                # SHOOT holds briefly at fire altitude, then always peels into RETREAT.
                                                                default=(0, 80, 55, 55, 28, 10, 42, 100, 123, 123))
    WHITE_UFO_PATTERN_PROBS: Tuple[float, ...] = struct.field(pytree_node=False,
                                                              # Mostly straight drops; occasional 1-lane (maybe 2) switches.
                                                              default=(0.34, 0.08, 0.08, 0.26, 0.06, 0.10, 0.15, 0.15)) #these probas are not 1:1, as some patterns have activation conditions
    WHITE_UFO_SPEED_FACTOR: float = struct.field(pytree_node=False, default=0.1)
    WHITE_UFO_SHOT_SPEED_FACTOR: float = struct.field(pytree_node=False, default=0.8)
    # Faster retreat heat so peels happen across a range of depths (variable fire Y).
    WHITE_UFO_RETREAT_P_MIN: float = struct.field(pytree_node=False, default=0.03)
    WHITE_UFO_RETREAT_P_MAX: float = struct.field(pytree_node=False, default=0.45)
    WHITE_UFO_RETREAT_ALPHA: float = struct.field(pytree_node=False, default=0.01)
    WHITE_UFO_RETREAT_SPEED_MULT: float = struct.field(pytree_node=False, default=2.5)
    WHITE_UFO_TOP_LANE_MIN_SPEED: float = struct.field(pytree_node=False, default=0.55)
    WHITE_UFO_TOP_LANE_TURN_SPEED: float = struct.field(pytree_node=False, default=0.7)
    WHITE_UFO_ATTACK_P_MIN: float = struct.field(pytree_node=False, default=0.0004)
    WHITE_UFO_ATTACK_P_MAX: float = struct.field(pytree_node=False, default=0.8)
    WHITE_UFO_ATTACK_ALPHA: float = struct.field(pytree_node=False, default=0.0002)
    ENEMY_EXPLOSION_FRAMES: int = struct.field(pytree_node=False, default=21)
    KAMIKAZE_Y_THRESHOLD: float = struct.field(pytree_node=False, default=86.0)
    ENEMY_HITBOX_TOP_EXTENSION: int = struct.field(pytree_node=False, default=5)

    # Bouncer constants
    BOUNCER_SPAWN_HEIGHT: float = struct.field(pytree_node=False, default=75.0)
    BOUNCER_START_LEVEL: int = struct.field(pytree_node=False, default=8)
    BOUNCER_SPEED_PATTERN: Tuple[int, int, int, int] = struct.field(pytree_node=False, default=(0, 3, 0, 3))
    BOUNCER_SWITCH_SPEED_X: float = struct.field(pytree_node=False, default=1.2)
    BOUNCER_SWITCH_SPEED_Y: float = struct.field(pytree_node=False, default=1.0)

    # Mothership Explosion
    # Sequence: 1, 2, 1, 2, 3, 2, 3, 2, 3 (indices 0, 1, 0, 1, 2, 1, 2, 1, 2)
    # 8 frames per sprite step -> total 9 steps * 8 frames = 72 frames
    MOTHERSHIP_EXPLOSION_SEQUENCE: Tuple[int, ...] = struct.field(pytree_node=False,
                                                                  default=(0, 1, 0, 1, 2, 1, 2, 1, 2))
    MOTHERSHIP_EXPLOSION_STEP_DURATION: int = struct.field(pytree_node=False, default=8)
    MOTHERSHIP_HITBOX_SIZE: int = struct.field(pytree_node=False, default=16)

    # Sprite sizes (H, W)
    PLAYER_SPRITE_SIZE: Tuple[int, int] = struct.field(pytree_node=False, default=(16, 15))
    UFO_SPRITE_SIZES: Tuple[Tuple[int, int], ...] = struct.field(pytree_node=False, default=((1, 1), (2, 3), (2, 4), (2, 4), (4, 6), (4, 7), (6, 8)))
    BOUNCER_SPRITE_SIZE: Tuple[int, int] = struct.field(pytree_node=False, default=(7, 8))
    METEOROID_SPRITE_SIZE: Tuple[int, int] = struct.field(pytree_node=False, default=(7, 7))
    BULLET_SPRITE_SIZES: Tuple[Tuple[int, int], ...] = struct.field(pytree_node=False, default=((5, 8), (1, 1), (3, 3), (5, 5))) # Laser, Torpedo 3, 2, 1
    ENEMY_SHOT_SPRITE_SIZES: Tuple[Tuple[int, int], ...] = struct.field(pytree_node=False, default=((6, 2), (2, 4))) # Vertical, Horizontal
    REJUVENATOR_SPRITE_SIZES: Tuple[Tuple[int, int], ...] = struct.field(pytree_node=False, default=((2, 3), (4, 3), (5, 4), (7, 5), (7, 7))) # Stage 1-4, Dead
    FALLING_ROCK_SPRITE_SIZES: Tuple[Tuple[int, int], ...] = struct.field(pytree_node=False, default=((3, 4), (4, 5), (5, 6), (6, 8)))
    LANE_BLOCKER_SPRITE_SIZES: Tuple[Tuple[int, int], ...] = struct.field(pytree_node=False, default=((3, 3), (4, 5), (7, 8), (7, 8)))
    MOTHERSHIP_SPRITE_SIZE: Tuple[int, int] = struct.field(pytree_node=False, default=(7, 16))

    # Blue line constants
    BLUE_LINE_OFFSCREEN_Y: int = struct.field(pytree_node=False, default=500)

    CHASING_METEOROID_MAX: int = struct.field(pytree_node=False, default=6)
    CHASING_METEOROID_WAVE_MIN: int = struct.field(pytree_node=False, default=2)
    CHASING_METEOROID_WAVE_MAX: int = struct.field(pytree_node=False, default=5)
    CHASING_METEOROID_SPAWN_INTERVAL_MIN: int = struct.field(pytree_node=False, default=2)
    CHASING_METEOROID_SPAWN_INTERVAL_MAX: int = struct.field(pytree_node=False, default=40)
    CHASING_METEOROID_SPAWN_Y: float = struct.field(pytree_node=False, default=54.0)
    CHASING_METEOROID_LANE_SPEED: float = struct.field(pytree_node=False, default=0.9)
    CHASING_METEOROID_ACCEL: float = struct.field(pytree_node=False, default=0.040)
    CHASING_METEOROID_LANE_ALIGN_THRESHOLD: float = struct.field(pytree_node=False, default=1.5)
    CHASING_METEOROID_CYCLE_DX: Tuple[int, ...] = struct.field(pytree_node=False, default=(2, 0, 1, 0, 2, 0, 2, 0))
    CHASING_METEOROID_CYCLE_DY: Tuple[int, ...] = struct.field(pytree_node=False, default=(1, 0, 0, 0, 1, 0, 0, 0))
    MOTHERSHIP_OFFSCREEN_POS: int = struct.field(pytree_node=False, default=500)
    MOTHERSHIP_ANIM_X: Tuple[int, int, int, int, int, int, int] = struct.field(pytree_node=False,
                                                                               default=(9, 9, 10, 10, 11, 12, 12))
    MOTHERSHIP_HEIGHT: int = struct.field(pytree_node=False, default=7)
    MOTHERSHIP_EMERGE_Y: int = struct.field(pytree_node=False, default=44)

    REJUVENATOR_SPAWN_PROB: float = struct.field(pytree_node=False, default=1 / 2500)
    REJUVENATOR_STAGE_2_Y: float = struct.field(pytree_node=False, default=62.0)
    REJUVENATOR_STAGE_3_Y: float = struct.field(pytree_node=False, default=93.0)
    REJUVENATOR_STAGE_4_Y: float = struct.field(pytree_node=False, default=112.0)
    DEATH_DURATION: int = struct.field(pytree_node=False, default=120)

    # Falling Rock constants
    FALLING_ROCK_MAX: int = struct.field(pytree_node=False, default=3)
    FALLING_ROCK_SPAWN_PROB: float = struct.field(pytree_node=False, default=0.002)
    FALLING_ROCK_SPAWN_Y: float = struct.field(pytree_node=False, default=43.0)
    FALLING_ROCK_BOTTOM_CLIP: float = struct.field(pytree_node=False, default=164.0)
    FALLING_ROCK_INIT_VEL: float = struct.field(pytree_node=False, default=0.07)
    FALLING_ROCK_ACCEL: float = struct.field(pytree_node=False, default=0.017)

    # Lane blocker constants
    LANE_BLOCKER_MAX: int = struct.field(pytree_node=False, default=1)
    LANE_BLOCKER_START_LEVEL: int = struct.field(pytree_node=False, default=10)
    LANE_BLOCKER_SPAWN_PROB: float = struct.field(pytree_node=False, default=1 / 1800)
    LANE_BLOCKER_SPAWN_Y: float = struct.field(pytree_node=False, default=43.0)
    LANE_BLOCKER_BOTTOM_Y: float = struct.field(pytree_node=False, default=155.0)
    LANE_BLOCKER_SPAWN_LANES: Tuple[int, int, int] = struct.field(pytree_node=False, default=(2, 3, 4))
    LANE_BLOCKER_HOLD_FRAMES: int = struct.field(pytree_node=False, default=122)
    LANE_BLOCKER_INIT_VEL: float = struct.field(pytree_node=False, default=0.02)
    LANE_BLOCKER_SINK_INTERVAL: int = struct.field(pytree_node=False, default=2)
    LANE_BLOCKER_WIDTH: int = struct.field(pytree_node=False, default=8)
    LANE_BLOCKER_HEIGHT: int = struct.field(pytree_node=False, default=7)
    LANE_BLOCKER_RETREAT_SPEED_MULT: float = struct.field(pytree_node=False, default=2.5)

    # Standby Mode
    STANDBY_DECEL_DURATION: int = struct.field(pytree_node=False, default=120)
    STANDBY_SECTOR_DONE_DURATION: int = struct.field(pytree_node=False, default=124)
    STANDBY_BLINK_DURATION: int = struct.field(pytree_node=False, default=16)

    # Kamikaze constants
    KAMIKAZE_MAX: int = struct.field(pytree_node=False, default=1)
    KAMIKAZE_SPAWN_INTERVAL: int = struct.field(pytree_node=False, default=250)
    KAMIKAZE_START_SECTOR: int = struct.field(pytree_node=False, default=12)
    KAMIKAZE_START_Y: float = struct.field(pytree_node=False, default=43.0)
    KAMIKAZE_TRACK_Y: float = struct.field(pytree_node=False, default=60.0)
    KAMIKAZE_SPRITE_Y_THRESHOLDS: Tuple[float, float, float, float] = struct.field(pytree_node=False,
                                                                                   default=(43.0, 65.0, 72.0, 95.0))
    # Coin constants
    COIN_MAX: int = struct.field(pytree_node=False, default=3)
    COIN_SPAWN_PROB: float = struct.field(pytree_node=False, default=1 / 1500)
    COIN_SPAWN_Y: float = struct.field(pytree_node=False, default=55.0)
    COIN_EXIT_Y: float = struct.field(pytree_node=False, default=95.0)
    COIN_SPAWN_X_LEFT: float = struct.field(pytree_node=False, default=5.0)
    COIN_SPAWN_X_RIGHT: float = struct.field(pytree_node=False, default=155.0)
    COIN_SPEED_Y: float = struct.field(pytree_node=False, default=0.5)
    COIN_SPEED_X: float = struct.field(pytree_node=False, default=1.9375)
    COIN_ANIM_SEQ: Tuple[int, ...] = struct.field(pytree_node=False, default=(3, 2, 1, 0, 1, 2))
    COIN_SPRITE_SIZE: Tuple[int, int] = struct.field(pytree_node=False, default=(7, 8))


def _get_index_ufo(pos: chex.Array) -> chex.Array:
    return _UFO_INDEX_TABLE[jnp.clip(pos.astype(jnp.int32), 0, 800)]

def _get_index_rejuvenator(pos: chex.Array) -> chex.Array:
    return _REJUVENATOR_INDEX_TABLE[jnp.clip(pos.astype(jnp.int32), 0, 800)]

def _get_index_falling_rock(pos: chex.Array) -> chex.Array:
    return _FALLING_ROCK_INDEX_TABLE[jnp.clip(pos.astype(jnp.int32), 0, 800)]

def _get_index_lane_blocker(pos: chex.Array) -> chex.Array:
    return _LANE_BLOCKER_INDEX_TABLE[jnp.clip(pos.astype(jnp.int32), 0, 800)]

def _get_index_kamikaze(pos: chex.Array) -> chex.Array:
    return _KAMIKAZE_INDEX_TABLE[jnp.clip(pos.astype(jnp.int32), 0, 800)]

def _get_ufo_alignment(pos: chex.Array) -> chex.Array:
    return _UFO_ALIGNMENT_TABLE[jnp.clip(pos.astype(jnp.int32), 0, 800)]

def _get_index_bullet(pos: chex.Array, bullet_type: chex.Array, laser_id: int) -> chex.Array:
    is_laser = bullet_type == laser_id
    torpedo_idx = 1 + _BULLET_INDEX_TABLE[jnp.clip(pos.astype(jnp.int32), 0, 800)]
    return jnp.where(is_laser, 0, torpedo_idx)

def _get_bullet_alignment(pos: chex.Array, bullet_type: chex.Array, laser_id: int) -> chex.Array:
    is_laser = bullet_type == laser_id
    torpedo_offset = 4 - _BULLET_INDEX_TABLE[jnp.clip(pos.astype(jnp.int32), 0, 800)]
    return jnp.where(is_laser, 0, torpedo_offset)


def _get_player_shot_screen_x(
    player_shot_pos: chex.Array,
    player_shot_vel: chex.Array,
    bullet_type: chex.Array,
    laser_id: int,
) -> chex.Array:
    # Match ALE lane rounding: left lanes (vx < 0) ceil, right lanes (vx > 0) floor.
    shot_dir = jnp.sign(player_shot_vel[0])
    shot_x_base = player_shot_pos[0]
    conds = [shot_dir < 0, shot_dir > 0]
    choices = [jnp.ceil(shot_x_base), jnp.floor(shot_x_base)]
    shot_x_rounded = jnp.select(conds, choices, default=jnp.round(shot_x_base))
    return shot_x_rounded + _get_bullet_alignment(player_shot_pos[1], bullet_type, laser_id)


def _get_player_screen_x(player_pos: chex.Array) -> chex.Array:
    conds = [player_pos == 27.0, player_pos == 52.0, player_pos == 127.0]
    choices = [26.0, 51.0, 128.0]
    return jnp.select(conds, choices, default=player_pos)

@struct.dataclass
class LevelState(struct.PyTreeNode):
    player_pos: chex.Array
    player_vel: chex.Array
    white_ufo_left: chex.Array
    mothership_position: chex.Array
    mothership_timer: chex.Array
    mothership_stage: chex.Array
    player_shot_pos: chex.Array
    player_shot_vel: chex.Array
    player_shot_frame: chex.Array
    torpedoes_left: chex.Array
    shooting_cooldown: chex.Array
    shooting_delay: chex.Array
    bullet_type: chex.Array
    shot_type_pending: chex.Array

    # enemies
    enemy_type: chex.Array
    white_ufo_pos: chex.Array
    white_ufo_vel: chex.Array
    enemy_shot_pos: chex.Array  # (2, 9) - 3 shots per ufo
    enemy_shot_vel: chex.Array  # (9,) - lane index
    enemy_shot_timer: chex.Array # (9,)
    enemy_shot_explosion_frame: chex.Array # (9,)
    enemy_shot_explosion_pos: chex.Array   # (2, 9)
    white_ufo_time_on_lane: chex.Array
    white_ufo_attack_time: chex.Array
    white_ufo_already_left: chex.Array
    white_ufo_spawn_delay: chex.Array
    white_ufo_pattern_id: chex.Array
    white_ufo_pattern_timer: chex.Array
    white_ufo_rngs: chex.Array
    ufo_explosion_frame: chex.Array
    ufo_explosion_pos: chex.Array
    chasing_meteoroid_explosion_frame: chex.Array
    chasing_meteoroid_explosion_pos: chex.Array
    chasing_meteoroid_pos: chex.Array
    chasing_meteoroid_active: chex.Array
    chasing_meteoroid_vel_y: chex.Array
    chasing_meteoroid_phase: chex.Array
    chasing_meteoroid_frame: chex.Array
    chasing_meteoroid_lane: chex.Array
    chasing_meteoroid_side: chex.Array
    chasing_meteoroid_spawn_timer: chex.Array
    chasing_meteoroid_remaining: chex.Array
    chasing_meteoroid_wave_active: chex.Array

    rejuvenator_pos: chex.Array
    rejuvenator_active: chex.Array
    rejuvenator_dead: chex.Array
    rejuvenator_frame: chex.Array
    rejuvenator_lane: chex.Array
    rejuvenator_explosion_frame: chex.Array
    rejuvenator_explosion_pos: chex.Array

    falling_rock_pos: chex.Array
    falling_rock_active: chex.Array
    falling_rock_vel_y: chex.Array
    falling_rock_lane: chex.Array
    falling_rock_explosion_frame: chex.Array
    falling_rock_explosion_pos: chex.Array

    lane_blocker_pos: chex.Array
    lane_blocker_active: chex.Array
    lane_blocker_vel_y: chex.Array
    lane_blocker_lane: chex.Array
    lane_blocker_phase: chex.Array
    lane_blocker_timer: chex.Array
    lane_blocker_explosion_frame: chex.Array
    lane_blocker_explosion_pos: chex.Array

    line_positions: chex.Array
    blue_line_counter: chex.Array

    death_timer: chex.Array

    # Bouncer dedicated fields
    bouncer_pos: chex.Array
    bouncer_vel: chex.Array
    bouncer_state: chex.Array
    bouncer_timer: chex.Array
    bouncer_active: chex.Array
    bouncer_lane: chex.Array
    bouncer_step_index: chex.Array
    bouncer_explosion_frame: chex.Array
    bouncer_explosion_pos: chex.Array

    standby_phase: chex.Array
    standby_timer: chex.Array
    standby_accumulator: chex.Array

    coin_pos: chex.Array
    coin_active: chex.Array
    coin_timer: chex.Array
    coin_side: chex.Array
    coin_explosion_frame: chex.Array
    coin_explosion_pos: chex.Array
    coin_spawn_count: chex.Array

    kamikaze_pos: chex.Array
    kamikaze_active: chex.Array
    kamikaze_lane: chex.Array
    kamikaze_vel_y: chex.Array
    kamikaze_tracking: chex.Array
    kamikaze_spawn_timer: chex.Array
    kamikaze_explosion_frame: chex.Array
    kamikaze_explosion_pos: chex.Array

    background_flash_timer: chex.Array

@struct.dataclass
class BeamriderState(struct.PyTreeNode):
    level: LevelState
    score: chex.Array
    sector: chex.Array
    level_finished: chex.Array
    reset_coords: chex.Array
    lives: chex.Array
    steps: chex.Array
    ufo_killed: chex.Array
    rng: chex.Array

@struct.dataclass
class BeamriderInfo(struct.PyTreeNode):
    score: chex.Array
    sector: chex.Array

@struct.dataclass
class BeamriderObservation(struct.PyTreeNode):
    player: ObjectObservation
    player_shots: ObjectObservation
    white_ufo: ObjectObservation
    enemy_shots: ObjectObservation
    chasing_meteoroids: ObjectObservation
    falling_rocks: ObjectObservation
    lane_blockers: ObjectObservation
    coins: ObjectObservation
    kamikaze: ObjectObservation
    rejuvenator: ObjectObservation
    bouncer: ObjectObservation
    mothership: ObjectObservation
    shooting_cd: chex.Array
    torpedoes_left: chex.Array
    white_ufo_left: chex.Array
    lives: chex.Array
    score: chex.Array
    sector: chex.Array
    shooting_delay: chex.Array
    bullet_type: chex.Array
    shot_type_pending: chex.Array
    standby_phase: chex.Array
    death_timer: chex.Array
    white_ufo_pattern_id: chex.Array
    white_ufo_pattern_timer: chex.Array
    mothership_timer: chex.Array
    mothership_stage: chex.Array
    rejuvenator_dead: chex.Array

@struct.dataclass
class WhiteUFOUpdate:
    """Aggregated quantities needed after updating all white UFOs."""
    pos: chex.Array
    vel: chex.Array
    time_on_lane: chex.Array
    attack_time: chex.Array
    already_left: chex.Array
    spawn_delay: chex.Array
    pattern_id: chex.Array
    pattern_timer: chex.Array
    rngs: chex.Array


class JaxBeamrider(JaxEnvironment[BeamriderState, BeamriderObservation, BeamriderInfo, BeamriderConstants]):
    def __init__(self, consts: Optional[BeamriderConstants] = None):
        super().__init__(consts)
        self.consts = consts or BeamriderConstants()
        self.key = jax.random.PRNGKey(42067)
        self.renderer = BeamriderRenderer(self.consts)

        self.action_set = [
            Action.NOOP,
            Action.FIRE,
            Action.UP,
            Action.RIGHT,
            Action.LEFT,
            Action.DOWN,
            Action.UPRIGHT,
            Action.UPLEFT,
            Action.DOWNRIGHT,
            Action.DOWNLEFT,
            Action.UPFIRE,
            Action.RIGHTFIRE,
            Action.LEFTFIRE,
            Action.DOWNFIRE,
            Action.UPRIGHTFIRE,
            Action.UPLEFTFIRE,
            Action.DOWNRIGHTFIRE,
            Action.DOWNLEFTFIRE,
        ]
        self._action_set_jnp = jnp.array(self.action_set, dtype=jnp.int32)

        # Pre-calculate static lane and physics data
        self.bottom_lanes = jnp.array(self.consts.BOTTOM_OF_LANES, dtype=jnp.float32)
        self.top_lanes_x = jnp.array(self.consts.TOP_OF_LANES, dtype=jnp.float32)
        self.lane_vectors_t2b = jnp.array(self.consts.TOP_TO_BOTTOM_LANE_VECTORS, dtype=jnp.float32)
        self.lane_vectors_b2t = jnp.array(self.consts.BOTTOM_TO_TOP_LANE_VECTORS, dtype=jnp.float32)
        self.lane_dx_over_dy = self.lane_vectors_t2b[:, 0] / self.lane_vectors_t2b[:, 1]

        # Pre-calculate sprite and hitbox data
        self.bullet_sprite_sizes = jnp.array(self.consts.BULLET_SPRITE_SIZES, dtype=jnp.int32)
        self.ufo_sprite_sizes = jnp.array(self.consts.UFO_SPRITE_SIZES, dtype=jnp.int32)
        self.rejuvenator_sprite_sizes = jnp.array(self.consts.REJUVENATOR_SPRITE_SIZES, dtype=jnp.int32)
        self.falling_rock_sprite_sizes = jnp.array(self.consts.FALLING_ROCK_SPRITE_SIZES, dtype=jnp.int32)
        self.lane_blocker_sprite_sizes = jnp.array(self.consts.LANE_BLOCKER_SPRITE_SIZES, dtype=jnp.int32)
        self.bouncer_sprite_size = jnp.array(self.consts.BOUNCER_SPRITE_SIZE, dtype=jnp.int32)
        self.meteoroid_sprite_size = jnp.array(self.consts.METEOROID_SPRITE_SIZE, dtype=jnp.int32)

        # Pre-calculate patterns and sequences
        self.chasing_meteoroid_cycle_dx = jnp.array(self.consts.CHASING_METEOROID_CYCLE_DX, dtype=jnp.float32)
        self.chasing_meteoroid_cycle_dy = jnp.array(self.consts.CHASING_METEOROID_CYCLE_DY, dtype=jnp.float32)
        self.ufo_pattern_durations = jnp.array(self.consts.WHITE_UFO_PATTERN_DURATIONS, dtype=jnp.int32)
        self.ufo_pattern_probs = jnp.array(self.consts.WHITE_UFO_PATTERN_PROBS, dtype=jnp.float32)
        self._ufo_lane_offsets = jnp.array([0, 0, 1, -1, 0, 0, 0, 0, 1, -1], dtype=jnp.int32)
        self.bouncer_speed_pattern = jnp.array(self.consts.BOUNCER_SPEED_PATTERN, dtype=jnp.int32)
        self.mothership_anim_x = jnp.array(self.consts.MOTHERSHIP_ANIM_X, dtype=jnp.float32)
        self.coin_anim_seq = jnp.array(self.consts.COIN_ANIM_SEQ, dtype=jnp.int32)

        # Pre-calculate action masks and static arrays for JIT-friendly logic
        self._actions_up = jnp.array(
            [Action.UP, Action.UPRIGHT, Action.UPLEFT, Action.UPFIRE, Action.UPRIGHTFIRE, Action.UPLEFTFIRE],
            dtype=jnp.int32,
        )
        self._actions_fire = jnp.array(
            [
                Action.FIRE,
                Action.RIGHTFIRE,
                Action.LEFTFIRE,
                Action.DOWNFIRE,
                Action.UPFIRE,
                Action.UPRIGHTFIRE,
                Action.UPLEFTFIRE,
                Action.DOWNRIGHTFIRE,
                Action.DOWNLEFTFIRE,
            ],
            dtype=jnp.int32,
        )
        self._actions_left = jnp.array(
            [Action.LEFT, Action.UPLEFT, Action.DOWNLEFT, Action.LEFTFIRE, Action.UPLEFTFIRE, Action.DOWNLEFTFIRE],
            dtype=jnp.int32,
        )
        self._actions_right = jnp.array(
            [Action.RIGHT, Action.UPRIGHT, Action.DOWNRIGHT, Action.RIGHTFIRE, Action.UPRIGHTFIRE, Action.DOWNRIGHTFIRE],
            dtype=jnp.int32,
        )
        self._torpedo_actions = self._actions_up
        self._laser_actions = jnp.array(
            [
                Action.FIRE,
                Action.RIGHTFIRE,
                Action.LEFTFIRE,
                Action.DOWNFIRE,
                Action.DOWNRIGHTFIRE,
                Action.DOWNLEFTFIRE,
            ],
            dtype=jnp.int32,
        )

        self.player_sprite_size = jnp.array(self.consts.PLAYER_SPRITE_SIZE, dtype=jnp.int32)
        self.mothership_sprite_size = jnp.array(self.consts.MOTHERSHIP_SPRITE_SIZE, dtype=jnp.int32)
        self.enemy_shot_sprite_sizes = jnp.array(self.consts.ENEMY_SHOT_SPRITE_SIZES, dtype=jnp.int32)
        self.coin_sprite_size = jnp.array(self.consts.COIN_SPRITE_SIZE, dtype=jnp.int32)
        self.white_ufo_per_sector = jnp.array(self.consts.WHITE_UFOS_PER_SECTOR, dtype=jnp.int32)
        self.laser_id = jnp.array(self.consts.LASER_ID, dtype=jnp.int32)

        self.enemy_offscreen = jnp.array(self.consts.ENEMY_OFFSCREEN_POS, dtype=jnp.float32)
        self.enemy_offscreen_col = self.enemy_offscreen.reshape(2, 1)
        self.bullet_offscreen = jnp.array(self.consts.BULLET_OFFSCREEN_POS, dtype=jnp.float32)
        self.bullet_offscreen_col = self.bullet_offscreen.reshape(2, 1)
        self.mothership_offscreen = jnp.array(self.consts.MOTHERSHIP_OFFSCREEN_POS, dtype=jnp.float32)
        self.white_ufo_spawn_pos = jnp.array([[81.0, 81.0, 81.0], [43.0, 43.0, 43.0]], dtype=jnp.float32)
        self.white_ufo_spawn_vel = jnp.array([[-0.5, 0.0, 0.5], [0.0, 0.0, 0.0]], dtype=jnp.float32)
        self.white_ufo_respawn_pos = jnp.array([81.0, 43.0], dtype=jnp.float32)

        self.enemy_offscreen_ufo = jnp.tile(self.enemy_offscreen_col, (1, 3))
        self.bullet_offscreen_shots = jnp.tile(self.bullet_offscreen_col, (1, 9))
        self.enemy_offscreen_meteoroids = jnp.tile(self.enemy_offscreen_col, (1, self.consts.CHASING_METEOROID_MAX))
        self.enemy_offscreen_falling = jnp.tile(self.enemy_offscreen_col, (1, self.consts.FALLING_ROCK_MAX))
        self.enemy_offscreen_lane_blocker = jnp.tile(self.enemy_offscreen_col, (1, self.consts.LANE_BLOCKER_MAX))
        self.enemy_offscreen_coins = jnp.tile(self.enemy_offscreen_col, (1, self.consts.COIN_MAX))
        self.enemy_offscreen_shots = jnp.tile(self.enemy_offscreen_col, (1, 9))
        self.kamikaze_offscreen = self.enemy_offscreen_col
        self.middle_lane_spawn = jnp.array(self.consts.LANE_BLOCKER_SPAWN_LANES, dtype=jnp.int32)
        self._lane_motion_patterns = jnp.array([
            int(WhiteUFOPattern.DROP_STRAIGHT), int(WhiteUFOPattern.DROP_LEFT),
            int(WhiteUFOPattern.DROP_RIGHT), int(WhiteUFOPattern.RETREAT),
            int(WhiteUFOPattern.MOVE_BACK), int(WhiteUFOPattern.KAMIKAZE),
            int(WhiteUFOPattern.TRIPLE_SHOT_RIGHT), int(WhiteUFOPattern.TRIPLE_SHOT_LEFT),
        ], dtype=jnp.int32)
        # White UFOs are advanced with lax.scan (not vmap) so each slot can see
        # sibling lane claims and never dive onto an occupied beam.

        # Dynamically calculate actual observation size
        # Create a dummy LevelState to get the initial shapes of all fields
        dummy_level_state = self._create_level_state(key=jax.random.PRNGKey(0))
        dummy_state = BeamriderState(
            level=dummy_level_state,
            score=jnp.array(0),
            sector=jnp.array(1),
            level_finished=jnp.array(0),
            reset_coords=jnp.array(False),
            lives=jnp.array(self.consts.STARTING_LIVES, dtype=jnp.int32),
            steps=_counter_array(0),
            ufo_killed=jnp.array(False),
            rng=jax.random.PRNGKey(0),
        )
        dummy_obs = self._get_observation(dummy_state)
        flat_dummy_obs, _ = ravel_pytree(dummy_obs)
        self.obs_size = flat_dummy_obs.shape[0]

    @partial(jax.jit, static_argnums=(0,))
    def reset(self, key: Optional[chex.PRNGKey] = None) -> Tuple[BeamriderObservation, BeamriderState]:
        if key is None:
            key = self.key
        state = self.reset_level(self.consts.STARTING_SECTOR, key=key)
        observation = self._get_observation(state)
        return observation, state

    def _create_level_state(
        self,
        key: chex.Array,
        white_ufo_left=None,
        torpedoes_left=None,
        shooting_cooldown=None,
        shooting_delay=None,
        shot_type_pending=None,
        standby_phase=None,
        coin_spawn_count=None,
    ) -> LevelState:
        white_ufo_left = white_ufo_left if white_ufo_left is not None else self.white_ufo_per_sector
        torpedoes_left = torpedoes_left if torpedoes_left is not None else jnp.array(3)
        shooting_cooldown = shooting_cooldown if shooting_cooldown is not None else jnp.array(0)
        shooting_delay = shooting_delay if shooting_delay is not None else jnp.array(0)
        shot_type_pending = shot_type_pending if shot_type_pending is not None else self.laser_id
        standby_phase = standby_phase if standby_phase is not None else jnp.array(int(StandbyPhase.NONE), dtype=jnp.int32)
        coin_spawn_count = coin_spawn_count if coin_spawn_count is not None else jnp.array(0, dtype=jnp.int32)

        white_ufo_rngs = jax.random.split(key, 3)

        active_count = jnp.minimum(white_ufo_left.astype(jnp.int32), 3)
        active_mask = jnp.arange(3, dtype=jnp.int32) < active_count
        ufo_offscreen = self.enemy_offscreen_ufo
        initial_ufo_pos = self.white_ufo_spawn_pos

        enemy_shot_offscreen = self.bullet_offscreen_shots

        return LevelState(
            player_pos=jnp.array(77.0),
            player_vel=jnp.array(0.0),
            white_ufo_left=white_ufo_left,
            mothership_position=self.mothership_offscreen,
            mothership_timer=jnp.array(0, dtype=jnp.int32),
            mothership_stage=jnp.array(0, dtype=jnp.int32),
            player_shot_pos=self.bullet_offscreen,
            player_shot_vel=jnp.zeros((2,), dtype=jnp.float32),
            player_shot_frame=jnp.array(-1, dtype=jnp.int32),
            torpedoes_left=torpedoes_left,
            shooting_cooldown=shooting_cooldown,
            shooting_delay=shooting_delay,
            bullet_type=self.laser_id,
            shot_type_pending=shot_type_pending,
            enemy_type=jnp.array([0, 0, 0]),
            white_ufo_pos=jnp.where(active_mask[None, :], initial_ufo_pos, ufo_offscreen),
            white_ufo_vel=self.white_ufo_spawn_vel,
            enemy_shot_pos=enemy_shot_offscreen,
            enemy_shot_vel=jnp.zeros((9,), dtype=jnp.int32),
            enemy_shot_timer=jnp.zeros((9,), dtype=jnp.int32),
            enemy_shot_explosion_frame=jnp.zeros((9,), dtype=jnp.int32),
            enemy_shot_explosion_pos=jnp.tile(
                self.enemy_offscreen_col,
                (1, 9),
            ),
            white_ufo_time_on_lane=jnp.array([0, 0, 0]),
            white_ufo_attack_time=jnp.zeros((3,), dtype=jnp.int32),
            white_ufo_already_left=jnp.zeros((3,), dtype=jnp.bool_),
            white_ufo_spawn_delay=jnp.zeros((3,), dtype=jnp.int32),
            white_ufo_pattern_id=jnp.zeros(3, dtype=jnp.int32),
            white_ufo_pattern_timer=jnp.zeros(3, dtype=jnp.int32),
            white_ufo_rngs=white_ufo_rngs,
            ufo_explosion_frame=jnp.zeros((3,), dtype=jnp.int32),
            ufo_explosion_pos=self.enemy_offscreen_ufo,
            chasing_meteoroid_explosion_frame=jnp.zeros((self.consts.CHASING_METEOROID_MAX,), dtype=jnp.int32),
            chasing_meteoroid_explosion_pos=self.enemy_offscreen_meteoroids,
            chasing_meteoroid_pos=self.enemy_offscreen_meteoroids,
            chasing_meteoroid_active=jnp.zeros((self.consts.CHASING_METEOROID_MAX,), dtype=jnp.bool_),
            chasing_meteoroid_vel_y=jnp.zeros((self.consts.CHASING_METEOROID_MAX,), dtype=jnp.float32),
            chasing_meteoroid_phase=jnp.zeros((self.consts.CHASING_METEOROID_MAX,), dtype=jnp.int32),
            chasing_meteoroid_frame=jnp.zeros((self.consts.CHASING_METEOROID_MAX,), dtype=jnp.int32),
            chasing_meteoroid_lane=jnp.zeros((self.consts.CHASING_METEOROID_MAX,), dtype=jnp.int32),
            chasing_meteoroid_side=jnp.ones((self.consts.CHASING_METEOROID_MAX,), dtype=jnp.int32),
            chasing_meteoroid_spawn_timer=jnp.array(0, dtype=jnp.int32),
            chasing_meteoroid_remaining=jnp.array(0, dtype=jnp.int32),
            chasing_meteoroid_wave_active=jnp.array(False),
            rejuvenator_pos=self.enemy_offscreen,
            rejuvenator_active=jnp.array(False),
            rejuvenator_dead=jnp.array(False),
            rejuvenator_frame=jnp.array(0, dtype=jnp.int32),
            rejuvenator_lane=jnp.array(0, dtype=jnp.int32),
            rejuvenator_explosion_frame=jnp.array(0, dtype=jnp.int32),
            rejuvenator_explosion_pos=self.enemy_offscreen,
            falling_rock_pos=self.enemy_offscreen_falling,
            falling_rock_active=jnp.zeros((self.consts.FALLING_ROCK_MAX,), dtype=jnp.bool_),
            falling_rock_vel_y=jnp.zeros((self.consts.FALLING_ROCK_MAX,), dtype=jnp.float32),
            falling_rock_lane=jnp.zeros((self.consts.FALLING_ROCK_MAX,), dtype=jnp.int32),
            falling_rock_explosion_frame=jnp.zeros((self.consts.FALLING_ROCK_MAX,), dtype=jnp.int32),
            falling_rock_explosion_pos=self.enemy_offscreen_falling,
            lane_blocker_pos=self.enemy_offscreen_lane_blocker,
            lane_blocker_active=jnp.zeros((self.consts.LANE_BLOCKER_MAX,), dtype=jnp.bool_),
            lane_blocker_vel_y=jnp.zeros((self.consts.LANE_BLOCKER_MAX,), dtype=jnp.float32),
            lane_blocker_lane=jnp.zeros((self.consts.LANE_BLOCKER_MAX,), dtype=jnp.int32),
            lane_blocker_phase=jnp.zeros((self.consts.LANE_BLOCKER_MAX,), dtype=jnp.int32),
            lane_blocker_timer=jnp.zeros((self.consts.LANE_BLOCKER_MAX,), dtype=jnp.int32),
            lane_blocker_explosion_frame=jnp.zeros((self.consts.LANE_BLOCKER_MAX,), dtype=jnp.int32),
            lane_blocker_explosion_pos=self.enemy_offscreen_lane_blocker,
            line_positions=BLUE_LINE_INIT_TABLE[0],
            blue_line_counter=jnp.array(0, dtype=jnp.int32),
            death_timer=jnp.array(0, dtype=jnp.int32),
            bouncer_pos=self.enemy_offscreen,
            bouncer_vel=jnp.zeros((2,), dtype=jnp.float32),
            bouncer_state=jnp.array(int(BouncerState.SWITCHING), dtype=jnp.int32),
            bouncer_timer=jnp.array(0, dtype=jnp.int32),
            bouncer_active=jnp.array(False),
            bouncer_lane=jnp.array(0, dtype=jnp.int32),
            bouncer_step_index=jnp.array(0, dtype=jnp.int32),
            bouncer_explosion_frame=jnp.array(0, dtype=jnp.int32),
            bouncer_explosion_pos=self.enemy_offscreen,
            standby_phase=standby_phase,
            standby_timer=jnp.array(0, dtype=jnp.int32),
            standby_accumulator=jnp.array(0.0, dtype=jnp.float32),
            background_flash_timer=jnp.array(0, dtype=jnp.int32),
            coin_pos=self.enemy_offscreen_coins,
            coin_active=jnp.zeros((self.consts.COIN_MAX,), dtype=jnp.bool_),
            coin_timer=jnp.zeros((self.consts.COIN_MAX,), dtype=jnp.int32),
            coin_side=jnp.zeros((self.consts.COIN_MAX,), dtype=jnp.int32),
            coin_explosion_frame=jnp.zeros((self.consts.COIN_MAX,), dtype=jnp.int32),
            coin_explosion_pos=self.enemy_offscreen_coins,
            coin_spawn_count=coin_spawn_count,
            kamikaze_pos=self.kamikaze_offscreen,
            kamikaze_active=jnp.array([False]),
            kamikaze_lane=jnp.array([0], dtype=jnp.int32),
            kamikaze_vel_y=jnp.array([0.0], dtype=jnp.float32),
            kamikaze_tracking=jnp.array([False]),
            kamikaze_spawn_timer=jnp.array([0], dtype=jnp.int32),
            kamikaze_explosion_frame=jnp.array([0], dtype=jnp.int32),
            kamikaze_explosion_pos=self.kamikaze_offscreen,
        )

    def reset_level(self, next_level=1, key: Optional[chex.PRNGKey] = None) -> BeamriderState:
        if key is None:
            key = self.key
        key, ufo_key = jax.random.split(key)
        level_state = self._create_level_state(key=ufo_key)

        return BeamriderState(
            level=level_state,
            score=jnp.array(0),
            sector=jnp.array(next_level),
            level_finished=jnp.array(0),
            reset_coords=jnp.array(False),
            lives=jnp.array(self.consts.STARTING_LIVES, dtype=jnp.int32),
            steps=_counter_array(0),
            ufo_killed=jnp.array(False),
            rng=key,
        )


    def _get_observation(self, state: BeamriderState) -> BeamriderObservation:
        level = state.level
        is_init = level.blue_line_counter < len(BLUE_LINE_INIT_TABLE)

        ufo_offscreen = self.enemy_offscreen_ufo
        enemy_shot_offscreen = self.bullet_offscreen_shots

        player_x = jnp.clip(_get_player_screen_x(level.player_pos), 0, self.consts.SCREEN_WIDTH)
        player_y = jnp.clip(jnp.array(self.consts.PLAYER_POS_Y), 0, self.consts.SCREEN_HEIGHT)
        player_active = jnp.array(level.death_timer == 0, dtype=jnp.bool_)
        player = ObjectObservation.create(
            x=player_x.astype(jnp.int32),
            y=player_y.astype(jnp.int32),
            width=jnp.array(self.consts.PLAYER_SPRITE_SIZE[1], dtype=jnp.int32),
            height=jnp.array(self.consts.PLAYER_SPRITE_SIZE[0], dtype=jnp.int32),
            active=player_active.astype(jnp.int32)
        )

        shot_active = level.player_shot_pos[1] < self.consts.BOTTOM_CLIP
        shot_x = _get_player_shot_screen_x(level.player_shot_pos, level.player_shot_vel, level.bullet_type, self.consts.LASER_ID)
        shot_idx = _get_index_bullet(level.player_shot_pos[1], level.bullet_type, self.consts.LASER_ID)
        shot_size = jnp.take(self.bullet_sprite_sizes, shot_idx, axis=0)
        player_shots = ObjectObservation.create(
            x=jnp.clip(shot_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32)[None],
            y=jnp.clip(level.player_shot_pos[1], 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32)[None],
            width=shot_size[1].astype(jnp.int32)[None],
            height=shot_size[0].astype(jnp.int32)[None],
            active=shot_active.astype(jnp.int32)[None],
            visual_id=level.bullet_type.astype(jnp.int32)[None]
        )

        ufo_pos = jnp.where(is_init, ufo_offscreen, level.white_ufo_pos)
        ufo_y = ufo_pos[1]
        ufo_x = ufo_pos[0] + _get_ufo_alignment(ufo_y)
        ufo_active = ufo_y >= 0.0
        ufo_indices = jnp.clip(_get_index_ufo(ufo_y) - 1, 0, len(self.consts.UFO_SPRITE_SIZES) - 1)
        ufo_sizes = jnp.take(self.ufo_sprite_sizes, ufo_indices, axis=0)
        white_ufo = ObjectObservation.create(
            x=jnp.clip(ufo_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(ufo_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=ufo_sizes[:, 1].astype(jnp.int32),
            height=ufo_sizes[:, 0].astype(jnp.int32),
            active=ufo_active.astype(jnp.int32)
        )

        es_pos = jnp.where(is_init, enemy_shot_offscreen, level.enemy_shot_pos)
        es_y = es_pos[1]
        es_x = es_pos[0] + _get_ufo_alignment(es_y)
        es_active = es_y <= self.consts.BOTTOM_CLIP
        es_sprite_idx = (jnp.floor_divide(level.enemy_shot_timer, 4) % 2).astype(jnp.int32)
        es_sizes = jnp.take(self.enemy_shot_sprite_sizes, es_sprite_idx, axis=0)
        enemy_shots = ObjectObservation.create(
            x=jnp.clip(es_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(es_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=es_sizes[:, 1].astype(jnp.int32),
            height=es_sizes[:, 0].astype(jnp.int32),
            active=es_active.astype(jnp.int32),
            visual_id=es_sprite_idx
        )

        cm_y = level.chasing_meteoroid_pos[1]
        cm_x = level.chasing_meteoroid_pos[0] + _get_ufo_alignment(cm_y)
        chasing_meteoroids = ObjectObservation.create(
            x=jnp.clip(cm_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(cm_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=jnp.full((self.consts.CHASING_METEOROID_MAX,), self.consts.METEOROID_SPRITE_SIZE[1], dtype=jnp.int32),
            height=jnp.full((self.consts.CHASING_METEOROID_MAX,), self.consts.METEOROID_SPRITE_SIZE[0], dtype=jnp.int32),
            active=level.chasing_meteoroid_active.astype(jnp.int32)
        )

        fr_y = level.falling_rock_pos[1]
        fr_x = level.falling_rock_pos[0] + _get_ufo_alignment(fr_y)
        fr_indices = jnp.clip(_get_index_falling_rock(fr_y) - 1, 0, len(self.consts.FALLING_ROCK_SPRITE_SIZES) - 1)
        fr_sizes = jnp.take(self.falling_rock_sprite_sizes, fr_indices, axis=0)
        falling_rocks = ObjectObservation.create(
            x=jnp.clip(fr_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(fr_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=fr_sizes[:, 1].astype(jnp.int32),
            height=fr_sizes[:, 0].astype(jnp.int32),
            active=level.falling_rock_active.astype(jnp.int32)
        )

        lb_y = level.lane_blocker_pos[1]
        lb_x = level.lane_blocker_pos[0] + _get_ufo_alignment(lb_y)
        lb_indices = jnp.clip(_get_index_lane_blocker(lb_y) - 1, 0, len(self.consts.LANE_BLOCKER_SPRITE_SIZES) - 1)
        lb_indices = jnp.where(lb_indices == 2, 3, lb_indices)
        lb_sizes = jnp.take(self.lane_blocker_sprite_sizes, lb_indices, axis=0)
        lane_blockers = ObjectObservation.create(
            x=jnp.clip(lb_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(lb_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=lb_sizes[:, 1].astype(jnp.int32),
            height=lb_sizes[:, 0].astype(jnp.int32),
            active=level.lane_blocker_active.astype(jnp.int32),
            visual_id=level.lane_blocker_phase.astype(jnp.int32)
        )

        c_y = level.coin_pos[1]
        c_x = level.coin_pos[0] + _get_ufo_alignment(c_y)
        coins = ObjectObservation.create(
            x=jnp.clip(c_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(c_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=jnp.full((self.consts.COIN_MAX,), self.consts.COIN_SPRITE_SIZE[1], dtype=jnp.int32),
            height=jnp.full((self.consts.COIN_MAX,), self.consts.COIN_SPRITE_SIZE[0], dtype=jnp.int32),
            active=level.coin_active.astype(jnp.int32)
        )

        k_y = level.kamikaze_pos[1]
        k_x = level.kamikaze_pos[0] + _get_ufo_alignment(k_y)
        k_indices = jnp.clip(_get_index_kamikaze(k_y) - 1, 0, 3)
        k_sizes = jnp.take(self.lane_blocker_sprite_sizes, k_indices, axis=0)
        kamikaze = ObjectObservation.create(
            x=jnp.clip(k_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(k_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=k_sizes[:, 1].astype(jnp.int32),
            height=k_sizes[:, 0].astype(jnp.int32),
            active=level.kamikaze_active.astype(jnp.int32)
        )

        rej_y = level.rejuvenator_pos[1]
        rej_x = level.rejuvenator_pos[0] + _get_ufo_alignment(rej_y)
        rej_indices = jnp.where(level.rejuvenator_dead, 4, jnp.clip(_get_index_rejuvenator(rej_y) - 1, 0, 3))
        rej_sizes = jnp.take(self.rejuvenator_sprite_sizes, rej_indices, axis=0)
        rejuvenator = ObjectObservation.create(
            x=jnp.clip(rej_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(rej_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=rej_sizes[1].astype(jnp.int32),
            height=rej_sizes[0].astype(jnp.int32),
            active=level.rejuvenator_active.astype(jnp.int32),
            visual_id=level.rejuvenator_dead.astype(jnp.int32)
        )

        b_y = level.bouncer_pos[1]
        b_x = level.bouncer_pos[0] + _get_ufo_alignment(b_y)
        bouncer = ObjectObservation.create(
            x=jnp.clip(b_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(b_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=jnp.array(self.consts.BOUNCER_SPRITE_SIZE[1], dtype=jnp.int32),
            height=jnp.array(self.consts.BOUNCER_SPRITE_SIZE[0], dtype=jnp.int32),
            active=level.bouncer_active.astype(jnp.int32)
        )

        ms_stage = level.mothership_stage.astype(jnp.int32)
        ms_active = ms_stage > 0
        ms_y = jnp.array(self.consts.MOTHERSHIP_EMERGE_Y - self.consts.MOTHERSHIP_HEIGHT, dtype=jnp.float32)
        ms_x = level.mothership_position
        mothership = ObjectObservation.create(
            x=jnp.clip(ms_x, 0, self.consts.SCREEN_WIDTH).astype(jnp.int32),
            y=jnp.clip(ms_y, 0, self.consts.SCREEN_HEIGHT).astype(jnp.int32),
            width=jnp.array(self.consts.MOTHERSHIP_SPRITE_SIZE[1], dtype=jnp.int32),
            height=jnp.array(self.consts.MOTHERSHIP_SPRITE_SIZE[0], dtype=jnp.int32),
            active=ms_active.astype(jnp.int32),
            visual_id=ms_stage
        )

        return BeamriderObservation(
            player=player,
            player_shots=player_shots,
            white_ufo=white_ufo,
            enemy_shots=enemy_shots,
            chasing_meteoroids=chasing_meteoroids,
            falling_rocks=falling_rocks,
            lane_blockers=lane_blockers,
            coins=coins,
            kamikaze=kamikaze,
            rejuvenator=rejuvenator,
            bouncer=bouncer,
            mothership=mothership,

            shooting_cd=level.shooting_cooldown,
            torpedoes_left=level.torpedoes_left,
            white_ufo_left=level.white_ufo_left,
            lives=state.lives,
            score=state.score,
            sector=state.sector,
            shooting_delay=level.shooting_delay,
            bullet_type=level.bullet_type,
            shot_type_pending=level.shot_type_pending,
            standby_phase=level.standby_phase,
            death_timer=level.death_timer,
            white_ufo_pattern_id=jnp.where(is_init, 0, level.white_ufo_pattern_id),
            white_ufo_pattern_timer=jnp.where(is_init, 0, level.white_ufo_pattern_timer),
            mothership_timer=level.mothership_timer,
            mothership_stage=level.mothership_stage,
            rejuvenator_dead=level.rejuvenator_dead,
        )

    def _bouncer_bullet_collision(
        self,
        bouncer_pos: chex.Array,
        bouncer_active: chex.Array,
        player_shot_pos: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array,
        is_torpedo: chex.Array
    ) -> Tuple[chex.Array, chex.Array]:
        # Torpedoes only
        bouncer_pos_screen = bouncer_pos[0] + _get_ufo_alignment(bouncer_pos[1])
        bouncer_y = bouncer_pos[1]
        shot_y = player_shot_pos[1]
        bouncer_size = self.bouncer_sprite_size

        is_near = bouncer_active & shot_active & (jnp.abs(bouncer_y - shot_y) <= 16.0)

        bouncer_hit = is_near & \
                      (bouncer_pos_screen < shot_x + bullet_size[1]) & (shot_x < bouncer_pos_screen + bouncer_size[1]) & \
                      (bouncer_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0]) & (
                                  shot_y < bouncer_y + bouncer_size[0])
        # Destroy bouncer only if torpedo
        bouncer_destroyed = bouncer_hit & is_torpedo
        return bouncer_hit, bouncer_destroyed

    def _rejuvenator_bullet_collision(
        self,
        rejuv_pos: chex.Array,
        rejuv_active: chex.Array,
        rejuv_dead: chex.Array,
        player_shot_pos: chex.Array,
        shot_x_screen: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array,
        is_torpedo: chex.Array
    ) -> Tuple[chex.Array, chex.Array]:
        rejuv_y = rejuv_pos[1]
        shot_y = player_shot_pos[1]
        rejuv_x_screen = rejuv_pos[0] + _get_ufo_alignment(rejuv_y)

        is_near = rejuv_active & shot_active & (jnp.abs(rejuv_y - shot_y) <= 16.0)

        rejuv_indices = jnp.where(rejuv_dead, 4, jnp.clip(_get_index_rejuvenator(rejuv_y) - 1, 0, 3))
        rejuv_sizes = jnp.take(self.rejuvenator_sprite_sizes, rejuv_indices, axis=0)

        rejuv_hit = (
                is_near
                & (rejuv_x_screen < shot_x_screen + bullet_size[1]) & (shot_x_screen < rejuv_x_screen + rejuv_sizes[1])
                & (rejuv_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0]) & (
                            shot_y < rejuv_y + rejuv_sizes[0])
        )

        rejuv_destroyed = rejuv_hit & rejuv_dead & is_torpedo

        return rejuv_hit, rejuv_destroyed

    def _mothership_bullet_collision(
        self,
        mothership_stage: chex.Array,
        mothership_position: chex.Array,
        player_shot_pos: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array,
        is_torpedo: chex.Array
    ) -> chex.Array:
        ms_y = self.consts.MOTHERSHIP_EMERGE_Y - self.consts.MOTHERSHIP_HEIGHT
        ms_size = self.mothership_sprite_size
        ms_square = jnp.max(ms_size)

        shot_y = player_shot_pos[1]
        ms_vulnerable = mothership_stage == 2

        is_near = ms_vulnerable & shot_active & (jnp.abs(ms_y - shot_y) <= 16.0)

        hit_mothership = (
                is_near
                & is_torpedo
                & (mothership_position < shot_x + bullet_size[1])
                & (shot_x < mothership_position + ms_square)
                & (ms_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0])
                & (shot_y < ms_y + ms_square + 3)
        )
        return hit_mothership

    def _player_collision_check(
        self,
        state: BeamriderState,
        player_x: chex.Array,
        white_ufo_pos: chex.Array,
        bouncer_pos: chex.Array,
        bouncer_active: chex.Array,
        chasing_meteoroid_pos: chex.Array,
        chasing_meteoroid_active: chex.Array,
        rejuv_pos: chex.Array,
        rejuv_active: chex.Array,
        rejuv_dead: chex.Array,
        falling_rock_pos: chex.Array,
        falling_rock_active: chex.Array,
        lane_blocker_pos: chex.Array,
        lane_blocker_active: chex.Array,
        lane_blocker_lane: chex.Array,
        lane_blocker_phase: chex.Array,
        kamikaze_pos: chex.Array,
        kamikaze_active: chex.Array,
        shot_hit_count: chex.Array,
    ) -> Tuple[chex.Array, chex.Array, chex.Array, chex.Array, chex.Array, chex.Array, chex.Array]:
        player_x_topleft = player_x
        player_y_topleft = float(self.consts.PLAYER_POS_Y)
        player_size = self.player_sprite_size

        hitbox_y_top = player_y_topleft - 1.0
        hitbox_y_bottom = player_y_topleft + player_size[0]

        alignment_at_player = -1.0

        # UFO
        ufo_x = white_ufo_pos[0] + alignment_at_player
        ufo_y = white_ufo_pos[1]
        ufo_size = self.ufo_sprite_sizes[6]
        # look if ufo is near before computing exact hits
        is_ufo_near = (ufo_y >= hitbox_y_top - ufo_size[0]) & (ufo_y <= hitbox_y_bottom)
        ufo_hits = is_ufo_near & (ufo_x < player_x_topleft + player_size[1]) & (player_x_topleft < ufo_x + ufo_size[1])
        ufo_hit_count = jnp.sum(ufo_hits, dtype=jnp.int32)

        # Bouncer
        bouncer_x = bouncer_pos[0] + alignment_at_player
        bouncer_y = bouncer_pos[1]
        bouncer_size = self.bouncer_sprite_size
        is_bouncer_near = bouncer_active & (bouncer_y >= hitbox_y_top - bouncer_size[0]) & (
                    bouncer_y <= hitbox_y_bottom)
        bouncer_hits = is_bouncer_near & (bouncer_x < player_x_topleft + player_size[1]) & (
                    player_x_topleft < bouncer_x + bouncer_size[1])
        bouncer_hit_count = jnp.sum(bouncer_hits, dtype=jnp.int32)

        # Meteoroid
        meteoroid_x = chasing_meteoroid_pos[0] + alignment_at_player
        meteoroid_y = chasing_meteoroid_pos[1]
        meteoroid_size = self.meteoroid_sprite_size
        is_meteoroid_near = chasing_meteoroid_active & (meteoroid_y >= hitbox_y_top - meteoroid_size[0]) & (
                    meteoroid_y <= hitbox_y_bottom)
        chasing_meteoroid_hits = is_meteoroid_near & (meteoroid_x < player_x_topleft + player_size[1]) & (
                    player_x_topleft < meteoroid_x + meteoroid_size[1])
        chasing_meteoroid_hit_count = jnp.sum(chasing_meteoroid_hits, dtype=jnp.int32)

        # Rejuvenator
        rejuv_x = rejuv_pos[0] + alignment_at_player
        rejuv_y = rejuv_pos[1]
        rejuv_size = jnp.where(rejuv_dead, self.rejuvenator_sprite_sizes[4], self.rejuvenator_sprite_sizes[3])
        is_rejuv_near = rejuv_active & (rejuv_y >= hitbox_y_top - rejuv_size[0]) & (rejuv_y <= hitbox_y_bottom)
        rejuv_hit_player = is_rejuv_near & (rejuv_x < player_x_topleft + player_size[1]) & (
                    player_x_topleft < rejuv_x + rejuv_size[1])
        gain_life = rejuv_hit_player & jnp.logical_not(rejuv_dead)
        lose_life_rejuv = rejuv_hit_player & rejuv_dead

        # Rock
        rock_x = falling_rock_pos[0] + alignment_at_player
        rock_y = falling_rock_pos[1]
        rock_size = self.falling_rock_sprite_sizes[3]
        is_rock_near = falling_rock_active & (rock_y >= hitbox_y_top - rock_size[0]) & (rock_y <= hitbox_y_bottom)
        rock_hits = is_rock_near & (rock_x < player_x_topleft + player_size[1]) & (
                    player_x_topleft < rock_x + rock_size[1])
        rock_hit_count = jnp.sum(rock_hits, dtype=jnp.int32)

        # Lane Blocker
        bottom_lanes = self.bottom_lanes
        safe_lane_idx = jnp.clip(lane_blocker_lane, 1, 5) - 1
        lane_blocker_lane_x = bottom_lanes[safe_lane_idx]
        lane_blocker_on_bottom = lane_blocker_active & (lane_blocker_pos[1] >= self.consts.LANE_BLOCKER_BOTTOM_Y)
        lane_blocker_on_bottom = lane_blocker_on_bottom & (lane_blocker_phase != int(LaneBlockerState.RETREAT))
        lane_blocker_hits = lane_blocker_on_bottom & (player_x_topleft == lane_blocker_lane_x)
        lane_blocker_hit_count = jnp.sum(lane_blocker_hits, dtype=jnp.int32)

        # Kamikaze
        kamikaze_x = kamikaze_pos[0, 0] + alignment_at_player
        kamikaze_y = kamikaze_pos[1, 0]
        kamikaze_size = self.lane_blocker_sprite_sizes[3]
        is_kamikaze_near = kamikaze_active[0] & (kamikaze_y >= hitbox_y_top - kamikaze_size[0]) & (
                    kamikaze_y <= hitbox_y_bottom)
        kamikaze_hits_player = is_kamikaze_near & (kamikaze_x < player_x_topleft + player_size[1]) & (
                    player_x_topleft < kamikaze_x + kamikaze_size[1])
        kamikaze_hit_count = kamikaze_hits_player.astype(jnp.int32)

        total_hit_count = (
            shot_hit_count
            + ufo_hit_count
            + bouncer_hit_count
            + chasing_meteoroid_hit_count
            + lose_life_rejuv.astype(jnp.int32)
            + rock_hit_count
            + lane_blocker_hit_count
            + kamikaze_hit_count
        )

        return (
            total_hit_count,
            bouncer_hits,
            chasing_meteoroid_hits,
            rejuv_hit_player,
            gain_life,
            lose_life_rejuv,
            kamikaze_hits_player
        )

    def _handle_active_phase(self, state, action, line_positions, blue_line_counter, standby_accum):
        is_init = blue_line_counter < len(BLUE_LINE_INIT_TABLE)
        return jax.lax.cond(is_init,
                            lambda _: self._handle_init_phase(state, line_positions, blue_line_counter),
                            lambda _: self._handle_normal_phase(state, action, line_positions, blue_line_counter, standby_accum),
                            operand=None)

    def _handle_normal_phase(self, state, action, line_positions, blue_line_counter, standby_accum):
        (
            player_x,
            vel_x,
            player_shot_position,
            player_shot_velocity,
            player_shot_frame,
            torpedos_left,
            bullet_type,
            shooting_cooldown,
            shooting_delay,
            shot_type_pending,
        ) = self._player_step(state, action)

        rngs = jax.random.split(state.rng, 11)
        next_rng = rngs[0]

        # 2. Enemy Step
        enemy_updates = self._enemies_step(state, player_x, vel_x, rngs)

        # 3. Collision Step
        collision_results = self._collisions_step(
            state, player_x, vel_x, player_shot_position, player_shot_velocity,
            player_shot_frame, torpedos_left, bullet_type, shooting_cooldown,
            shooting_delay, shot_type_pending, enemy_updates, rngs[10]
        )

        # 4. State Update & Cleanup
        return self._finalize_normal_step(
            state, collision_results, line_positions, blue_line_counter,
            standby_accum, next_rng
        )

    def _enemies_step(self, state, player_x, vel_x, rngs):
        ufo_keys = rngs[1:4]
        meteoroid_key = rngs[4]
        rejuvenator_key = rngs[5]
        falling_rock_key = rngs[6]
        lane_blocker_key = rngs[7]
        bouncer_key = rngs[8]
        coin_key = rngs[8]
        kamikaze_key = rngs[9]

        ufo_update = self._advance_white_ufos(state)

        (
            bouncer_pos, bouncer_vel, bouncer_state, bouncer_timer,
            bouncer_active, bouncer_lane, bouncer_step_index,
        ) = self._bouncer_dedicated_step(state, bouncer_key)

        (
            chasing_meteoroid_pos, chasing_meteoroid_active, chasing_meteoroid_vel_y,
            chasing_meteoroid_phase, chasing_meteoroid_frame, chasing_meteoroid_lane,
            chasing_meteoroid_side, chasing_meteoroid_spawn_timer, chasing_meteoroid_remaining,
            chasing_meteoroid_wave_active,
        ) = self._chasing_meteoroid_step(state, player_x, vel_x, state.level.white_ufo_left, meteoroid_key)

        (
            falling_rock_pos, falling_rock_active, falling_rock_lane, falling_rock_vel_y,
        ) = self._falling_rock_step(state, falling_rock_key)

        (
            lane_blocker_pos, lane_blocker_active, lane_blocker_lane, lane_blocker_vel_y,
            lane_blocker_phase, lane_blocker_timer,
        ) = self._lane_blocker_step(state, lane_blocker_key)

        (
            kamikaze_pos, kamikaze_active, kamikaze_lane, kamikaze_vel_y,
            kamikaze_tracking, kamikaze_spawn_timer,
        ) = self._kamikaze_step(state, kamikaze_key)

        (
            coin_pos, coin_active, coin_timer, coin_side, coin_spawn_count,
        ) = self._coin_step(state, coin_key)

        (
            rejuv_pos, rejuv_active, rejuv_dead, rejuv_frame, rejuv_lane,
        ) = self._rejuvenator_step(state, rejuvenator_key)

        enemy_shot_pos, enemy_shot_lane, enemy_shot_timer, shot_hit_count = self._enemy_shot_step(
            state, ufo_update.pos, ufo_update.pattern_id, ufo_update.pattern_timer,
        )

        return {
            "ufo": ufo_update,
            "bouncer": (bouncer_pos, bouncer_vel, bouncer_state, bouncer_timer, bouncer_active, bouncer_lane, bouncer_step_index),
            "meteoroid": (chasing_meteoroid_pos, chasing_meteoroid_active, chasing_meteoroid_vel_y, chasing_meteoroid_phase, chasing_meteoroid_frame, chasing_meteoroid_lane, chasing_meteoroid_side, chasing_meteoroid_spawn_timer, chasing_meteoroid_remaining, chasing_meteoroid_wave_active),
            "rock": (falling_rock_pos, falling_rock_active, falling_rock_lane, falling_rock_vel_y),
            "blocker": (lane_blocker_pos, lane_blocker_active, lane_blocker_lane, lane_blocker_vel_y, lane_blocker_phase, lane_blocker_timer),
            "kamikaze": (kamikaze_pos, kamikaze_active, kamikaze_lane, kamikaze_vel_y, kamikaze_tracking, kamikaze_spawn_timer),
            "coin": (coin_pos, coin_active, coin_timer, coin_side, coin_spawn_count),
            "rejuv": (rejuv_pos, rejuv_active, rejuv_dead, rejuv_frame, rejuv_lane),
            "shots": (enemy_shot_pos, enemy_shot_lane, enemy_shot_timer, shot_hit_count)
        }

    def _collisions_step(
        self, state, player_x, vel_x, player_shot_pos, player_shot_vel,
        player_shot_frame, torpedos_left, bullet_type, shooting_cooldown,
        shooting_delay, shot_type_pending, enemy_updates, key
    ):
        ufo_update = enemy_updates["ufo"]
        (bouncer_pos, bouncer_vel, bouncer_state, bouncer_timer, bouncer_active, bouncer_lane, bouncer_step_index) = enemy_updates["bouncer"]
        (chasing_meteoroid_pos, chasing_meteoroid_active, chasing_meteoroid_vel_y, chasing_meteoroid_phase, chasing_meteoroid_frame, chasing_meteoroid_lane, chasing_meteoroid_side, chasing_meteoroid_spawn_timer, chasing_meteoroid_remaining, chasing_meteoroid_wave_active) = enemy_updates["meteoroid"]
        (falling_rock_pos, falling_rock_active, falling_rock_lane, falling_rock_vel_y) = enemy_updates["rock"]
        (lane_blocker_pos, lane_blocker_active, lane_blocker_lane, lane_blocker_vel_y, lane_blocker_phase, lane_blocker_timer) = enemy_updates["blocker"]
        (kamikaze_pos, kamikaze_active, kamikaze_lane, kamikaze_vel_y, kamikaze_tracking, kamikaze_spawn_timer) = enemy_updates["kamikaze"]
        (coin_pos, coin_active, coin_timer, coin_side, coin_spawn_count) = enemy_updates["coin"]
        (rejuv_pos, rejuv_active, rejuv_dead, rejuv_frame, rejuv_lane) = enemy_updates["rejuv"]
        (enemy_shot_pos, enemy_shot_lane, enemy_shot_timer, shot_hit_count) = enemy_updates["shots"]

        # Pre-calculate shot screen X for all collisions
        shot_x_screen = _get_player_shot_screen_x(
            player_shot_pos,
            player_shot_vel,
            bullet_type,
            self.consts.LASER_ID,
        )

        shot_y = player_shot_pos[1]
        shot_active = shot_y < self.consts.BOTTOM_CLIP
        bullet_idx = _get_index_bullet(shot_y, bullet_type, self.consts.LASER_ID)
        bullet_size = jnp.take(self.bullet_sprite_sizes, bullet_idx, axis=0)
        is_torpedo = bullet_type == self.consts.TORPEDO_ID

        # UFO collisions
        (
            white_ufo_pos,
            player_shot_pos,
            white_ufo_pattern_id,
            white_ufo_pattern_timer,
            white_ufo_spawn_delay,
            white_ufo_left,
            score,
            hit_mask_ufo,
            hit_exists_ufo,
        ) = self._collision_handler(
            state, ufo_update.pos, player_shot_pos,
            bullet_type, ufo_update.pattern_id, ufo_update.pattern_timer,
            ufo_update.spawn_delay, key, shot_x_screen,
            shot_active, bullet_size
        )

        # Bouncer bullet collision
        bouncer_hit, bouncer_destroyed = self._bouncer_bullet_collision(
            bouncer_pos, bouncer_active, player_shot_pos, shot_x_screen,
            shot_active, bullet_size, is_torpedo
        )
        pre_collision_bouncer_pos = bouncer_pos
        bouncer_pos = jnp.where(bouncer_destroyed, self.enemy_offscreen, bouncer_pos)
        bouncer_active = jnp.where(bouncer_destroyed, False, bouncer_active)
        player_shot_pos = jnp.where(bouncer_hit, self.bullet_offscreen, player_shot_pos)
        score = jnp.where(bouncer_destroyed, score + 80, score)

        # Meteoroid bullet collision
        pre_collision_meteoroid_pos = chasing_meteoroid_pos
        (
            chasing_meteoroid_pos, chasing_meteoroid_active, chasing_meteoroid_vel_y,
            chasing_meteoroid_phase, chasing_meteoroid_frame, chasing_meteoroid_lane,
            chasing_meteoroid_side, player_shot_pos, chasing_meteoroid_hit_mask,
            hit_exists_meteoroid, collision_exists_m,
        ) = self._chasing_meteoroid_bullet_collision(
            chasing_meteoroid_pos, chasing_meteoroid_active, chasing_meteoroid_vel_y,
            chasing_meteoroid_phase, chasing_meteoroid_frame, chasing_meteoroid_lane,
            chasing_meteoroid_side, player_shot_pos, white_ufo_left, shot_x_screen,
            shot_active, bullet_size, is_torpedo
        )

        # Rock bullet collision
        pre_collision_rock_pos = falling_rock_pos
        (
            falling_rock_pos, falling_rock_active, player_shot_pos,
            falling_rock_hit_mask, hit_exists_rock,
        ) = self._falling_rock_bullet_collision(
            falling_rock_pos, falling_rock_active, player_shot_pos, white_ufo_left, shot_x_screen,
            shot_active, bullet_size, is_torpedo
        )

        # Lane Blocker bullet collision
        pre_collision_lane_blocker_pos = lane_blocker_pos
        (
            lane_blocker_pos, lane_blocker_active, lane_blocker_phase, lane_blocker_timer,
            lane_blocker_vel_y, player_shot_pos, blocker_destroyed, hit_exists_lane_blocker,
        ) = self._lane_blocker_bullet_collision(
            lane_blocker_pos, lane_blocker_active, lane_blocker_phase, lane_blocker_timer,
            lane_blocker_vel_y, player_shot_pos, white_ufo_left, shot_x_screen,
            shot_active, bullet_size, is_torpedo
        )

        # Kamikaze bullet collision
        pre_collision_kamikaze_pos = kamikaze_pos
        (
            kamikaze_pos, kamikaze_active, player_shot_pos, kamikaze_destroyed, hit_exists_kamikaze,
        ) = self._kamikaze_bullet_collision(kamikaze_pos, kamikaze_active, player_shot_pos, shot_x_screen,
                                            shot_active, bullet_size, is_torpedo)

        # Coin bullet collision
        pre_collision_coin_pos = coin_pos
        hit_mask_coin, hit_exists_coin = self._coin_bullet_collision(coin_pos, coin_active, player_shot_pos, shot_x_screen,
                                                                     shot_active, bullet_size)
        coin_pos = jnp.where(hit_mask_coin[None, :], self.enemy_offscreen_col, coin_pos)
        coin_active = jnp.where(hit_mask_coin, False, coin_active)
        player_shot_pos = jnp.where(hit_exists_coin, self.bullet_offscreen, player_shot_pos)
        clamped_sector = jnp.minimum(state.sector, 89)
        score = jnp.where(hit_exists_coin, score + 300 + 30 * clamped_sector + jnp.maximum(state.lives - 1, 0) * (100 + 10 * clamped_sector), score)

        # Rejuvenator bullet collision
        rejuv_hit, rejuv_destroyed = self._rejuvenator_bullet_collision(rejuv_pos, rejuv_active, rejuv_dead, player_shot_pos,
                                                                        shot_x_screen, shot_active, bullet_size, is_torpedo)
        pre_collision_rejuv_pos = rejuv_pos
        rejuv_dead = jnp.logical_or(rejuv_dead, rejuv_hit)
        rejuv_active = jnp.where(rejuv_destroyed, False, rejuv_active)
        rejuv_pos = jnp.where(rejuv_destroyed, self.enemy_offscreen, rejuv_pos)
        player_shot_pos = jnp.where(rejuv_hit, self.bullet_offscreen, player_shot_pos)
        score = jnp.where(rejuv_destroyed, score + 150, score)

        # Mothership bullet collision
        hit_mothership = self._mothership_bullet_collision(state.level.mothership_stage, state.level.mothership_position,
                                                           player_shot_pos, shot_x_screen, shot_active, bullet_size, is_torpedo)
        player_shot_pos = jnp.where(hit_mothership, self.bullet_offscreen, player_shot_pos)
        score = jnp.where(hit_mothership, score + 300 + 30 * clamped_sector + jnp.maximum(state.lives - 1, 0) * (100 + 10 * clamped_sector), score)

        # Enemy shot collision
        hit_mask_shot, hit_exists_shot = self._enemy_shot_bullet_collision(enemy_shot_pos, enemy_shot_timer, player_shot_pos,
                                                                           shot_x_screen, shot_active, bullet_size, is_torpedo)
        enemy_shot_pos_pre_collision = enemy_shot_pos
        enemy_shot_pos = jnp.where(hit_mask_shot[None, :], self.bullet_offscreen_shots, enemy_shot_pos)
        enemy_shot_timer = jnp.where(hit_mask_shot, 0, enemy_shot_timer)
        player_shot_pos = jnp.where(hit_exists_shot, self.bullet_offscreen, player_shot_pos)

        # Projectile resolution
        bullet_hit_any = hit_exists_ufo | bouncer_hit | hit_exists_meteoroid | hit_exists_rock | hit_exists_lane_blocker | rejuv_hit | hit_mothership | hit_exists_shot | hit_exists_coin
        player_shot_frame, shooting_cooldown = self._resolve_player_projectile(
            state,
            player_shot_frame,
            shooting_cooldown,
            bullet_hit_any,
        )

        any_explosion_triggered = (
            jnp.any(hit_mask_ufo)
            | bouncer_destroyed
            | jnp.any(chasing_meteoroid_hit_mask)
            | jnp.any(falling_rock_hit_mask)
            | jnp.any(blocker_destroyed)
            | jnp.any(kamikaze_destroyed)
            | jnp.any(hit_mask_coin)
            | jnp.any(hit_mask_shot)
            | rejuv_destroyed
        )

        # Explosions
        ufo_explosion_frame, ufo_explosion_pos = self._update_enemy_explosions(state.level.ufo_explosion_frame, state.level.ufo_explosion_pos, hit_mask_ufo, ufo_update.pos, self.enemy_offscreen_ufo)
        bouncer_explosion_frame, bouncer_explosion_pos = self._update_enemy_explosions(state.level.bouncer_explosion_frame[None], state.level.bouncer_explosion_pos[:, None], bouncer_destroyed[None], pre_collision_bouncer_pos[:, None], self.enemy_offscreen_col)
        chasing_meteoroid_explosion_frame, chasing_meteoroid_explosion_pos = self._update_enemy_explosions(state.level.chasing_meteoroid_explosion_frame, state.level.chasing_meteoroid_explosion_pos, chasing_meteoroid_hit_mask, pre_collision_meteoroid_pos, self.enemy_offscreen_meteoroids)
        falling_rock_explosion_frame, falling_rock_explosion_pos = self._update_enemy_explosions(state.level.falling_rock_explosion_frame, state.level.falling_rock_explosion_pos, falling_rock_hit_mask, pre_collision_rock_pos, self.enemy_offscreen_falling)
        lane_blocker_explosion_frame, lane_blocker_explosion_pos = self._update_enemy_explosions(state.level.lane_blocker_explosion_frame, state.level.lane_blocker_explosion_pos, blocker_destroyed, pre_collision_lane_blocker_pos, self.enemy_offscreen_lane_blocker)
        enemy_shot_explosion_frame, enemy_shot_explosion_pos = self._update_enemy_explosions(state.level.enemy_shot_explosion_frame, state.level.enemy_shot_explosion_pos, hit_mask_shot, enemy_shot_pos_pre_collision, self.enemy_offscreen_shots)
        coin_explosion_frame, coin_explosion_pos = self._update_enemy_explosions(state.level.coin_explosion_frame, state.level.coin_explosion_pos, hit_mask_coin, pre_collision_coin_pos, self.enemy_offscreen_coins)
        kamikaze_explosion_frame, kamikaze_explosion_pos = self._update_enemy_explosions(state.level.kamikaze_explosion_frame, state.level.kamikaze_explosion_pos, kamikaze_destroyed, pre_collision_kamikaze_pos, self.kamikaze_offscreen)
        rejuv_explosion_frame, rejuv_explosion_pos = self._update_enemy_explosions(state.level.rejuvenator_explosion_frame[None], state.level.rejuvenator_explosion_pos[:, None], rejuv_destroyed[None], pre_collision_rejuv_pos[:, None], self.enemy_offscreen_col)

        # Player collisions
        (total_hit_count, bouncer_hits_p, chasing_meteoroid_hits_p, rejuv_hit_player, gain_life, lose_life_rejuv, kamikaze_hits_player) = self._player_collision_check(
            state, player_x, white_ufo_pos, bouncer_pos, bouncer_active, chasing_meteoroid_pos, chasing_meteoroid_active, rejuv_pos, rejuv_active, rejuv_dead, falling_rock_pos, falling_rock_active, lane_blocker_pos, lane_blocker_active, lane_blocker_lane, lane_blocker_phase, kamikaze_pos, kamikaze_active, shot_hit_count
        )

        # Reset objects hit by player
        bouncer_active = jnp.where(bouncer_hits_p, False, bouncer_active)
        bouncer_pos = jnp.where(bouncer_hits_p, self.enemy_offscreen, bouncer_pos)
        rejuv_active = jnp.where(rejuv_hit_player, False, rejuv_active)
        rejuv_pos = jnp.where(rejuv_hit_player, self.enemy_offscreen, rejuv_pos)
        kamikaze_active = jnp.where(kamikaze_hits_player, jnp.array([False]), kamikaze_active)
        kamikaze_pos = jnp.where(kamikaze_hits_player, self.kamikaze_offscreen, kamikaze_pos)
        chasing_meteoroid_offscreen = self.enemy_offscreen_meteoroids
        chasing_meteoroid_active = jnp.where(chasing_meteoroid_hits_p, False, chasing_meteoroid_active)
        chasing_meteoroid_pos = jnp.where(chasing_meteoroid_hits_p[None, :], chasing_meteoroid_offscreen, chasing_meteoroid_pos)
        reached_player = jnp.logical_and(chasing_meteoroid_active, chasing_meteoroid_pos[1] >= float(self.consts.PLAYER_POS_Y))
        chasing_meteoroid_active = jnp.where(reached_player, False, chasing_meteoroid_active)
        chasing_meteoroid_pos = jnp.where(reached_player[None, :], chasing_meteoroid_offscreen, chasing_meteoroid_pos)

        return {
            "player": (player_x, vel_x, player_shot_pos, player_shot_vel, player_shot_frame, torpedos_left, bullet_type, shooting_cooldown, shooting_delay, shot_type_pending),
            "ufo": (white_ufo_pos, white_ufo_pattern_id, white_ufo_pattern_timer, white_ufo_left, ufo_update.vel, ufo_update.time_on_lane, ufo_update.attack_time, hit_mask_ufo, ufo_update.already_left, white_ufo_spawn_delay, ufo_update.rngs),
            "bouncer": (bouncer_pos, bouncer_vel, bouncer_state, bouncer_timer, bouncer_active, bouncer_lane, bouncer_step_index),
            "meteoroid": (chasing_meteoroid_pos, chasing_meteoroid_active, chasing_meteoroid_vel_y, chasing_meteoroid_phase, chasing_meteoroid_frame, chasing_meteoroid_lane, chasing_meteoroid_side, chasing_meteoroid_spawn_timer, chasing_meteoroid_remaining, chasing_meteoroid_wave_active),
            "rock": (falling_rock_pos, falling_rock_active, falling_rock_lane, falling_rock_vel_y),
            "blocker": (lane_blocker_pos, lane_blocker_active, lane_blocker_lane, lane_blocker_vel_y, lane_blocker_phase, lane_blocker_timer),
            "kamikaze": (kamikaze_pos, kamikaze_active, kamikaze_lane, kamikaze_vel_y, kamikaze_tracking, kamikaze_spawn_timer),
            "coin": (coin_pos, coin_active, coin_timer, coin_side, coin_spawn_count),
            "rejuv": (rejuv_pos, rejuv_active, rejuv_dead, rejuv_frame, rejuv_lane, gain_life, rejuv_hit),
            "shots": (enemy_shot_pos, enemy_shot_lane, enemy_shot_timer),
            "score": score,
            "total_hit_count": total_hit_count,
            "hit_mothership": hit_mothership,
            "any_explosion_triggered": any_explosion_triggered,
            "explosions": (ufo_explosion_frame, ufo_explosion_pos, bouncer_explosion_frame[0], bouncer_explosion_pos[:, 0], chasing_meteoroid_explosion_frame, chasing_meteoroid_explosion_pos, falling_rock_explosion_frame, falling_rock_explosion_pos, lane_blocker_explosion_frame, lane_blocker_explosion_pos, enemy_shot_explosion_frame, enemy_shot_explosion_pos, coin_explosion_frame, coin_explosion_pos, kamikaze_explosion_frame, kamikaze_explosion_pos, rejuv_explosion_frame[0], rejuv_explosion_pos[:, 0])
        }

    def _finalize_normal_step(self, state, collision_results, line_positions, blue_line_counter, standby_accum, next_rng):
        # Unpack results
        score = collision_results["score"]
        total_hit_count = collision_results["total_hit_count"]
        hit_mothership = collision_results["hit_mothership"]
        any_explosion_triggered = collision_results["any_explosion_triggered"]

        (player_x, vel_x, player_shot_pos, player_shot_vel, player_shot_frame, torpedos_left, bullet_type, shooting_cooldown, shooting_delay, shot_type_pending) = collision_results["player"]
        (white_ufo_pos, white_ufo_pattern_id, white_ufo_pattern_timer, white_ufo_left, white_ufo_vel_raw, white_ufo_time_on_lane_raw, white_ufo_attack_time_raw, hit_mask_ufo, white_ufo_already_left_raw, white_ufo_spawn_delay_raw, white_ufo_rngs) = collision_results["ufo"]
        (bouncer_pos, bouncer_vel, bouncer_state, bouncer_timer, bouncer_active, bouncer_lane, bouncer_step_index) = collision_results["bouncer"]
        (chasing_meteoroid_pos, chasing_meteoroid_active, chasing_meteoroid_vel_y, chasing_meteoroid_phase, chasing_meteoroid_frame, chasing_meteoroid_lane, chasing_meteoroid_side, chasing_meteoroid_spawn_timer, chasing_meteoroid_remaining, chasing_meteoroid_wave_active) = collision_results["meteoroid"]
        (falling_rock_pos, falling_rock_active, falling_rock_lane, falling_rock_vel_y) = collision_results["rock"]
        (lane_blocker_pos, lane_blocker_active, lane_blocker_lane, lane_blocker_vel_y, lane_blocker_phase, lane_blocker_timer) = collision_results["blocker"]
        (kamikaze_pos, kamikaze_active, kamikaze_lane, kamikaze_vel_y, kamikaze_tracking, kamikaze_spawn_timer) = collision_results["kamikaze"]
        (coin_pos, coin_active, coin_timer, coin_side, coin_spawn_count) = collision_results["coin"]
        (rejuv_pos, rejuv_active, rejuv_dead, rejuv_frame, rejuv_lane, gain_life, rejuv_hit) = collision_results["rejuv"]
        (enemy_shot_pos, enemy_shot_lane, enemy_shot_timer) = collision_results["shots"]
        (ufo_explosion_frame, ufo_explosion_pos, bouncer_explosion_frame, bouncer_explosion_pos, chasing_meteoroid_explosion_frame, chasing_meteoroid_explosion_pos, falling_rock_explosion_frame, falling_rock_explosion_pos, lane_blocker_explosion_frame, lane_blocker_explosion_pos, enemy_shot_explosion_frame, enemy_shot_explosion_pos, coin_explosion_frame, coin_explosion_pos, kamikaze_explosion_frame, kamikaze_explosion_pos, rejuv_explosion_frame, rejuv_explosion_pos) = collision_results["explosions"]

        current_death_timer = state.level.death_timer
        is_hit = total_hit_count > 0
        start_dying = jnp.logical_and(is_hit, current_death_timer == 0)
        next_death_timer = jnp.where(start_dying, self.consts.DEATH_DURATION, jnp.maximum(current_death_timer - 1, 0))
        is_dying_sequence = next_death_timer > 0
        just_died = jnp.logical_and(current_death_timer > 0, next_death_timer == 0)

        mothership_position, mothership_timer, mothership_stage, sector_advanced_m = self._mothership_step(
            state, white_ufo_left, ufo_explosion_frame, hit_mothership
        )

        died_after_clearing_ufos = jnp.logical_and(just_died, white_ufo_left == 0)
        sector_advanced = jnp.logical_or(died_after_clearing_ufos, sector_advanced_m)
        clear_entities = jnp.logical_or(is_dying_sequence, hit_mothership)

        any_explosion_triggered = collision_results["any_explosion_triggered"]
        current_flash_timer = state.level.background_flash_timer

        # Mothership hit suppresses background animation; other explosions trigger flash.
        flash_trigger = jnp.where(hit_mothership, 0, jnp.where(any_explosion_triggered, 17, jnp.maximum(current_flash_timer - 1, 0)))
        next_flash_timer = flash_trigger

        white_ufo_vel = jnp.where(hit_mask_ufo[None, :], 0.0, white_ufo_vel_raw)
        white_ufo_time_on_lane = jnp.where(hit_mask_ufo, 0, white_ufo_time_on_lane_raw)
        white_ufo_attack_time = jnp.where(hit_mask_ufo, 0, white_ufo_attack_time_raw)

        # Merge sector_advanced and clear_entities into a single condition for entity cleanup.
        # Both conditions reset entities to the same offscreen/zero values, so a single
        # jnp.where per field replaces two separate ones — halving the XLA graph nodes.
        any_clear = sector_advanced | clear_entities
        enemy_shot_offscreen = self.bullet_offscreen_shots
        chasing_meteoroid_offscreen = self.enemy_offscreen_meteoroids
        falling_rock_offscreen = self.enemy_offscreen_falling
        lane_blocker_offscreen = self.enemy_offscreen_lane_blocker
        coin_offscreen = self.enemy_offscreen_coins
        ufo_offscreen = self.enemy_offscreen_ufo
        kamikaze_offscreen = self.kamikaze_offscreen
        rejuv_offscreen = self.enemy_offscreen
        bouncer_offscreen = self.enemy_offscreen

        # Enemy shots: pos cleared by any_clear, timer/lane/explosions by sector_advanced|hit_mothership
        enemy_shot_pos = jnp.where(any_clear, enemy_shot_offscreen, enemy_shot_pos)
        enemy_shot_timer = jnp.where(sector_advanced | hit_mothership, 0, enemy_shot_timer)
        enemy_shot_lane = jnp.where(sector_advanced | hit_mothership, 0, enemy_shot_lane)
        enemy_shot_explosion_frame = jnp.where(hit_mothership, jnp.zeros_like(enemy_shot_explosion_frame), enemy_shot_explosion_frame)
        enemy_shot_explosion_pos = jnp.where(hit_mothership, enemy_shot_offscreen, enemy_shot_explosion_pos)

        # Chasing meteoroids
        chasing_meteoroid_pos = jnp.where(any_clear, chasing_meteoroid_offscreen, chasing_meteoroid_pos)
        chasing_meteoroid_active = jnp.where(any_clear, False, chasing_meteoroid_active)
        chasing_meteoroid_vel_y = jnp.where(any_clear, 0.0, chasing_meteoroid_vel_y)
        chasing_meteoroid_phase = jnp.where(any_clear, 0, chasing_meteoroid_phase)
        chasing_meteoroid_frame = jnp.where(any_clear, 0, chasing_meteoroid_frame)
        chasing_meteoroid_lane = jnp.where(any_clear, 0, chasing_meteoroid_lane)
        chasing_meteoroid_side = jnp.where(any_clear, 1, chasing_meteoroid_side)
        chasing_meteoroid_spawn_timer = jnp.where(any_clear, 0, chasing_meteoroid_spawn_timer)
        chasing_meteoroid_remaining = jnp.where(any_clear, 0, chasing_meteoroid_remaining)
        chasing_meteoroid_wave_active = jnp.where(any_clear, False, chasing_meteoroid_wave_active)
        chasing_meteoroid_explosion_frame = jnp.where(hit_mothership, jnp.zeros_like(chasing_meteoroid_explosion_frame), chasing_meteoroid_explosion_frame)
        chasing_meteoroid_explosion_pos = jnp.where(hit_mothership, chasing_meteoroid_offscreen, chasing_meteoroid_explosion_pos)

        # Rejuvenator
        rejuv_pos = jnp.where(any_clear, rejuv_offscreen, rejuv_pos)
        rejuv_active = jnp.where(any_clear, False, rejuv_active)
        rejuv_dead = jnp.where(any_clear, False, rejuv_dead)
        rejuv_frame = jnp.where(any_clear, 0, rejuv_frame)
        rejuv_lane = jnp.where(any_clear, 0, rejuv_lane)
        rejuv_explosion_frame = jnp.where(hit_mothership, jnp.zeros_like(rejuv_explosion_frame), rejuv_explosion_frame)
        rejuv_explosion_pos = jnp.where(hit_mothership, rejuv_offscreen, rejuv_explosion_pos)

        # Falling rocks
        falling_rock_pos = jnp.where(any_clear, falling_rock_offscreen, falling_rock_pos)
        falling_rock_active = jnp.where(any_clear, False, falling_rock_active)
        falling_rock_lane = jnp.where(any_clear, 0, falling_rock_lane)
        falling_rock_vel_y = jnp.where(any_clear, 0.0, falling_rock_vel_y)
        falling_rock_explosion_frame = jnp.where(hit_mothership, jnp.zeros_like(falling_rock_explosion_frame), falling_rock_explosion_frame)
        falling_rock_explosion_pos = jnp.where(hit_mothership, falling_rock_offscreen, falling_rock_explosion_pos)

        # Lane blockers
        lane_blocker_pos = jnp.where(any_clear, lane_blocker_offscreen, lane_blocker_pos)
        lane_blocker_active = jnp.where(any_clear, False, lane_blocker_active)
        lane_blocker_lane = jnp.where(any_clear, 0, lane_blocker_lane)
        lane_blocker_vel_y = jnp.where(any_clear, 0.0, lane_blocker_vel_y)
        lane_blocker_phase = jnp.where(any_clear, 0, lane_blocker_phase)
        lane_blocker_timer = jnp.where(any_clear, 0, lane_blocker_timer)
        lane_blocker_explosion_frame = jnp.where(hit_mothership, jnp.zeros_like(lane_blocker_explosion_frame), lane_blocker_explosion_frame)
        lane_blocker_explosion_pos = jnp.where(hit_mothership, lane_blocker_offscreen, lane_blocker_explosion_pos)

        # Kamikaze
        kamikaze_pos = jnp.where(any_clear, kamikaze_offscreen, kamikaze_pos)
        kamikaze_active = jnp.where(any_clear, jnp.array([False]), kamikaze_active)
        kamikaze_lane = jnp.where(any_clear, 0, kamikaze_lane)
        kamikaze_vel_y = jnp.where(any_clear, 0.0, kamikaze_vel_y)
        kamikaze_tracking = jnp.where(any_clear, jnp.array([False]), kamikaze_tracking)
        kamikaze_spawn_timer = jnp.where(any_clear, 0, kamikaze_spawn_timer)
        kamikaze_explosion_frame = jnp.where(hit_mothership, jnp.zeros_like(kamikaze_explosion_frame), kamikaze_explosion_frame)
        kamikaze_explosion_pos = jnp.where(hit_mothership, kamikaze_offscreen, kamikaze_explosion_pos)

        # Coins
        coin_pos = jnp.where(any_clear, coin_offscreen, coin_pos)
        coin_active = jnp.where(any_clear, False, coin_active)
        coin_timer = jnp.where(any_clear, 0, coin_timer)
        coin_side = jnp.where(any_clear, 0, coin_side)
        coin_explosion_frame = jnp.where(any_clear, jnp.zeros_like(coin_explosion_frame), coin_explosion_frame)
        coin_explosion_pos = jnp.where(any_clear, coin_offscreen, coin_explosion_pos)
        coin_spawn_count = jnp.where(any_clear, 0, coin_spawn_count)

        # UFOs and bouncer (only cleared by clear_entities)
        white_ufo_pos = jnp.where(clear_entities, ufo_offscreen, white_ufo_pos)
        ufo_explosion_frame = jnp.where(hit_mothership, jnp.zeros_like(ufo_explosion_frame), ufo_explosion_frame)
        ufo_explosion_pos = jnp.where(hit_mothership, ufo_offscreen, ufo_explosion_pos)
        bouncer_pos = jnp.where(clear_entities, bouncer_offscreen, bouncer_pos)
        bouncer_active = jnp.where(clear_entities, False, bouncer_active)
        bouncer_explosion_frame = jnp.where(hit_mothership, jnp.zeros_like(bouncer_explosion_frame), bouncer_explosion_frame)
        bouncer_explosion_pos = jnp.where(hit_mothership, bouncer_offscreen, bouncer_explosion_pos)

        mothership_position = jnp.where(is_dying_sequence, self.mothership_offscreen, mothership_position)
        mothership_timer = jnp.where(is_dying_sequence, 0, mothership_timer)
        mothership_stage = jnp.where(is_dying_sequence, 0, mothership_stage)
        vel_x = jnp.where(is_dying_sequence, 0.0, vel_x)
        player_shot_pos = jnp.where(is_dying_sequence, self.bullet_offscreen, player_shot_pos)
        player_shot_frame = jnp.where(is_dying_sequence, jnp.array(-1, dtype=player_shot_frame.dtype), player_shot_frame)

        new_level_state = LevelState(
            player_pos=player_x, player_vel=vel_x, white_ufo_left=white_ufo_left, mothership_position=mothership_position,
            mothership_timer=mothership_timer, mothership_stage=mothership_stage, player_shot_pos=player_shot_pos,
            player_shot_vel=player_shot_vel, player_shot_frame=player_shot_frame, torpedoes_left=torpedos_left,
            shooting_cooldown=shooting_cooldown, shooting_delay=shooting_delay, bullet_type=bullet_type, shot_type_pending=shot_type_pending,
            enemy_type=jnp.array([0, 0, 0]), white_ufo_pos=white_ufo_pos, white_ufo_vel=white_ufo_vel,
            enemy_shot_pos=enemy_shot_pos, enemy_shot_vel=enemy_shot_lane, enemy_shot_timer=enemy_shot_timer,
            enemy_shot_explosion_frame=enemy_shot_explosion_frame, enemy_shot_explosion_pos=enemy_shot_explosion_pos,
            white_ufo_time_on_lane=white_ufo_time_on_lane, white_ufo_attack_time=white_ufo_attack_time,
            white_ufo_already_left=white_ufo_already_left_raw,
            white_ufo_spawn_delay=white_ufo_spawn_delay_raw,
            white_ufo_pattern_id=white_ufo_pattern_id, white_ufo_pattern_timer=white_ufo_pattern_timer,
            white_ufo_rngs=white_ufo_rngs,
            ufo_explosion_frame=ufo_explosion_frame, ufo_explosion_pos=ufo_explosion_pos,
            chasing_meteoroid_explosion_frame=chasing_meteoroid_explosion_frame, chasing_meteoroid_explosion_pos=chasing_meteoroid_explosion_pos,
            chasing_meteoroid_pos=chasing_meteoroid_pos, chasing_meteoroid_active=chasing_meteoroid_active, chasing_meteoroid_vel_y=chasing_meteoroid_vel_y,
            chasing_meteoroid_phase=chasing_meteoroid_phase, chasing_meteoroid_frame=chasing_meteoroid_frame, chasing_meteoroid_lane=chasing_meteoroid_lane,
            chasing_meteoroid_side=chasing_meteoroid_side, chasing_meteoroid_spawn_timer=chasing_meteoroid_spawn_timer,
            chasing_meteoroid_remaining=chasing_meteoroid_remaining, chasing_meteoroid_wave_active=chasing_meteoroid_wave_active,
            rejuvenator_pos=rejuv_pos, rejuvenator_active=rejuv_active, rejuvenator_dead=rejuv_dead, rejuvenator_frame=rejuv_frame, rejuvenator_lane=rejuv_lane,
            falling_rock_pos=falling_rock_pos, falling_rock_active=falling_rock_active, falling_rock_vel_y=falling_rock_vel_y,
            falling_rock_lane=falling_rock_lane, falling_rock_explosion_frame=falling_rock_explosion_frame, falling_rock_explosion_pos=falling_rock_explosion_pos,
            lane_blocker_pos=lane_blocker_pos, lane_blocker_active=lane_blocker_active, lane_blocker_vel_y=lane_blocker_vel_y,
            lane_blocker_lane=lane_blocker_lane, lane_blocker_phase=lane_blocker_phase, lane_blocker_timer=lane_blocker_timer,
            lane_blocker_explosion_frame=lane_blocker_explosion_frame, lane_blocker_explosion_pos=lane_blocker_explosion_pos,
            line_positions=line_positions, blue_line_counter=blue_line_counter, death_timer=next_death_timer,
            bouncer_pos=bouncer_pos, bouncer_vel=bouncer_vel, bouncer_state=bouncer_state, bouncer_timer=bouncer_timer,
            bouncer_active=bouncer_active, bouncer_lane=bouncer_lane, bouncer_step_index=bouncer_step_index,
            bouncer_explosion_frame=bouncer_explosion_frame, bouncer_explosion_pos=bouncer_explosion_pos,
            standby_phase=jnp.array(int(StandbyPhase.NONE), dtype=jnp.int32), standby_timer=jnp.array(0, dtype=jnp.int32), standby_accumulator=standby_accum,
            coin_pos=coin_pos, coin_active=coin_active, coin_timer=coin_timer, coin_side=coin_side, coin_explosion_frame=coin_explosion_frame,
            coin_explosion_pos=coin_explosion_pos, coin_spawn_count=coin_spawn_count, kamikaze_pos=kamikaze_pos, kamikaze_active=kamikaze_active,
            kamikaze_lane=kamikaze_lane, kamikaze_vel_y=kamikaze_vel_y, kamikaze_tracking=kamikaze_tracking, kamikaze_spawn_timer=kamikaze_spawn_timer,
            kamikaze_explosion_frame=kamikaze_explosion_frame, kamikaze_explosion_pos=kamikaze_explosion_pos,
            background_flash_timer=next_flash_timer,
            rejuvenator_explosion_frame=rejuv_explosion_frame,
            rejuvenator_explosion_pos=rejuv_explosion_pos,
        )

        key_reset, next_rng = jax.random.split(next_rng)
        needs_reset = jnp.logical_or(just_died, sector_advanced)

        def _build_reset_state():
            reset_level_state = self._create_level_state(
                key=key_reset,
                white_ufo_left=white_ufo_left, torpedoes_left=torpedos_left, shooting_cooldown=shooting_cooldown,
                shooting_delay=shooting_delay, shot_type_pending=shot_type_pending,
                standby_phase=jnp.where(
                    sector_advanced,
                    int(StandbyPhase.SECTOR_DONE),
                    jnp.where(just_died, int(StandbyPhase.DECEL), int(StandbyPhase.NONE)),
                ).astype(jnp.int32),
                coin_spawn_count=coin_spawn_count,
            )
            return reset_level_state.replace(
                line_positions=line_positions, blue_line_counter=blue_line_counter,
                death_timer=jnp.where(jnp.logical_and(just_died, jnp.logical_not(sector_advanced)), self.consts.STANDBY_DECEL_DURATION, reset_level_state.death_timer),
                player_pos=player_x,
                background_flash_timer=next_flash_timer,
                rejuvenator_explosion_frame=rejuv_explosion_frame,
                rejuvenator_explosion_pos=rejuv_explosion_pos,
            )

        final_level_state = jax.lax.cond(
            needs_reset,
            _build_reset_state,
            lambda: new_level_state,
        )

        lives_after_gain = jnp.minimum(
            state.lives + gain_life.astype(jnp.int32),
            jnp.array(self.consts.MAX_LIVES, dtype=jnp.int32),
        )
        new_lives = jnp.where(just_died, jnp.maximum(lives_after_gain - 1, 0), lives_after_gain)

        new_state = BeamriderState(
            level=final_level_state, score=score, sector=state.sector,
            level_finished=jnp.array(0), reset_coords=jnp.array(False),
            lives=new_lives, steps=state.steps + 1,
            ufo_killed=state.ufo_killed | jnp.any(hit_mask_ufo),
            rng=next_rng,
        )

        done = jnp.array(self._get_done(new_state), dtype=jnp.bool_)
        done = jnp.logical_or(done, (state.sector == 14) & sector_advanced)
        env_reward = jnp.array(self._get_reward(state, new_state), dtype=jnp.float32)
        info = self._get_info(new_state)
        observation = self._get_observation(new_state)
        return observation, new_state, env_reward, done, info

    def _handle_init_phase(self, state, line_positions, blue_line_counter):
        # During init, we ONLY update the blue line positions and counter.
        # We ALSO advance the RNG so the game doesn't start identically every time.
        rngs = jax.random.split(state.rng, 2)
        new_level = state.level.replace(
            line_positions=line_positions,
            blue_line_counter=blue_line_counter,
            shooting_cooldown=jnp.maximum(state.level.shooting_cooldown - 1, 0),
            shooting_delay=jnp.maximum(state.level.shooting_delay - 1, 0),
            background_flash_timer=jnp.maximum(state.level.background_flash_timer - 1, 0),
            rejuvenator_explosion_frame=state.level.rejuvenator_explosion_frame,
            rejuvenator_explosion_pos=state.level.rejuvenator_explosion_pos,
        )
        new_state = state.replace(level=new_level, steps=state.steps + 1, rng=rngs[0])

        return self._standby_result(new_state)

    def _standby_result(self, new_state):
        """Shared return for all standby phases: zero reward, not done."""
        return (
            self._get_observation(new_state),
            new_state,
            jnp.array(0.0, dtype=jnp.float32),
            jnp.array(False, dtype=jnp.bool_),
            self._get_info(new_state),
        )

    def _handle_standby_decel(self, state, line_positions, blue_line_counter, standby_accum):
        timer = state.level.standby_timer + 1
        finished = timer >= self.consts.STANDBY_DECEL_DURATION
        next_phase = jnp.where(finished, int(StandbyPhase.WAIT), int(StandbyPhase.DECEL))
        next_timer = jnp.where(finished, 0, timer)

        # Keep death timer ticking during decel so life icons keep blinking.
        next_death_timer = jnp.where(
            finished,
            0,
            jnp.maximum(state.level.death_timer - 1, 0),
        )

        new_level = state.level.replace(
            line_positions=line_positions,
            blue_line_counter=blue_line_counter,
            standby_phase=next_phase,
            standby_timer=next_timer,
            standby_accumulator=standby_accum,
            death_timer=next_death_timer,
            player_pos=jnp.where(finished, 77.0, state.level.player_pos),
            background_flash_timer=jnp.maximum(state.level.background_flash_timer - 1, 0),
            rejuvenator_explosion_frame=state.level.rejuvenator_explosion_frame,
            rejuvenator_explosion_pos=state.level.rejuvenator_explosion_pos,
        )
        new_state = state.replace(level=new_level, steps=state.steps + 1)

        return self._standby_result(new_state)

    def _handle_standby_wait(self, state, action, line_positions, blue_line_counter, standby_accum):
        timer = state.level.standby_timer + 1
        # Check for any input (non-NOOP)
        pressed = action != Action.NOOP

        next_phase = jnp.where(pressed, int(StandbyPhase.NONE), int(StandbyPhase.WAIT))
        # Reset blue_line_counter to 0 if we exit wait phase, to trigger acceleration (init)
        next_counter = jnp.where(pressed, 0, blue_line_counter)

        new_level = state.level.replace(
            line_positions=line_positions,
            blue_line_counter=next_counter,
            standby_phase=next_phase,
            standby_timer=timer,
            standby_accumulator=standby_accum,
            background_flash_timer=jnp.maximum(state.level.background_flash_timer - 1, 0),
            rejuvenator_explosion_frame=state.level.rejuvenator_explosion_frame,
            rejuvenator_explosion_pos=state.level.rejuvenator_explosion_pos,
        )
        # Advance RNG to ensure variety after resume
        rngs = jax.random.split(state.rng, 2)
        new_state = state.replace(level=new_level, steps=state.steps + 1, rng=rngs[0])

        return self._standby_result(new_state)

    def _handle_standby_sector_done(self, state, line_positions, blue_line_counter, standby_accum):
        timer = state.level.standby_timer + 1
        finished = timer >= self.consts.STANDBY_SECTOR_DONE_DURATION
        next_phase = jnp.where(finished, int(StandbyPhase.WAIT), int(StandbyPhase.SECTOR_DONE))
        next_timer = jnp.where(finished, 0, timer)

        # Apply sector update and resets when transitioning to WAIT
        next_sector = state.sector + jnp.where(finished, 1, 0)
        next_white_ufo = jnp.where(finished, self.consts.WHITE_UFOS_PER_SECTOR, state.level.white_ufo_left)
        next_torpedoes = jnp.where(finished, 3, state.level.torpedoes_left)

        # Reset UFO positions and other states for the new sector
        initial_ufo_pos = self.white_ufo_spawn_pos
        next_ufo_pos = jnp.where(finished, initial_ufo_pos, state.level.white_ufo_pos)
        next_line_counter = jnp.where(finished, 0, blue_line_counter)

        new_level = state.level.replace(
            line_positions=line_positions,
            blue_line_counter=next_line_counter,
            standby_phase=next_phase,
            standby_timer=next_timer,
            standby_accumulator=standby_accum,
            player_pos=jnp.where(finished, 77.0, state.level.player_pos),
            white_ufo_left=next_white_ufo,
            torpedoes_left=next_torpedoes,
            white_ufo_pos=next_ufo_pos,
            white_ufo_already_left=jnp.where(finished, jnp.zeros(3, dtype=jnp.bool_), state.level.white_ufo_already_left),
            white_ufo_spawn_delay=jnp.where(finished, jnp.zeros(3, dtype=jnp.int32), state.level.white_ufo_spawn_delay),
            white_ufo_vel=jnp.where(finished, self.white_ufo_spawn_vel, state.level.white_ufo_vel),
            white_ufo_pattern_id=jnp.where(finished, 0, state.level.white_ufo_pattern_id),
            white_ufo_pattern_timer=jnp.where(finished, 0, state.level.white_ufo_pattern_timer),
            background_flash_timer=jnp.maximum(state.level.background_flash_timer - 1, 0),
            rejuvenator_explosion_frame=state.level.rejuvenator_explosion_frame,
            rejuvenator_explosion_pos=state.level.rejuvenator_explosion_pos,
        )
        new_state = state.replace(level=new_level, steps=state.steps + 1, sector=next_sector)

        return self._standby_result(new_state)

    @partial(jax.jit, static_argnums=(0,), donate_argnums=(1,))
    def step(
        self,
        state: BeamriderState,
        action: chex.Array,
    ) -> Tuple[BeamriderObservation, BeamriderState, float, bool, BeamriderInfo]:

        # Map action index to semantic value
        action = jnp.take(self._action_set_jnp, action)

        # --- 1. Advance Blue Lines (Always happens) ---
        line_positions, blue_line_counter, standby_accum = self._line_step(state)

        # --- 2. Orchestrate based on phase ---
        return jax.lax.switch(
            state.level.standby_phase,
            [
                lambda: self._handle_active_phase(state, action, line_positions, blue_line_counter, standby_accum),
                lambda: self._handle_standby_decel(state, line_positions, blue_line_counter, standby_accum),
                lambda: self._handle_standby_wait(state, action, line_positions, blue_line_counter, standby_accum),
                lambda: self._handle_standby_sector_done(state, line_positions, blue_line_counter, standby_accum)
            ]
        )

    def _player_step(self, state: BeamriderState, action: chex.Array):
        #level_constants = self._get_level_constants(state.sector)
        x = state.level.player_pos
        v = state.level.player_vel

        is_dead = state.level.death_timer > 0
        action = jnp.where(is_dead, Action.NOOP, action)
        v = jnp.where(is_dead, 0.0, v)

        is_in_lane = jnp.isin(x, self.bottom_lanes) # predicate: x is one of LANES

        v = jax.lax.cond(
            is_in_lane,
            lambda v_: jnp.zeros_like(v_),          # then -> 0
            lambda v_: v_,                          # else -> keep v
            v,                                      # operand
        )

        # Check for Left/Right movement components
        press_left = jnp.isin(action, self._actions_left)
        press_right = jnp.isin(action, self._actions_right)

        v = jax.lax.cond(
            jnp.logical_or(press_left, press_right),
            lambda v_: (press_right.astype(v.dtype) - press_left.astype(v.dtype)) * self.consts.PLAYER_SPEED,
            lambda v_: v_,
            v,
        )
        x_before_change = x
        x = jnp.clip(x + v, self.consts.LEFT_CLIP_PLAYER, self.consts.RIGHT_CLIP_PLAYER - self.consts.PLAYER_SPRITE_SIZE[1])

        ####### Corrected Shot Logic
        bullet_exists = self._bullet_infos(state)
        shooting_cooldown = state.level.shooting_cooldown
        shooting_delay = state.level.shooting_delay
        shot_type_pending = state.level.shot_type_pending

        # 1. Update recovery cooldown
        shooting_cooldown = jnp.maximum(shooting_cooldown - 1, 0)

        # 2. Handle firing input (only if no bullet exists and not in recovery/delay)
        can_initiate_launch = jnp.logical_and.reduce(jnp.array([
            jnp.logical_not(bullet_exists),
            is_in_lane,
            shooting_cooldown == 0,
            shooting_delay == 0
        ]))

        want_torpedo = jnp.isin(action, self._torpedo_actions) & (state.level.torpedoes_left >= 1)
        want_laser = jnp.isin(action, self._actions_fire)

        initiate_launch = can_initiate_launch & (want_torpedo | want_laser)

        # 3. Advance launch delay and spawn bullet on transition 1 -> 0
        new_bullet = (shooting_delay == 1)

        # Update timers
        delay_hold = new_bullet & jnp.logical_not(is_in_lane)
        shooting_delay = jnp.where(
            initiate_launch,
            self.consts.PLAYER_SHOT_LAUNCH_DELAY,
            jnp.where(delay_hold, shooting_delay, jnp.maximum(shooting_delay - 1, 0)),
        )
        shot_type_pending = jnp.where(initiate_launch,
                                      jnp.where(want_torpedo, self.consts.TORPEDO_ID, self.consts.LASER_ID),
                                      shot_type_pending)

        lane_index = jnp.argmax(x_before_change == self.bottom_lanes)
        lane_velocity = self.lane_vectors_b2t[lane_index]

        spawn_bullet = new_bullet & is_in_lane
        shot_velocity = jnp.where(
            spawn_bullet,
            lane_velocity,
            state.level.player_shot_vel,
        )

        bullet_type = jnp.where(spawn_bullet, shot_type_pending, state.level.bullet_type)
        shot_frame = state.level.player_shot_frame
        reset_frame = jnp.full_like(shot_frame, -1)
        shot_frame = jnp.where(
            spawn_bullet,
            jnp.zeros_like(shot_frame),
            jnp.where(bullet_exists, shot_frame + 1, reset_frame),
        )

        is_laser = bullet_type == self.consts.LASER_ID
        max_frames = jnp.where(is_laser, LASER_PROJECTILE_FRAMES, TORPEDO_PROJECTILE_FRAMES)
        active = (shot_frame >= 0) & (shot_frame < max_frames)
        step_idx = jnp.floor_divide(jnp.maximum(shot_frame, 0), PROJECTILE_STEP_FRAMES).astype(jnp.int32)
        laser_y = jnp.take(PROJECTILE_Y_TABLE_LASER, step_idx, mode="clip")
        torpedo_y = jnp.take(PROJECTILE_Y_TABLE_TORPEDO, step_idx, mode="clip")
        shot_y = jnp.where(is_laser, laser_y, torpedo_y)
        shot_y = jnp.where(active, shot_y, self.consts.BULLET_OFFSCREEN_POS[1])

        lane_dy = jnp.where(shot_velocity[1] == 0, 1.0, shot_velocity[1])
        lane_slope = shot_velocity[0] / lane_dy
        delta_y = shot_y - state.level.player_shot_pos[1]
        shot_x = state.level.player_shot_pos[0] + lane_slope * delta_y
        shot_x = jnp.where(spawn_bullet, state.level.player_pos + 3, shot_x)
        shot_x = jnp.where(active, shot_x, self.consts.BULLET_OFFSCREEN_POS[0])
        shot_position = jnp.array([shot_x, shot_y])

        shot_frame = jnp.where(active, shot_frame, reset_frame)

        # Torpedo consumed ONLY when actually spawned
        new_torpedo_spawned = spawn_bullet & (shot_type_pending == self.consts.TORPEDO_ID)
        torpedos_left = state.level.torpedoes_left - new_torpedo_spawned.astype(jnp.int32)

        #####
        return(
            x, v, shot_position, shot_velocity, shot_frame, torpedos_left, bullet_type,
            shooting_cooldown, shooting_delay, shot_type_pending
        )

    def _collision_handler(
        self,
        state: BeamriderState,
        new_white_ufo_pos: chex.Array,
        new_shot_pos: chex.Array,
        new_bullet_type: chex.Array,
        current_patterns: chex.Array,
        current_timers: chex.Array,
        current_spawn_delays: chex.Array,
        key: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,  # NEU
        bullet_size: chex.Array
    ):
        enemies_raw = new_white_ufo_pos.T

        # Collision should match what the player sees on screen:
        # - white UFO x-pos is shifted based on its y-pos (_get_ufo_alignment)
        # - player bullet x-pos is shifted based on its y-pos, type, and lane rounding (_get_player_shot_screen_x)
        ufo_x = new_white_ufo_pos[0, :] + _get_ufo_alignment(new_white_ufo_pos[1, :])
        ufo_y = new_white_ufo_pos[1, :]
        shot_y = new_shot_pos[1]

        is_near = shot_active & (jnp.abs(ufo_y - shot_y) <= 16.0)

        ufo_indices = jnp.clip(_get_index_ufo(ufo_y) - 1, 0, len(self.consts.UFO_SPRITE_SIZES) - 1)
        ufo_sizes = jnp.take(self.ufo_sprite_sizes, ufo_indices, axis=0)
        # ufo_sizes is (3, 2) -> [H, W]



        # AABB collision check
        # Extend enemy hitbox to the top to avoid skipping over them
        # due to large jumps in the projectile Y table (up to 14px).
        # x-overlap: (ufo_x < shot_x + bullet_w) & (shot_x < ufo_x + ufo_w)
        # y-overlap: (ufo_y < shot_y + bullet_h) & (shot_y < ufo_y + ufo_h)
        hit_mask_ufo = is_near & (ufo_x < shot_x + bullet_size[1]) & (shot_x < ufo_x + ufo_sizes[:, 1]) & \
                       (ufo_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0]) & (
                                   shot_y < ufo_y + ufo_sizes[:, 0])

        hit_index = jnp.argmax(hit_mask_ufo)
        hit_exists_ufo = jnp.any(hit_mask_ufo)

        # If there are more than 3 UFOs, the hit one respawns.
        # Otherwise, it stays offscreen.
        should_respawn = state.level.white_ufo_left > 3
        respawn_pos = self.white_ufo_respawn_pos
        offscreen_pos = self.enemy_offscreen
        target_pos = jnp.where(should_respawn, respawn_pos, offscreen_pos)

        enemy_pos_after_hit = enemies_raw.at[hit_index].set(target_pos).T

        # Reset pattern and timer for hit UFO
        new_patterns = jnp.where(hit_mask_ufo, int(WhiteUFOPattern.IDLE), current_patterns)
        new_timers = jnp.where(hit_mask_ufo, 0, current_timers)

        rolls = jax.random.uniform(key, shape=(3,))
        random_delays = jnp.floor(rolls * 300.0).astype(jnp.int32) + 1
        new_spawn_delays = jnp.where(hit_mask_ufo, random_delays, current_spawn_delays)

        player_shot_pos = jnp.where(hit_exists_ufo, self.bullet_offscreen, new_shot_pos)
        enemy_pos = jnp.where(hit_exists_ufo, enemy_pos_after_hit, new_white_ufo_pos)
        white_ufo_left = jnp.where(
            hit_exists_ufo,
            jnp.maximum(state.level.white_ufo_left - 1, 0),
            state.level.white_ufo_left,
        )
        clamped_sector = jnp.minimum(state.sector, 89)
        ufo_score = 40 + 4 * clamped_sector
        score = jnp.where(hit_exists_ufo, state.score + ufo_score, state.score)
        return (enemy_pos, player_shot_pos, new_patterns, new_timers, new_spawn_delays, white_ufo_left, score, hit_mask_ufo, hit_exists_ufo)

    def _update_enemy_explosions(
        self,
        current_frames: chex.Array,
        current_positions: chex.Array,
        hit_mask: chex.Array,
        enemy_positions: chex.Array,
        offscreen: chex.Array = None,
    ):
        """Advance current explosion animations and start new ones when enemies get hit."""
        if offscreen is None:
            offscreen = jnp.tile(self.enemy_offscreen_col, (1, current_frames.shape[0]))

        active_frames = current_frames > 0
        advanced_frames = jnp.where(active_frames, current_frames + 1, current_frames)
        finished = advanced_frames > self.consts.ENEMY_EXPLOSION_FRAMES
        cleared_frames = jnp.where(finished, 0, advanced_frames)
        cleared_positions = jnp.where(finished[None, :], offscreen, current_positions)

        next_frames = jnp.where(hit_mask, jnp.ones_like(cleared_frames), cleared_frames)
        next_positions = jnp.where(hit_mask[None, :], enemy_positions, cleared_positions)
        return next_frames, next_positions

    @staticmethod
    def entropy_heat_prob_static(steps_static, alpha=0.0005, p_min=0.0002, p_max=0.8):
        steps = steps_static / 10
        # steps_static: scalar integer or array
        heat = 1.0 - jnp.exp(-alpha * steps)
        p_swap = p_min + (p_max - p_min) * heat
        return p_swap

    def entropy_heat_prob(self, steps_static, alpha=0.0005, p_min=0.0002, p_max=0.8):
        return JaxBeamrider.entropy_heat_prob_static(steps_static, alpha, p_min, p_max)

    def _white_ufo_claimed_lane(
        self,
        pos: chex.Array,
        pattern_id: chex.Array,
        pattern_timer: chex.Array,
    ) -> chex.Array:
        """Beam a diving UFO is committed to (pattern target), or -1 if idle / offscreen / on top."""
        offscreen = jnp.all(pos == self.enemy_offscreen)
        on_top = pos[1] <= self.consts.TOP_CLIP
        diving = jnp.logical_and.reduce(jnp.array([
            jnp.logical_not(offscreen),
            jnp.logical_not(on_top),
            pattern_id != int(WhiteUFOPattern.IDLE),
        ]))
        return jnp.where(
            diving,
            self._white_ufo_dive_target_lane(pos, pattern_id, pattern_timer),
            jnp.int32(-1),
        )

    def _white_ufo_dive_target_lane(
        self,
        pos: chex.Array,
        pattern_id: chex.Array,
        pattern_timer: chex.Array,
    ) -> chex.Array:
        """Lane a UFO is steering toward (same rules as `_white_ufo_normal`)."""
        x, y = pos[0], pos[1]
        lane_x_at_y = self.top_lanes_x + self.lane_dx_over_dy * (y - float(self.consts.TOP_CLIP))
        raw_closest = jnp.argmin(jnp.abs(lane_x_at_y - x)).astype(jnp.int32)
        lane_offset = jnp.take(self._ufo_lane_offsets, pattern_id)
        is_side_drop = (pattern_id == int(WhiteUFOPattern.DROP_LEFT)) | (
            pattern_id == int(WhiteUFOPattern.DROP_RIGHT)
        )
        start_lane = (pattern_timer >> 8) & 15
        base_lane = jnp.where(is_side_drop & (start_lane <= 6), start_lane, raw_closest)
        is_kamikaze = pattern_id == int(WhiteUFOPattern.KAMIKAZE)
        actively_merging_from_outer = is_side_drop & (
            ((start_lane == 0) & (pattern_id == int(WhiteUFOPattern.DROP_RIGHT)))
            | ((start_lane == 6) & (pattern_id == int(WhiteUFOPattern.DROP_LEFT)))
        )
        on_outer_rail = (raw_closest == 0) | (raw_closest == 6)
        merge_y = jnp.where(
            is_kamikaze | (on_outer_rail & jnp.logical_not(actively_merging_from_outer)),
            float(self.consts.WHITE_UFO_EDGE_COLLISION_MERGE_Y),
            float(self.consts.WHITE_UFO_EDGE_MERGE_Y),
        )
        near_merge = y >= merge_y
        min_lane = jnp.where(near_merge, 1, 0)
        max_lane = jnp.where(near_merge, 5, 6)
        target = jnp.clip(base_lane + lane_offset, min_lane, max_lane)
        target = jnp.where(near_merge & (raw_closest <= 1), 1, target)
        target = jnp.where(near_merge & (raw_closest >= 5), 5, target)
        return target.astype(jnp.int32)

    def _white_ufo_resolve_free_lane(
        self,
        preferred: chex.Array,
        occupied_lanes: chex.Array,
        min_lane: chex.Array,
        max_lane: chex.Array,
    ) -> chex.Array:
        """Pick preferred lane if free, else nearest free beam in [min_lane, max_lane]."""
        lanes = jnp.arange(7, dtype=jnp.int32)
        in_range = (lanes >= min_lane) & (lanes <= max_lane)
        free = in_range & jnp.logical_not(occupied_lanes)
        preferred_ok = free[preferred]
        # Prefer playable beams; only land on unreachable 0/6 when that was the preference.
        prefer_outer = (preferred == 0) | (preferred == 6)
        outer_penalty = jnp.where(
            ((lanes == 0) | (lanes == 6)) & jnp.logical_not(prefer_outer),
            50,
            0,
        )
        dist = jnp.abs(lanes - preferred) + jnp.where(free, 0, 100) + outer_penalty
        fallback = jnp.argmin(dist).astype(jnp.int32)
        any_free = jnp.any(free)
        return jnp.where(preferred_ok, preferred, jnp.where(any_free, fallback, preferred))

    def _advance_white_ufos(self, state: BeamriderState) -> WhiteUFOUpdate:
        """Advance all white UFOs; scan so siblings never share a dive lane."""
        n_ufos = 3
        pos = state.level.white_ufo_pos
        vel = state.level.white_ufo_vel
        time_on_lane = state.level.white_ufo_time_on_lane
        attack_time = state.level.white_ufo_attack_time
        already_left = state.level.white_ufo_already_left
        spawn_delay = state.level.white_ufo_spawn_delay
        pattern_id = state.level.white_ufo_pattern_id
        pattern_timer = state.level.white_ufo_pattern_timer
        rngs = state.level.white_ufo_rngs

        claims0 = jax.vmap(self._white_ufo_claimed_lane, in_axes=(1, 0, 0))(
            pos, pattern_id, pattern_timer
        )

        def body(claims, i):
            occupied = jnp.zeros(7, dtype=bool)

            def add_claim(j, occ):
                c = claims[j]
                valid = (j != i) & (c >= 0) & (c < 7)
                # Divers block idlers. Among two divers, the lower slot index keeps the beam.
                both_diving = (claims[i] >= 0) & (claims[j] >= 0)
                j_has_priority = jnp.where(both_diving, j < i, True)
                take = valid & j_has_priority
                return jnp.where(take, occ.at[c].set(True), occ)

            occupied = jax.lax.fori_loop(0, n_ufos, add_claim, occupied)

            (
                new_pos, vel_x, vel_y, new_tol, new_atk, new_left, new_delay,
                new_pid, new_pt, new_key,
            ) = self._white_ufo_step(
                state.sector,
                state.level.white_ufo_left,
                pos[:, i],
                vel[:, i],
                time_on_lane[i],
                attack_time[i],
                already_left[i],
                spawn_delay[i],
                pattern_id[i],
                pattern_timer[i],
                rngs[i],
                occupied_lanes=occupied,
            )
            new_claim = self._white_ufo_claimed_lane(new_pos, new_pid, new_pt)
            claims = claims.at[i].set(new_claim)
            return claims, (
                new_pos, vel_x, vel_y, new_tol, new_atk, new_left, new_delay,
                new_pid, new_pt, new_key,
            )

        _, results = jax.lax.scan(body, claims0, jnp.arange(n_ufos, dtype=jnp.int32))
        positions, vel_x, vel_y, time_on_lane, attack_time, already_left, spawn_delay, pattern_id, pattern_timer, new_keys = results

        # Hard guarantee: if two divers still book the same beam, peel the
        # higher-index UFO — never teleport its X onto another lane.
        def dedupe(i, carry):
            pos, pid, pt = carry
            claims = jax.vmap(self._white_ufo_claimed_lane, in_axes=(0, 0, 0))(pos, pid, pt)
            c = claims[i]
            occupied = jnp.zeros(7, dtype=bool)

            def add_prior(j, occ):
                cj = claims[j]
                take = (j < i) & (cj >= 0) & (cj < 7)
                return jnp.where(take, occ.at[cj].set(True), occ)

            occupied = jax.lax.fori_loop(0, n_ufos, add_prior, occupied)
            conflict = (c >= 0) & occupied[c]
            already_retreating = pid[i] == int(WhiteUFOPattern.RETREAT)
            # Yield by peeling upward — never re-arm the retreat timer (that re-fires
            # a shot every frame while two divers share a beam).
            pid = jnp.where(conflict, pid.at[i].set(int(WhiteUFOPattern.RETREAT)), pid)
            silent_retreat_t = jnp.int32(self.consts.WHITE_UFO_RETREAT_DURATION) - 1
            pt = jnp.where(
                conflict & jnp.logical_not(already_retreating),
                pt.at[i].set(silent_retreat_t),
                pt,
            )
            return pos, pid, pt

        positions, pattern_id, pattern_timer = jax.lax.fori_loop(
            0, n_ufos, dedupe, (positions, pattern_id, pattern_timer)
        )

        return WhiteUFOUpdate(
            pos=positions.T,
            vel=jnp.stack([vel_x, vel_y]),
            time_on_lane=time_on_lane,
            attack_time=attack_time,
            already_left=already_left,
            spawn_delay=spawn_delay,
            pattern_id=pattern_id.astype(jnp.int32),
            pattern_timer=pattern_timer.astype(jnp.int32),
            rngs=new_keys,
        )
    def _white_ufo_step(
        self,
        sector: chex.Array,
        white_ufo_left: chex.Array,
        white_ufo_position: chex.Array,
        white_ufo_vel: chex.Array,
        time_on_lane: chex.Array,
        attack_time: chex.Array,
        already_left: chex.Array,
        spawn_delay: chex.Array,
        pattern_id: chex.Array,
        pattern_timer: chex.Array,
        key: chex.Array,
        occupied_lanes: chex.Array,
    ):
        white_ufo_vel_x = white_ufo_vel[0]
        white_ufo_vel_y = white_ufo_vel[1]

        offscreen_pos = self.enemy_offscreen
        is_offscreen = jnp.all(white_ufo_position == offscreen_pos)

        key_out, choice_key1, choice_key2, float_key = jax.random.split(key, 4)
        float_rolls = jax.random.uniform(float_key, shape=(5,))

        spawn_delay_roll = float_rolls[0]
        motion_roll = float_rolls[1]
        retreat_roll = float_rolls[2]
        start_roll = float_rolls[3]
        flythrough_roll = float_rolls[4]

        spawn_delay = jnp.maximum(spawn_delay - 1, 0)

        can_shoot = white_ufo_left <= self.consts.WHITE_UFO_SHOOT_UNLOCK_LEFT
        # Late-sector edge flavor (prefer reachable outer beams 1/5) — never stay on 0/6.
        edge_phase = white_ufo_left <= self.consts.WHITE_UFO_OUTER_EDGE_UNLOCK_LEFT

        pattern_id, pattern_timer, time_on_lane, attack_time = self._white_ufo_update_pattern_state(
            sector, white_ufo_left, white_ufo_position, time_on_lane, attack_time, already_left, spawn_delay, pattern_id, pattern_timer,
            retreat_roll, start_roll, flythrough_roll, can_shoot, choice_key1, choice_key2,
            occupied_lanes=occupied_lanes,
        )

        requires_lane_motion = self._white_ufo_pattern_requires_lane_motion(pattern_id)

        on_top_lane = white_ufo_position[1] <= self.consts.TOP_CLIP
        already_left = already_left | jnp.logical_not(on_top_lane)

        def follow_lane(_):
            return self._white_ufo_normal(
                white_ufo_position, white_ufo_vel_x, white_ufo_vel_y, pattern_id,
                pattern_timer, already_left, occupied_lanes=occupied_lanes, edge_phase=edge_phase,
            )

        def stay_on_top(_):
            return self._white_ufo_top_lane(white_ufo_position, white_ufo_vel_x, pattern_id, motion_roll)

        white_ufo_vel_x, white_ufo_vel_y = jax.lax.cond(
            requires_lane_motion,
            follow_lane,
            stay_on_top,
            operand=None
        )

        new_x = white_ufo_position[0] + white_ufo_vel_x
        new_y = white_ufo_position[1] + white_ufo_vel_y

        # Only clip horizontally if on top lane
        on_top_lane = new_y <= self.consts.TOP_CLIP
        clipped_x = jnp.clip(new_x, self.consts.LEFT_CLIP_PLAYER, self.consts.RIGHT_CLIP_PLAYER)
        new_x = jnp.where(on_top_lane, clipped_x, new_x)

        # Past EDGE_MERGE_Y, `_white_ufo_normal` steers toward playable beams 1–5.
        # Keep outer-rail dives inside the visible playfield so late merges don't run
        # off the side before they can cut in (lane 0/6 geometry goes OOB deep down).
        diving_off_top = jnp.logical_and(requires_lane_motion, jnp.logical_not(on_top_lane))
        new_x = jnp.where(diving_off_top, jnp.clip(new_x, 4.0, 155.0), new_x)

        # Soft ceiling: kamikaze/flythrough may pass the ship; others stop just past it.
        is_kamikaze = pattern_id == int(WhiteUFOPattern.KAMIKAZE)
        y_ceiling = jnp.where(is_kamikaze, float(self.consts.PLAYER_POS_Y) + 8.0, float(self.consts.PLAYER_POS_Y) + 1.0)
        new_y = jnp.clip(new_y, float(self.consts.TOP_CLIP), y_ceiling)

        # Despawn only once past the player (not from sideways OOB during the edge pass).
        should_respawn = jnp.logical_and(
            jnp.logical_not(is_offscreen),
            new_y > self.consts.PLAYER_POS_Y,
        )

        white_ufo_position = jnp.where(should_respawn, jnp.array([81.0, 43.0]), jnp.array([new_x, new_y]))
        white_ufo_vel_x = jnp.where(should_respawn, 0.0, white_ufo_vel_x)
        white_ufo_vel_y = jnp.where(should_respawn, 0.0, white_ufo_vel_y)
        time_on_lane = jnp.where(should_respawn, 0, time_on_lane)
        attack_time = jnp.where(should_respawn, 0, attack_time)

        new_spawn_delay_val = jnp.floor(spawn_delay_roll * 300.0).astype(jnp.int32) + 1
        spawn_delay = jnp.where(should_respawn, new_spawn_delay_val, spawn_delay)

        pattern_id = jnp.where(should_respawn, int(WhiteUFOPattern.IDLE), pattern_id)
        pattern_timer = jnp.where(should_respawn, 0, pattern_timer)

        # Ensure that if it was offscreen, it stays offscreen and its state is reset
        white_ufo_position = jnp.where(is_offscreen, offscreen_pos, white_ufo_position)
        white_ufo_vel_x = jnp.where(is_offscreen, 0.0, white_ufo_vel_x)
        white_ufo_vel_y = jnp.where(is_offscreen, 0.0, white_ufo_vel_y)
        time_on_lane = jnp.where(is_offscreen, 0, time_on_lane)
        attack_time = jnp.where(is_offscreen, 0, attack_time)
        spawn_delay = jnp.where(is_offscreen, 0, spawn_delay)
        pattern_id = jnp.where(is_offscreen, int(WhiteUFOPattern.IDLE), pattern_id)
        pattern_timer = jnp.where(is_offscreen, 0, pattern_timer)

        return (
            white_ufo_position, white_ufo_vel_x, white_ufo_vel_y, time_on_lane, attack_time,
            already_left, spawn_delay, pattern_id, pattern_timer, key_out,
        )

    def _white_ufo_pattern_requires_lane_motion(self, pattern_id: chex.Array) -> chex.Array:
        return jnp.isin(pattern_id, self._lane_motion_patterns)

    def _white_ufo_update_pattern_state(
            self,
            sector: chex.Array,
            white_ufo_left: chex.Array,
            position: chex.Array,
            time_on_lane: chex.Array,
            attack_time: chex.Array,
            already_left: chex.Array,
            spawn_delay: chex.Array,
            pattern_id: chex.Array,
            pattern_timer: chex.Array,
            retreat_roll: chex.Array,
            start_roll: chex.Array,
            flythrough_roll: chex.Array,
            can_shoot: chex.Array,
            key_chain_choice: chex.Array,
            key_start_choice: chex.Array,
            occupied_lanes: chex.Array,
    ):
        on_top_lane = position[1] <= self.consts.TOP_CLIP
        time_on_lane = jnp.where(on_top_lane, time_on_lane + 1, 0)
        attack_time = jnp.where(on_top_lane, 0, attack_time)

        # Calculate closest lane and distance to it to determine if we are "on a lane"
        ufo_x = position[0].astype(jnp.float32)
        ufo_y = position[1].astype(jnp.float32)
        lane_x_at_ufo_y = self.top_lanes_x + self.lane_dx_over_dy * (ufo_y - float(self.consts.TOP_CLIP))
        closest_lane_id = jnp.argmin(jnp.abs(lane_x_at_ufo_y - ufo_x)).astype(jnp.int32)

        closest_lane_x = lane_x_at_ufo_y[closest_lane_id]
        dist_to_lane = jnp.abs(closest_lane_x - ufo_x)
        is_on_lane = dist_to_lane <= 0.25

        is_triple = (pattern_id == int(WhiteUFOPattern.TRIPLE_SHOT_RIGHT)) | (
                    pattern_id == int(WhiteUFOPattern.TRIPLE_SHOT_LEFT))

        # Triple Shot State Machine:
        # pattern_timer bits: [shoot_now (1 bit) | last_lane (4 bits) | shots_left (3 bits)]
        shots_left = pattern_timer & 7
        last_lane = (pattern_timer >> 3) & 15
        shoot_now = (pattern_timer >> 7) & 1

        def update_triple(_):
            new_shoot_now = jnp.array(0, dtype=jnp.int32)
            new_shots_left = shots_left
            new_last_lane = last_lane

            # If we just signaled a shot, clear it
            # If we have shots left and just reached a new lane, signal a shot
            can_shoot_lane = (shots_left > 0) & is_on_lane & (closest_lane_id != last_lane)

            new_shoot_now = jnp.where(shoot_now == 1, 0, jnp.where(can_shoot_lane, 1, 0))
            new_shots_left = jnp.where(can_shoot_lane, shots_left - 1, shots_left)
            new_last_lane = jnp.where(can_shoot_lane, closest_lane_id, last_lane)

            return (new_shoot_now << 7) | (new_last_lane << 3) | new_shots_left

        # Non-triple: low 8 bits = countdown; bits 8+ may store DROP_L/R start lane.
        def update_normal_timer(t):
            return ((t >> 8) << 8) | jnp.maximum((t & 255) - 1, 0)

        pattern_timer = jnp.where(
            is_triple,
            update_triple(None),
            update_normal_timer(pattern_timer),
        )
        pattern_countdown = jnp.where(is_triple, pattern_timer & 7, pattern_timer & 255)

        on_outer_now = (closest_lane_id == 0) | (closest_lane_id == 6)
        past_edge_merge = position[1] >= float(self.consts.WHITE_UFO_EDGE_MERGE_Y)
        # Also treat "pressed against the visible edge" as merge time — lane 0/6 X goes
        # off-screen deep down, which caused teleports/despawns on the collision path.
        screen_edge_pinch = on_outer_now & (
            (position[0] <= 6.0) | (position[0] >= 153.0)
        )
        past_collision_merge = (
            (position[1] >= float(self.consts.WHITE_UFO_EDGE_COLLISION_MERGE_Y))
            | screen_edge_pinch
        )
        is_kamikaze_pattern = pattern_id == int(WhiteUFOPattern.KAMIKAZE)

        # If a side-drop aims at a sibling-occupied beam, flatten to straight — but NEVER
        # while on unreachable 0/6 (that traps them on the outer rail).
        is_side_drop_now = (pattern_id == int(WhiteUFOPattern.DROP_LEFT)) | (
            pattern_id == int(WhiteUFOPattern.DROP_RIGHT)
        )
        side_start = (pattern_timer >> 8) & 15
        side_offset = jnp.take(self._ufo_lane_offsets, pattern_id)
        side_target = jnp.clip(side_start + side_offset, 0, 6)
        side_blocked = (
            is_side_drop_now
            & occupied_lanes[side_target]
            & jnp.logical_not(on_outer_now)
            & jnp.logical_not((side_target == 0) | (side_target == 6))
        )
        pattern_id = jnp.where(side_blocked, int(WhiteUFOPattern.DROP_STRAIGHT), pattern_id)
        pattern_timer = jnp.where(side_blocked, pattern_countdown, pattern_timer)
        # Recompute after possible side-block / so outer-approach packing stays consistent.
        is_side_drop_now = (pattern_id == int(WhiteUFOPattern.DROP_LEFT)) | (
            pattern_id == int(WhiteUFOPattern.DROP_RIGHT)
        )
        side_start = (pattern_timer >> 8) & 15
        side_offset = jnp.take(self._ufo_lane_offsets, pattern_id)
        side_target = jnp.clip(side_start + side_offset, 0, 6)

        # Outer approach (1/2→0 or 4/5→6): never expire mid-seek. Expiring while still on
        # the start beam chained back to DROP_STRAIGHT = a few-pixel fake cross then reverse.
        chasing_outer = jnp.logical_and.reduce(jnp.array([
            is_side_drop_now,
            (side_target == 0) | (side_target == 6),
            closest_lane_id != side_target,
            jnp.logical_not(past_edge_merge),
            jnp.logical_not(on_top_lane),
        ]))
        pattern_timer = jnp.where(
            chasing_outer & (pattern_countdown == 0),
            (side_start.astype(jnp.int32) << 8) | jnp.int32(45),
            pattern_timer,
        )
        pattern_countdown = jnp.where(is_triple, pattern_timer & 7, pattern_timer & 255)

        already_merge_l = (
            (pattern_id == int(WhiteUFOPattern.DROP_RIGHT))
            & (((pattern_timer >> 8) & 15) == 0)
        )
        already_merge_r = (
            (pattern_id == int(WhiteUFOPattern.DROP_LEFT))
            & (((pattern_timer >> 8) & 15) == 6)
        )
        in_shoot_merge = already_merge_l | already_merge_r

        # At the shoot-merge gate on 0/6: either cut in for a mid-board shoot/retreat,
        # or commit to a deep outer overshoot (kamikaze) that merges much later/sharper.
        # Decide once from a straight outer ride — never cancel an in-progress DROP merge
        # (that caused a few-pixel inward fake-cross, then reverse back onto 0/6).
        edge_phase_early = white_ufo_left <= self.consts.WHITE_UFO_OUTER_EDGE_UNLOCK_LEFT
        overshoot_p = jnp.where(
            edge_phase_early,
            jnp.minimum(self.consts.WHITE_UFO_FLYTHROUGH_P * 1.8, 0.35),
            self.consts.WHITE_UFO_FLYTHROUGH_P,
        )
        commit_outer_overshoot = jnp.logical_and.reduce(jnp.array([
            on_outer_now,
            past_edge_merge,
            jnp.logical_not(past_collision_merge),
            jnp.logical_not(on_top_lane),
            jnp.logical_not(is_kamikaze_pattern),
            jnp.logical_not(in_shoot_merge),
            pattern_id == int(WhiteUFOPattern.DROP_STRAIGHT),
            can_shoot,
            flythrough_roll < overshoot_p,
        ]))
        pattern_id = jnp.where(commit_outer_overshoot, int(WhiteUFOPattern.KAMIKAZE), pattern_id)
        pattern_timer = jnp.where(
            commit_outer_overshoot,
            self.ufo_pattern_durations[int(WhiteUFOPattern.KAMIKAZE)],
            pattern_timer,
        )
        is_kamikaze_pattern = pattern_id == int(WhiteUFOPattern.KAMIKAZE)

        # Shoot-path: merge at EDGE_MERGE_Y via DROP_L/R (once fire is unlocked).
        # Collision/overshoot (kamikaze): stay on outer until COLLISION_MERGE_Y.
        needs_shoot_merge = jnp.logical_and.reduce(jnp.array([
            on_outer_now,
            past_edge_merge,
            jnp.logical_not(on_top_lane),
            jnp.logical_not(is_kamikaze_pattern),
            can_shoot,
            pattern_id != int(WhiteUFOPattern.IDLE),
            pattern_id != int(WhiteUFOPattern.RETREAT),
        ]))
        # Enter merge once — refreshing the packed timer every frame while on 0/6
        # permanently stalls countdown and prevents the post-merge peel+shot.
        merge_from_left = needs_shoot_merge & (closest_lane_id == 0) & jnp.logical_not(already_merge_l)
        merge_from_right = needs_shoot_merge & (closest_lane_id == 6) & jnp.logical_not(already_merge_r)
        # If still stuck on 0/6 after countdown dies, extend once so seek can finish.
        extend_merge_l = needs_shoot_merge & (closest_lane_id == 0) & already_merge_l & (pattern_countdown == 0)
        extend_merge_r = needs_shoot_merge & (closest_lane_id == 6) & already_merge_r & (pattern_countdown == 0)
        pattern_id = jnp.where(merge_from_left | extend_merge_l, int(WhiteUFOPattern.DROP_RIGHT), pattern_id)
        pattern_id = jnp.where(merge_from_right | extend_merge_r, int(WhiteUFOPattern.DROP_LEFT), pattern_id)
        merge_duration = jnp.maximum(pattern_countdown, jnp.int32(40))
        packed_merge_l = (jnp.int32(0) << 8) | (merge_duration & 255)
        packed_merge_r = (jnp.int32(6) << 8) | (merge_duration & 255)
        pattern_timer = jnp.where(merge_from_left | extend_merge_l, packed_merge_l, pattern_timer)
        pattern_timer = jnp.where(merge_from_right | extend_merge_r, packed_merge_r, pattern_timer)

        shootable_lane = jnp.logical_and(closest_lane_id > 0, closest_lane_id < 6)
        # Lane-switch shots: also allow fire while crossing between beams once unlocked.
        # Prefer mid-board fire — far snipes (above FIRE_MIN_Y) are gated off.
        mid_fire_depth = position[1] >= float(self.consts.WHITE_UFO_FIRE_MIN_Y)
        allow_shoot = jnp.logical_and.reduce(jnp.array([
            jnp.logical_not(on_top_lane),
            can_shoot,
            mid_fire_depth,
            jnp.logical_or(shootable_lane, is_on_lane),
        ]))

        is_drop_pattern = jnp.logical_or(
            pattern_id == int(WhiteUFOPattern.DROP_STRAIGHT),
            jnp.logical_or(
                pattern_id == int(WhiteUFOPattern.DROP_LEFT),
                jnp.logical_or(
                    pattern_id == int(WhiteUFOPattern.DROP_RIGHT),
                    pattern_id == int(WhiteUFOPattern.MOVE_BACK)
                ),
            ),
        )
        is_triple_shot_pattern = is_triple
        is_shoot_pattern = pattern_id == int(WhiteUFOPattern.SHOOT)
        is_engagement_pattern = is_drop_pattern | is_shoot_pattern | is_triple_shot_pattern
        attack_time = jnp.where(
            jnp.logical_and(jnp.logical_not(on_top_lane), is_engagement_pattern),
            attack_time + 1,
            attack_time,
        )

        is_retreat = pattern_id == int(WhiteUFOPattern.RETREAT)
        is_move_back = pattern_id == int(WhiteUFOPattern.MOVE_BACK)
        movement_finished = jnp.logical_and(jnp.logical_or(is_retreat, is_move_back), on_top_lane)
        pattern_id = jnp.where(movement_finished, int(WhiteUFOPattern.IDLE), pattern_id)
        pattern_timer = jnp.where(movement_finished, 0, pattern_timer)
        attack_time = jnp.where(movement_finished, 0, attack_time)

        triple_finished = is_triple & ((pattern_timer & 7) == 0) & jnp.logical_not(
            (pattern_timer >> 7) & 1) & is_on_lane

        # Stuck check: if target lane is same as current lane due to clipping in stage 6/7, finish triple shot.
        lane_offset = jnp.where(pattern_id == int(WhiteUFOPattern.TRIPLE_SHOT_RIGHT), 1, 0)
        lane_offset = jnp.where(pattern_id == int(WhiteUFOPattern.TRIPLE_SHOT_LEFT), -1, lane_offset)
        in_restricted_stage = position[1] >= 86.0
        min_lane = jnp.where(in_restricted_stage, 1, 0)
        max_lane = jnp.where(in_restricted_stage, 5, 6)
        target_lane_id = jnp.clip(closest_lane_id + lane_offset, min_lane, max_lane)

        triple_stuck = is_triple & is_on_lane & (shots_left > 0) & (target_lane_id == closest_lane_id) & (
                    closest_lane_id == last_lane)
        triple_finished = triple_finished | triple_stuck

        pattern_finished_off_top = jnp.logical_and.reduce(jnp.array([
            jnp.logical_not(on_top_lane),
            is_engagement_pattern,
            jnp.where(is_triple, triple_finished, pattern_countdown == 0),
            is_on_lane,
            # Still cutting toward 0/6 — not finished until we arrive (or hit merge gate).
            jnp.logical_not(chasing_outer),
        ]))

        # After a brief SHOOT hold, always peel back (ALE: fire then instant retreat).
        shoot_finished = jnp.logical_and.reduce(jnp.array([
            is_shoot_pattern,
            pattern_countdown == 0,
            jnp.logical_not(on_top_lane),
        ]))

        retreat_prob = self._white_ufo_retreat_prob(attack_time)
        on_outer_lane = (closest_lane_id == 0) | (closest_lane_id == 6)
        on_reachable_edge = (closest_lane_id == 1) | (closest_lane_id == 5)
        deep_enough = position[1] >= self.consts.WHITE_UFO_RETREAT_MIN_Y
        edge_phase = white_ufo_left <= self.consts.WHITE_UFO_OUTER_EDGE_UNLOCK_LEFT
        ufo_y = position[1]
        fire_min = float(self.consts.WHITE_UFO_FIRE_MIN_Y)
        fire_full = float(self.consts.WHITE_UFO_FIRE_FULL_Y)
        # Fire peels: once unlocked, usually peel+shoot at depth. Late edge-phase may
        # instead chain nearer (lane-switch) and shoot from deeper — uncommon.
        fire_depth = jnp.clip((ufo_y - fire_min) / jnp.maximum(fire_full - fire_min, 1.0), 0.0, 1.0)
        # Base peel chance rises with depth; late sector keeps a small "continue nearer" hole.
        peel_p = 0.72 + 0.25 * fire_depth
        continue_nearer = jnp.logical_and.reduce(jnp.array([
            edge_phase,
            can_shoot,
            ufo_y < fire_full,
            retreat_roll >= peel_p,
        ]))
        want_fire_peel = jnp.logical_or.reduce(jnp.array([
            shoot_finished,
            ufo_y >= fire_full,
            jnp.logical_not(continue_nearer),
        ]))

        # Flythrough only on reachable beams — never while still on unreachable 0/6.
        # Late edge-phase: prefer overshoot from outermost reachable beams 1/5.
        flythrough_p = jnp.where(
            edge_phase & on_reachable_edge,
            jnp.minimum(self.consts.WHITE_UFO_FLYTHROUGH_P * 1.8, 0.35),
            self.consts.WHITE_UFO_FLYTHROUGH_P,
        )
        flythrough_now = jnp.logical_and.reduce(jnp.array([
            pattern_finished_off_top,
            deep_enough,
            can_shoot,
            jnp.logical_not(on_outer_lane),
            flythrough_roll < flythrough_p,
            jnp.logical_not(is_shoot_pattern),
            jnp.logical_not(shoot_finished),
            pattern_id != int(WhiteUFOPattern.KAMIKAZE),
        ]))

        # Never peel/retreat while on unreachable outer beams — keep merging inward.
        outer_blocks_retreat = on_outer_lane

        # After fire unlock: peel ⇒ shot ⇒ go back (unless flythrough / rare continue-nearer).
        # Before unlock: probabilistic silent retreat once deep enough.
        peel_y_ok = jnp.where(
            edge_phase & on_reachable_edge & jnp.logical_not(shoot_finished),
            ufo_y >= float(self.consts.WHITE_UFO_EDGE_MERGE_Y),
            deep_enough | shoot_finished,
        )
        peel_unlocked = jnp.logical_and.reduce(jnp.array([
            pattern_finished_off_top | shoot_finished,
            peel_y_ok,
            can_shoot,
            want_fire_peel,
            jnp.logical_not(outer_blocks_retreat),
            jnp.logical_not(flythrough_now),
        ]))
        peel_early = jnp.logical_and.reduce(jnp.array([
            pattern_finished_off_top,
            retreat_roll < retreat_prob,
            deep_enough,
            jnp.logical_not(can_shoot),
            jnp.logical_not(outer_blocks_retreat),
            jnp.logical_not(flythrough_now),
        ]))
        retreat_now = peel_unlocked | peel_early

        pattern_id = jnp.where(flythrough_now, int(WhiteUFOPattern.KAMIKAZE), pattern_id)
        pattern_timer = jnp.where(
            flythrough_now,
            self.ufo_pattern_durations[int(WhiteUFOPattern.KAMIKAZE)],
            pattern_timer,
        )

        pattern_id = jnp.where(retreat_now, int(WhiteUFOPattern.RETREAT), pattern_id)
        pattern_timer = jnp.where(retreat_now, self.consts.WHITE_UFO_RETREAT_DURATION, pattern_timer)
        attack_time = jnp.where(retreat_now | flythrough_now, 0, attack_time)

        chain_next = jnp.logical_and.reduce(jnp.array([
            pattern_finished_off_top,
            jnp.logical_not(retreat_now),
            jnp.logical_not(flythrough_now),
            jnp.logical_not(shoot_finished),
        ]))

        ufo_stage = _get_index_ufo(position[1])

        def choose_chain_pattern(_):
            is_kamikaze_zone = position[1] >= self.consts.KAMIKAZE_Y_THRESHOLD
            pattern, duration = self._white_ufo_choose_pattern(
                key_chain_choice,
                allow_shoot=allow_shoot,
                prev_pattern=pattern_id,
                is_kamikaze_zone=is_kamikaze_zone,
                sector=sector,
                stage=ufo_stage,
                lane=closest_lane_id,
                is_on_lane=is_on_lane,
                white_ufo_left=white_ufo_left,
                occupied_lanes=occupied_lanes,
                past_edge_merge=past_edge_merge,
                on_top=on_top_lane,
            )
            # If pattern is triple shot, initialize bits 3-6 (last_lane) to 15 (all ones)
            # so that it fires on the first lane it is on.
            # DROP_L/R: pack start lane in bits 8+ so offset is fixed to one adjacent beam
            # (otherwise closest±1 re-targets every frame and they cascade across the board).
            is_new_triple = (pattern == int(WhiteUFOPattern.TRIPLE_SHOT_RIGHT)) | (pattern == int(WhiteUFOPattern.TRIPLE_SHOT_LEFT))
            is_side_drop = (pattern == int(WhiteUFOPattern.DROP_LEFT)) | (pattern == int(WhiteUFOPattern.DROP_RIGHT))
            init_timer = jnp.where(is_new_triple, duration | (15 << 3), duration)
            init_timer = jnp.where(
                is_side_drop,
                (closest_lane_id.astype(jnp.int32) << 8) | (init_timer & 255),
                init_timer,
            )
            return pattern, init_timer

        def keep_after_chain(_):
            return pattern_id, pattern_timer

        pattern_id, pattern_timer = jax.lax.cond(
            chain_next,
            choose_chain_pattern,
            keep_after_chain,
            operand=None,
        )

        should_choose_new = jnp.logical_and.reduce(jnp.array([
            on_top_lane,
            pattern_id == int(WhiteUFOPattern.IDLE),
            pattern_timer == 0,
            spawn_delay == 0,
        ]))
        p_start = JaxBeamrider.entropy_heat_prob_static(
            jnp.where(already_left, time_on_lane * 10, time_on_lane),
            alpha=self.consts.WHITE_UFO_ATTACK_ALPHA,
            p_min=jnp.where(already_left, 0.1, self.consts.WHITE_UFO_ATTACK_P_MIN),
            p_max=self.consts.WHITE_UFO_ATTACK_P_MAX,
        )

        start_attack = jnp.logical_and(should_choose_new, start_roll < p_start)

        def choose_new_pattern(_):
            pattern, duration = self._white_ufo_choose_pattern(
                key_start_choice,
                allow_shoot=jnp.array(False),
                prev_pattern=pattern_id,
                is_kamikaze_zone=jnp.array(False),
                sector=sector,
                stage=ufo_stage,
                lane=closest_lane_id,
                is_on_lane=is_on_lane,
                white_ufo_left=white_ufo_left,
                occupied_lanes=occupied_lanes,
                past_edge_merge=past_edge_merge,
                on_top=on_top_lane,
            )
            is_new_triple = (pattern == int(WhiteUFOPattern.TRIPLE_SHOT_RIGHT)) | (
                        pattern == int(WhiteUFOPattern.TRIPLE_SHOT_LEFT))
            is_side_drop = (pattern == int(WhiteUFOPattern.DROP_LEFT)) | (pattern == int(WhiteUFOPattern.DROP_RIGHT))
            init_timer = jnp.where(is_new_triple, duration | (15 << 3), duration)
            init_timer = jnp.where(
                is_side_drop,
                (closest_lane_id.astype(jnp.int32) << 8) | (init_timer & 255),
                init_timer,
            )
            return pattern, init_timer

        def keep_pattern(_):
            return pattern_id, pattern_timer

        pattern_id, pattern_timer = jax.lax.cond(
            start_attack,
            choose_new_pattern,
            keep_pattern,
            operand=None,
        )

        return pattern_id, pattern_timer, time_on_lane, attack_time

    def _white_ufo_retreat_prob(self, attack_time: chex.Array) -> chex.Array:
        p_min = self.consts.WHITE_UFO_RETREAT_P_MIN
        p_max = self.consts.WHITE_UFO_RETREAT_P_MAX
        alpha = self.consts.WHITE_UFO_RETREAT_ALPHA
        # Probability increases with attack_time
        heat = 1.0 - jnp.exp(-alpha * attack_time)
        return p_min + (p_max - p_min) * heat

    def _white_ufo_choose_pattern(
        self,
        key: chex.Array,
        *,
        allow_shoot: chex.Array,
        prev_pattern: chex.Array,
        is_kamikaze_zone: chex.Array,
        sector: chex.Array,
        stage: chex.Array,
        lane: chex.Array,
        is_on_lane: chex.Array,
        white_ufo_left: chex.Array,
        occupied_lanes: chex.Array,
        past_edge_merge: chex.Array,
        on_top: chex.Array,
    ):
        pattern_choices = jnp.array(
            [
                int(WhiteUFOPattern.DROP_STRAIGHT),
                int(WhiteUFOPattern.DROP_LEFT),
                int(WhiteUFOPattern.DROP_RIGHT),
                int(WhiteUFOPattern.SHOOT),
                int(WhiteUFOPattern.MOVE_BACK),
                int(WhiteUFOPattern.KAMIKAZE),
                int(WhiteUFOPattern.TRIPLE_SHOT_RIGHT),
                int(WhiteUFOPattern.TRIPLE_SHOT_LEFT),
            ],
            dtype=jnp.int32,
        )
        # Probabilities for DROP_STRAIGHT, DROP_LEFT, DROP_RIGHT, SHOOT, MOVE_BACK, KAMIKAZE, TRIPLE_RIGHT, TRIPLE_LEFT
        pattern_probs = self.ufo_pattern_probs

        # Restriction: Cannot follow MOVE_BACK with DROP_STRAIGHT (idx 0)
        is_move_back = (prev_pattern == int(WhiteUFOPattern.MOVE_BACK))
        chain_mask = jnp.ones_like(pattern_probs).at[0].set(jnp.where(is_move_back, 0.0, 1.0))
        pattern_probs = pattern_probs * chain_mask

        # Mask out SHOOT (index 3) if not allowed.
        shoot_mask = jnp.array([1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0, 1.0], dtype=jnp.float32)
        pattern_probs = jnp.where(allow_shoot, pattern_probs, pattern_probs * shoot_mask)

        # Mask out KAMIKAZE (index 5) if not in zone
        kamikaze_mask = jnp.array([1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0], dtype=jnp.float32)
        pattern_probs = jnp.where(is_kamikaze_zone, pattern_probs, pattern_probs * kamikaze_mask)

        # Mask out MOVE_BACK (index 4) if stage < 4, or on unhittable outer beams.
        on_outer_lane = (lane == 0) | (lane == 6)
        move_back_mask = jnp.array([1.0, 1.0, 1.0, 1.0, 0.0, 1.0, 1.0, 1.0], dtype=jnp.float32)
        allow_move_back = (stage >= 4) & jnp.logical_not(on_outer_lane)
        pattern_probs = jnp.where(allow_move_back, pattern_probs, pattern_probs * move_back_mask)

        # Never start / chain onto a beam another white UFO already claims.
        # Escaping unreachable 0/6 past the merge line always keeps the inward merge.
        lane_i = lane.astype(jnp.int32)
        left_t = jnp.clip(lane_i - 1, 0, 6)
        right_t = jnp.clip(lane_i + 1, 0, 6)
        lane_busy = occupied_lanes[lane_i]
        left_busy = occupied_lanes[left_t]
        right_busy = occupied_lanes[right_t]
        escaping_outer = on_outer_lane
        occ_mask = jnp.stack([
            jnp.where(lane_busy & jnp.logical_not(escaping_outer), 0.0, 1.0),   # DROP_STRAIGHT
            jnp.where(left_busy & jnp.logical_not(escaping_outer & (lane_i == 6)), 0.0, 1.0),   # DROP_LEFT
            jnp.where(right_busy & jnp.logical_not(escaping_outer & (lane_i == 0)), 0.0, 1.0),  # DROP_RIGHT
            jnp.where(lane_busy, 0.0, 1.0),   # SHOOT
            jnp.where(lane_busy, 0.0, 1.0),   # MOVE_BACK
            jnp.where(lane_busy, 0.0, 1.0),   # KAMIKAZE
            jnp.where(lane_busy | right_busy, 0.0, 1.0),  # TRIPLE_RIGHT
            jnp.where(lane_busy | left_busy, 0.0, 1.0),   # TRIPLE_LEFT
        ]).astype(jnp.float32)
        pattern_probs = pattern_probs * occ_mask

        # Past merge on 0/6: only inward merge is legal.
        # Above merge: allow riding the outer approach beam (DROP_STRAIGHT) mid-dive.
        # From the top rail: never begin a dive already on 0/6 — cut onto 1/5 instead.
        outer_escape_mask = jnp.where(
            (past_edge_merge | on_top) & (lane == 0),
            jnp.array([0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=jnp.float32),
            jnp.where(
                (past_edge_merge | on_top) & (lane == 6),
                jnp.array([0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=jnp.float32),
                jnp.ones(8, dtype=jnp.float32),
            ),
        )
        pattern_probs = pattern_probs * outer_escape_mask
        # Mid-dive on 0/6 (not top, not past merge): ride straight only.
        # Side-drops / kamikaze here fake a cross or abort into a new pattern.
        # Overshoot vs shoot-merge is decided at the merge gate from DROP_STRAIGHT.
        upper_outer_0 = jnp.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=jnp.float32)
        upper_outer_6 = jnp.array([1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0], dtype=jnp.float32)
        mid_outer_ride = jnp.logical_not(past_edge_merge) & jnp.logical_not(on_top)
        pattern_probs = jnp.where(mid_outer_ride & (lane == 0), pattern_probs * upper_outer_0, pattern_probs)
        pattern_probs = jnp.where(mid_outer_ride & (lane == 6), pattern_probs * upper_outer_6, pattern_probs)

        # Lane-switch (DROP_L/R): mild late-sector boost; keep switches occasional.
        in_lane_switch_phase = white_ufo_left <= self.consts.WHITE_UFO_LANE_SWITCH_LEFT_MAX
        switch_boost = jnp.array([0.95, 1.35, 1.35, 1.1, 1.0, 1.0, 1.0, 1.0], dtype=jnp.float32)
        pattern_probs = jnp.where(in_lane_switch_phase, pattern_probs * switch_boost, pattern_probs)

        # Discourage chaining the same side-drop immediately (avoids 3+ lane sweeps).
        same_side_dampen = jnp.ones_like(pattern_probs)
        same_side_dampen = jnp.where(
            prev_pattern == int(WhiteUFOPattern.DROP_LEFT),
            same_side_dampen.at[1].set(0.25),
            same_side_dampen,
        )
        same_side_dampen = jnp.where(
            prev_pattern == int(WhiteUFOPattern.DROP_RIGHT),
            same_side_dampen.at[2].set(0.25),
            same_side_dampen,
        )
        pattern_probs = pattern_probs * same_side_dampen

        # Outer approach: occasional late-sector cuts onto 0/6, then merge to 1/5.
        outer_unlocked = white_ufo_left <= self.consts.WHITE_UFO_OUTER_EDGE_UNLOCK_LEFT
        # On lane 0: prefer DROP_RIGHT (→1). On lane 6: prefer DROP_LEFT (→5).
        merge_left_boost = jnp.array([1.0, 0.0, 3.0, 1.0, 1.0, 1.0, 1.0, 1.0], dtype=jnp.float32)
        merge_right_boost = jnp.array([1.0, 3.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0], dtype=jnp.float32)
        pattern_probs = jnp.where(lane == 0, pattern_probs * merge_left_boost, pattern_probs)
        pattern_probs = jnp.where(lane == 6, pattern_probs * merge_right_boost, pattern_probs)
        # Mild push from 1–2 toward 0 / 4–5 toward 6 (not every dive).
        toward_outer_left = jnp.array([0.9, 1.7, 0.75, 1.0, 1.0, 1.0, 1.0, 1.0], dtype=jnp.float32)
        toward_outer_right = jnp.array([0.9, 0.75, 1.7, 1.0, 1.0, 1.0, 1.0, 1.0], dtype=jnp.float32)
        pattern_probs = jnp.where(
            outer_unlocked & ((lane == 1) | (lane == 2)),
            pattern_probs * toward_outer_left,
            pattern_probs,
        )
        pattern_probs = jnp.where(
            outer_unlocked & ((lane == 4) | (lane == 5)),
            pattern_probs * toward_outer_right,
            pattern_probs,
        )
        reachable_edge_boost = jnp.array([1.1, 1.0, 1.0, 1.3, 0.5, 1.6, 1.0, 1.0], dtype=jnp.float32)
        on_reachable_edge = (lane == 1) | (lane == 5)
        pattern_probs = jnp.where(
            outer_unlocked & on_reachable_edge,
            pattern_probs * reachable_edge_boost,
            pattern_probs,
        )

        # Triple shot conditions
        # sector >= 7
        # stage in [4, 5, 6]
        # triple right: lane in [1, 2, 3]
        # triple left: lane in [5, 4, 3]
        can_triple = sector >= 7
        can_triple = can_triple & (stage >= 4) & (stage <= 6) & is_on_lane

        can_triple_right = can_triple & (lane >= 1) & (lane <= 3)
        can_triple_left = can_triple & (lane >= 3) & (lane <= 5)

        triple_right_mask = jnp.array([1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 1.0], dtype=jnp.float32)
        triple_left_mask = jnp.array([1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0], dtype=jnp.float32)

        pattern_probs = jnp.where(can_triple_right, pattern_probs, pattern_probs * triple_right_mask)
        pattern_probs = jnp.where(can_triple_left, pattern_probs, pattern_probs * triple_left_mask)

        # Avoid division by zero if all probs masked
        prob_sum = jnp.sum(pattern_probs)
        safe_probs = jnp.where(
            prob_sum > 0,
            pattern_probs / prob_sum,
            jnp.ones_like(pattern_probs) / pattern_probs.shape[0],
        )

        pattern = jax.random.choice(key, pattern_choices, shape=(), p=safe_probs)
        duration = self.ufo_pattern_durations[pattern]
        # All engagement beams taken by siblings: peel (on top this instantly becomes IDLE).
        pattern = jnp.where(prob_sum > 0, pattern, int(WhiteUFOPattern.RETREAT))
        duration = jnp.where(prob_sum > 0, duration, self.consts.WHITE_UFO_RETREAT_DURATION)
        # Give outer approaches enough time to actually reach 0/6 (short DROP_L/R used to
        # abort halfway and chain back onto the starting beam).
        outer_approach = jnp.logical_or(
            (pattern == int(WhiteUFOPattern.DROP_LEFT)) & ((lane == 1) | (lane == 2)),
            (pattern == int(WhiteUFOPattern.DROP_RIGHT)) & ((lane == 4) | (lane == 5)),
        )
        outer_ride = (pattern == int(WhiteUFOPattern.DROP_STRAIGHT)) & ((lane == 0) | (lane == 6))
        duration = jnp.where(
            outer_approach | outer_ride,
            jnp.maximum(duration, jnp.int32(95)),
            duration,
        )
        return pattern, duration

    def _white_ufo_top_lane(self, white_ufo_pos, white_ufo_vel_x, pattern_id, motion_roll: chex.Array):
        hold_position = jnp.logical_or(
            pattern_id == int(WhiteUFOPattern.SHOOT),
            white_ufo_pos[1] > float(self.consts.TOP_CLIP),
        )
        min_speed = float(self.consts.WHITE_UFO_TOP_LANE_MIN_SPEED)
        turn_speed = float(self.consts.WHITE_UFO_TOP_LANE_TURN_SPEED)

        vx = jnp.where(hold_position, 0.0, white_ufo_vel_x)
        need_boost = jnp.logical_and(jnp.logical_not(hold_position), jnp.abs(vx) < min_speed)

        random_sign = jnp.where(motion_roll < 0.5, -1.0, 1.0)

        direction = jnp.where(vx == 0.0, random_sign, jnp.sign(vx))
        vx = jnp.where(need_boost, direction * min_speed, vx)

        do_bounce = jnp.logical_not(hold_position)
        vx = jnp.where(
            jnp.logical_and(do_bounce, white_ufo_pos[0] >= self.consts.RIGHT_CLIP_PLAYER),
            -turn_speed,
            vx,
        )
        vx = jnp.where(
            jnp.logical_and(do_bounce, white_ufo_pos[0] <= self.consts.LEFT_CLIP_PLAYER),
            turn_speed,
            vx,
        )
        return vx, 0.0

    def _white_ufo_normal(self, white_ufo_pos, white_ufo_vel_x, white_ufo_vel_y, pattern_id, pattern_timer, already_left, occupied_lanes, edge_phase=False): #velocities not used anymore
        speed_factor = self.consts.WHITE_UFO_SPEED_FACTOR
        retreat_mult = self.consts.WHITE_UFO_RETREAT_SPEED_MULT
        x, y = white_ufo_pos[0], white_ufo_pos[1]

        lane_x_at_y = self.top_lanes_x + self.lane_dx_over_dy * (y - float(self.consts.TOP_CLIP))

        # 1. Identify the current lane (raw, including unhittable outer beams 0 / 6)
        raw_closest_lane_id = jnp.argmin(jnp.abs(lane_x_at_y - x))
        lane_offset = jnp.take(self._ufo_lane_offsets, pattern_id)

        # DROP_L/R: offset is relative to the lane where the pattern started (packed in
        # pattern_timer bits 8+). Re-applying closest±1 each frame cascades across the board.
        is_side_drop = (pattern_id == int(WhiteUFOPattern.DROP_LEFT)) | (
            pattern_id == int(WhiteUFOPattern.DROP_RIGHT)
        )
        start_lane = (pattern_timer >> 8) & 15
        base_lane = jnp.where(is_side_drop & (start_lane <= 6), start_lane, raw_closest_lane_id)

        # Upper dive: may track unreachable 0/6.
        # Shoot-path DROP from 0/6 merges at EDGE_MERGE_Y; kamikaze / plain outer rides
        # hold until COLLISION_MERGE_Y for a steeper cut-in near the player.
        is_kamikaze = pattern_id == int(WhiteUFOPattern.KAMIKAZE)
        actively_merging_from_outer = is_side_drop & (
            ((start_lane == 0) & (pattern_id == int(WhiteUFOPattern.DROP_RIGHT)))
            | ((start_lane == 6) & (pattern_id == int(WhiteUFOPattern.DROP_LEFT)))
        )
        on_outer_rail = (raw_closest_lane_id == 0) | (raw_closest_lane_id == 6)
        merge_y = jnp.where(
            is_kamikaze | (on_outer_rail & jnp.logical_not(actively_merging_from_outer)),
            float(self.consts.WHITE_UFO_EDGE_COLLISION_MERGE_Y),
            float(self.consts.WHITE_UFO_EDGE_MERGE_Y),
        )
        near_merge = y >= merge_y
        is_retreat = pattern_id == int(WhiteUFOPattern.RETREAT)
        is_move_back = pattern_id == int(WhiteUFOPattern.MOVE_BACK)
        is_triple = (pattern_id == int(WhiteUFOPattern.TRIPLE_SHOT_RIGHT)) | (
                    pattern_id == int(WhiteUFOPattern.TRIPLE_SHOT_LEFT))
        min_lane = jnp.where(near_merge, 1, 0)
        max_lane = jnp.where(near_merge, 5, 6)
        target_lane_id = jnp.clip(base_lane + lane_offset, min_lane, max_lane)
        # Lock outer approaches onto the matching outermost player lane when merging.
        # Retreats keep their current beam — don't sideways-snap onto 1/5 then back.
        target_lane_id = jnp.where(
            near_merge & (raw_closest_lane_id <= 1) & jnp.logical_not(is_retreat),
            1,
            target_lane_id,
        )
        target_lane_id = jnp.where(
            near_merge & (raw_closest_lane_id >= 5) & jnp.logical_not(is_retreat),
            5,
            target_lane_id,
        )
        # Retreating from an outer rail: climb the nearest playable edge beam.
        retreat_lane = jnp.clip(raw_closest_lane_id, 1, 5)
        target_lane_id = jnp.where(is_retreat, retreat_lane, target_lane_id)
        preferred_lane_id = target_lane_id
        # Outer approaches / merges must always be allowed onto 1/5 even if a sibling
        # already claims that beam (dedupe peels the other UFO — never trap on 0/6).
        approach_outer = ((preferred_lane_id == 0) | (preferred_lane_id == 6)) & jnp.logical_not(near_merge)
        escaping_or_merging_outer = (
            on_outer_rail
            | approach_outer
            | actively_merging_from_outer
            | (near_merge & ((raw_closest_lane_id <= 1) | (raw_closest_lane_id >= 5)))
        )
        effective_occupied = jnp.where(
            escaping_or_merging_outer | is_retreat,
            jnp.zeros_like(occupied_lanes),
            occupied_lanes,
        )
        target_lane_id = self._white_ufo_resolve_free_lane(
            target_lane_id, effective_occupied, min_lane, max_lane
        )
        yielding_lane = effective_occupied[preferred_lane_id] & (target_lane_id != preferred_lane_id)

        lane_vector = self.lane_vectors_t2b[target_lane_id]
        target_lane_x = lane_x_at_y[target_lane_id]

        cross_track = target_lane_x - x
        distance_to_lane = jnp.abs(cross_track)
        direction = jnp.sign(cross_track)
        # Side drops: gentle lateral crawl.
        # Shoot-path outer merge: mid diagonal. Collision kamikaze: late sharp cut-in.
        target_is_outer = (target_lane_id == 0) | (target_lane_id == 6)
        merging_inward = (
            (on_outer_rail | actively_merging_from_outer)
            & jnp.logical_not(target_is_outer)
            & jnp.logical_not(is_retreat)
        )
        sharp_collision_merge = merging_inward & (
            is_kamikaze | (y >= float(self.consts.WHITE_UFO_EDGE_COLLISION_MERGE_Y) - 1.0)
        )
        seek_vx = jnp.where(
            sharp_collision_merge,
            2.2,
            jnp.where(
                merging_inward | (near_merge & actively_merging_from_outer),
                1.25,
                jnp.where(target_is_outer, 1.1, jnp.where(is_side_drop, 0.55, 0.9)),
            ),
        )
        # Never one-frame teleport — cap yield seeks.
        seek_vx = jnp.where(yielding_lane, jnp.maximum(seek_vx, 1.25), seek_vx)

        def seek_lane(_):
            has_dir = (direction != 0).astype(jnp.float32)
            # Don't overshoot the beam — step at most onto the lane center.
            step = jnp.minimum(seek_vx, distance_to_lane)
            attack_vx = direction * step * has_dir
            retreat_vx = direction * speed_factor * retreat_mult * 2.0 * has_dir

            fast_seek = is_retreat | is_triple | (is_kamikaze & jnp.logical_not(on_outer_rail))
            new_vx = jnp.where(fast_seek, retreat_vx, attack_vx)
            # Collision cut-in: capped attack step (sharp, not a teleport).
            new_vx = jnp.where(sharp_collision_merge | merging_inward, attack_vx, new_vx)

            # While still riding the outer rail as kamikaze, use normal dive speed —
            # full kamikaze vy races off-screen before the late merge can complete.
            riding_outer = on_outer_rail & jnp.logical_not(near_merge)
            kamikaze_vy = jnp.where(
                riding_outer,
                0.25,
                lane_vector[1] * speed_factor * retreat_mult,
            )
            base_vy = (
                    is_retreat * (-lane_vector[1] * speed_factor * retreat_mult) +
                    is_move_back * (-lane_vector[1] * speed_factor) +
                    is_kamikaze * kamikaze_vy +
                    is_triple * 0.25 +
                    (~(is_retreat | is_move_back | is_kamikaze | is_triple)) * 0.25
            )
            merge_vy = jnp.where(sharp_collision_merge, 0.38, 0.32)
            new_vy = jnp.where(merging_inward & jnp.logical_not(is_retreat), merge_vy, base_vy)
            return new_vx, new_vy

        def follow_lane(_):
            normal_vx = lane_vector[0] * speed_factor
            normal_vy = lane_vector[1] * speed_factor

            retreat_vx = -lane_vector[0] * speed_factor * retreat_mult
            retreat_vy = -lane_vector[1] * speed_factor * retreat_mult

            move_back_vx = -lane_vector[0] * speed_factor
            move_back_vy = -lane_vector[1] * speed_factor

            kamikaze_vx = lane_vector[0] * speed_factor * retreat_mult
            kamikaze_vy = lane_vector[1] * speed_factor * retreat_mult
            # Don't race off-screen on 0/6 before the late collision merge.
            riding_outer = on_outer_rail & jnp.logical_not(near_merge)
            kamikaze_vx = jnp.where(riding_outer, normal_vx, kamikaze_vx)
            kamikaze_vy = jnp.where(riding_outer, normal_vy, kamikaze_vy)

            new_vx = (
                    is_retreat * retreat_vx +
                    is_move_back * move_back_vx +
                    is_kamikaze * kamikaze_vx +
                    (~(is_retreat | is_move_back | is_kamikaze)) * normal_vx
            )

            new_vy = (
                    is_retreat * retreat_vy +
                    is_move_back * move_back_vy +
                    is_kamikaze * kamikaze_vy +
                    is_triple * 0.25 +
                    (~(is_retreat | is_move_back | is_kamikaze | is_triple)) * normal_vy
            )
            return new_vx, new_vy

        return jax.lax.cond(
            distance_to_lane <= 0.25,
            follow_lane,
            seek_lane,
            operand=None,
        )

    def _enemy_shot_step(
        self,
        state: BeamriderState,
        white_ufo_pos: chex.Array,
        white_ufo_pattern_id: chex.Array,
        white_ufo_pattern_timer: chex.Array,
    ) -> Tuple[chex.Array, chex.Array, chex.Array, chex.Array]:
        lane_vectors = self.lane_vectors_t2b
        lanes_top_x = self.top_lanes_x
        lane_dx_over_dy = self.lane_dx_over_dy

        offscreen_xy = self.bullet_offscreen
        offscreen = self.bullet_offscreen_shots

        shot_pos = state.level.enemy_shot_pos.astype(jnp.float32)
        shot_lane = state.level.enemy_shot_vel.astype(jnp.int32)
        shot_timer = state.level.enemy_shot_timer.astype(jnp.int32)

        shot_active = shot_pos[1] <= float(self.consts.BOTTOM_CLIP)
        shot_timer = jnp.where(shot_active, shot_timer + 1, 0)

        retreat_duration = int(self.consts.WHITE_UFO_RETREAT_DURATION)

        is_triple = (white_ufo_pattern_id == int(WhiteUFOPattern.TRIPLE_SHOT_RIGHT)) | (white_ufo_pattern_id == int(WhiteUFOPattern.TRIPLE_SHOT_LEFT))
        shoot_now_triple = (white_ufo_pattern_timer >> 7) & 1

        # Fire only when a real fire-peel begins (timer armed at full RETREAT_DURATION).
        # Silent peels (dedupe yields) use duration-1 so they never shoot.
        # Kamikaze/flythrough must NOT shoot-on-commit — shot ⇒ go back, not dive nearer.
        wants_spawn = jnp.logical_and(
            white_ufo_pattern_id == int(WhiteUFOPattern.RETREAT),
            white_ufo_pattern_timer == retreat_duration,
        )
        wants_spawn = wants_spawn | (is_triple & (shoot_now_triple == 1))

        ufo_on_screen = white_ufo_pos[1] <= float(self.consts.BOTTOM_CLIP)
        ufo_not_on_top_lane = white_ufo_pos[1] > float(self.consts.TOP_CLIP)
        ufo_x = white_ufo_pos[0].astype(jnp.float32)
        ufo_y = white_ufo_pos[1].astype(jnp.float32)

        lane_x_at_ufo_y = lanes_top_x[:, None] + lane_dx_over_dy[:, None] * (
            ufo_y[None, :] - float(self.consts.TOP_CLIP)
        )
        closest_lane = jnp.argmin(jnp.abs(lane_x_at_ufo_y - ufo_x[None, :]), axis=0).astype(jnp.int32)
        # Only fire from player-reachable beams — never while still on 0/6 (that spawned
        # shots on 1/5 while the saucer stayed on the wall: looked like a 1-frame teleport).
        shot_lane_id = closest_lane
        allowed_shot_lane = (closest_lane >= 1) & (closest_lane <= 5)

        # Each UFO has 3 slots: [3*i, 3*i+1, 3*i+2]
        # We find the first inactive slot for each UFO.
        ufo_shot_active = jnp.reshape(shot_active, (3, 3)) # UFO, Slot
        first_inactive_slot = jnp.argmax(jnp.logical_not(ufo_shot_active), axis=1) # UFO
        has_inactive_slot = jnp.any(jnp.logical_not(ufo_shot_active), axis=1)

        # Unlock after ~2 kills (enemies remaining ≤ 13), matching ALE sector-1 log.
        can_shoot = state.level.white_ufo_left <= self.consts.WHITE_UFO_SHOOT_UNLOCK_LEFT
        # Gate far snipes. Use pre-motion Y so a same-frame retreat step can't drop a
        # mid-board peel just under the floor.
        fire_depth_y = jnp.maximum(ufo_y, state.level.white_ufo_pos[1].astype(jnp.float32))
        deep_enough_to_fire = fire_depth_y >= float(self.consts.WHITE_UFO_FIRE_MIN_Y)

        spawn = jnp.logical_and.reduce(
            jnp.array([
                wants_spawn,
                ufo_on_screen,
                ufo_not_on_top_lane,
                allowed_shot_lane,
                has_inactive_slot,
                deep_enough_to_fire,
            ])
        ) & can_shoot

        spawn_y = jnp.clip(ufo_y + 4.0, float(self.consts.TOP_CLIP), float(self.consts.BOTTOM_CLIP))
        spawn_x = jnp.take(lanes_top_x, shot_lane_id) + jnp.take(lane_dx_over_dy, shot_lane_id) * (
            spawn_y - float(self.consts.TOP_CLIP)
        )

        # Global slot indices for each UFO's best spawn candidate
        spawn_slots = jnp.arange(3) * 3 + first_inactive_slot
        spawn_mask = (jax.nn.one_hot(spawn_slots, 9) * spawn[:, None]).sum(axis=0).astype(jnp.bool_) # (9,)

        # Update shot state for spawned shots
        spawn_x_expanded = jnp.repeat(spawn_x, 3) # (9,)
        spawn_y_expanded = jnp.repeat(spawn_y, 3) # (9,)
        spawn_pos_expanded = jnp.stack([spawn_x_expanded, spawn_y_expanded]) # (2, 9)

        shot_pos = jnp.where(spawn_mask[None, :], spawn_pos_expanded, shot_pos)

        shot_lane_expanded = jnp.repeat(shot_lane_id, 3) # (9,)
        shot_lane = jnp.where(spawn_mask, shot_lane_expanded, shot_lane)
        shot_timer = jnp.where(spawn_mask, 0, shot_timer)
        shot_active = jnp.logical_or(shot_active, spawn_mask)

        # Per-shot cadence (frame-by-frame):
        should_move = jnp.logical_and(shot_active, (shot_timer % 4) == 2)
        speed = float(self.consts.WHITE_UFO_SHOT_SPEED_FACTOR)
        lane_dy = jnp.take(lane_vectors[:, 1], shot_lane)
        y_after = shot_pos[1] + jnp.where(should_move, lane_dy * speed, 0.0)
        x_after = jnp.take(lanes_top_x, shot_lane) + jnp.take(lane_dx_over_dy, shot_lane) * (
            y_after - float(self.consts.TOP_CLIP)
        )
        shot_pos = jnp.where(shot_active, jnp.stack([x_after, y_after]), shot_pos)

        moved_offscreen = shot_pos[1] > float(self.consts.BOTTOM_CLIP)
        shot_pos = jnp.where(moved_offscreen, offscreen, shot_pos)
        shot_timer = jnp.where(moved_offscreen, 0, shot_timer)
        shot_active = jnp.logical_and(shot_active, jnp.logical_not(moved_offscreen))

        player_left = state.level.player_pos.astype(jnp.float32)
        player_y = float(self.consts.PLAYER_POS_Y)
        player_size = self.player_sprite_size

        shot_x = shot_pos[0] + _get_ufo_alignment(shot_pos[1])
        shot_y = shot_pos[1]

        shot_sizes = self.consts.ENEMY_SHOT_SPRITE_SIZES[0] # always take the larger size

        player_hitbox_top = player_y - 1

        hits = shot_active & \
               (shot_x < player_left + player_size[1]) & (player_left < shot_x + shot_sizes[1]) & \
               (shot_y < player_y + player_size[0]) & (player_hitbox_top < shot_y + shot_sizes[0])

        hit_count = jnp.sum(hits, dtype=jnp.int32)

        shot_pos = jnp.where(hits[None, :], offscreen, shot_pos)
        shot_timer = jnp.where(hits, 0, shot_timer)
        return shot_pos, shot_lane, shot_timer, hit_count

    def _chasing_meteoroid_step(
        self,
        state: BeamriderState,
        player_x: chex.Array,
        player_vel: chex.Array,
        white_ufo_left: chex.Array,
        key: chex.Array,
    ):
        pos = state.level.chasing_meteoroid_pos
        active = state.level.chasing_meteoroid_active
        vel_y = state.level.chasing_meteoroid_vel_y
        phase = state.level.chasing_meteoroid_phase
        frame = state.level.chasing_meteoroid_frame
        lane = state.level.chasing_meteoroid_lane
        side = state.level.chasing_meteoroid_side
        spawn_timer = state.level.chasing_meteoroid_spawn_timer
        remaining = state.level.chasing_meteoroid_remaining
        wave_active = state.level.chasing_meteoroid_wave_active

        is_sector_6_plus = state.sector >= 6

        rolls = jax.random.uniform(key, shape=(4,))
        start_chance_roll = rolls[0]
        side_roll = rolls[1]

        min_w = jnp.where(white_ufo_left == 0, self.consts.CHASING_METEOROID_WAVE_MIN, 1)
        max_w = jnp.where(white_ufo_left == 0, self.consts.CHASING_METEOROID_WAVE_MAX, 3)
        wave_count = jnp.floor(rolls[2] * (max_w - min_w + 1.0)).astype(jnp.int32) + min_w

        interval_min = self.consts.CHASING_METEOROID_SPAWN_INTERVAL_MIN
        interval_max = self.consts.CHASING_METEOROID_SPAWN_INTERVAL_MAX
        spawn_interval = jnp.floor(rolls[3] * (interval_max - interval_min + 1.0)).astype(jnp.int32) + interval_min

        ms_stage = state.level.mothership_stage
        ms_pos = state.level.mothership_position
        is_ltr = (state.sector % 2) != 0
        # Stop spawning if mothership surpasses 100 pixels (coming from left) or 60 pixels (coming from right)
        ms_too_far = jnp.where(is_ltr, ms_pos > 100, ms_pos < 60)

        # Stop spawning if mothership is descending (3) or exploding (5)
        # This ensures they finish their tracing before the mothership disappears.
        can_spawn_in_ms = (white_ufo_left == 0) & (ms_stage < 3) & jnp.logical_not(ms_too_far)

        # Trigger waves of chasing meteoroids:
        # 1. Periodically when all UFOs are cleared (all sectors)
        # 2. Periodically during normal play (Sector 6+)
        # Frequency for normal gameplay: 0.0021 probability per frame (~once per 8 seconds).
        # Clear-UFO waves are more frequent: 0.05 probability per frame.
        start_chance = jnp.where(can_spawn_in_ms, 0.05, jnp.where(is_sector_6_plus & (white_ufo_left > 0), 0.0021, 0.0))

        start_wave = jnp.logical_and(
            start_chance_roll < start_chance,
            jnp.logical_not(wave_active)
        )

        wave_active = jnp.where(start_wave, True, wave_active)

        remaining = jnp.where(start_wave, wave_count, remaining)
        spawn_timer = jnp.where(start_wave, 0, spawn_timer)

        # Reset wave state when moving to a sector where they shouldn't appear normally,
        # and UFOs are present.
        should_cancel = jnp.logical_and(jnp.logical_not(is_sector_6_plus), white_ufo_left > 0)
        # Also stop spawning waves if it's too late in the Mothership phase
        should_cancel = jnp.logical_or(should_cancel, (white_ufo_left == 0) & (ms_stage >= 3))
        should_cancel = jnp.logical_or(should_cancel, (white_ufo_left == 0) & ms_too_far)

        # Also reset wave_active when finished so it can repeat.
        wave_finished = wave_active & (remaining == 0) & jnp.all(jnp.logical_not(active))

        wave_active = jnp.where(should_cancel | wave_finished, False, wave_active)
        remaining = jnp.where(should_cancel, 0, remaining)
        spawn_timer = jnp.where(should_cancel, 0, spawn_timer)

        spawn_timer = jnp.where(
            jnp.logical_and(wave_active, remaining > 0),
            jnp.maximum(spawn_timer - 1, 0),
            spawn_timer,
        )

        should_spawn = jnp.logical_and.reduce(jnp.array([
            wave_active,
            remaining > 0,
            spawn_timer == 0,
        ]))
        has_slot = jnp.any(jnp.logical_not(active))
        should_spawn = jnp.logical_and(should_spawn, has_slot)

        spawn_side = jnp.where(side_roll < 0.5, 1, -1)
        spawn_x = jnp.where(
            spawn_side == 1,
            float(self.consts.LEFT_CLIP_PLAYER),
            float(self.consts.RIGHT_CLIP_PLAYER),
        )
        spawn_y = float(self.consts.CHASING_METEOROID_SPAWN_Y)

        inactive_mask = jnp.logical_not(active)
        slot = jnp.argmax(inactive_mask)
        one_hot = jax.nn.one_hot(slot, self.consts.CHASING_METEOROID_MAX, dtype=pos.dtype)
        one_hot_bool = one_hot.astype(jnp.bool_)

        spawn_pos = jnp.array([spawn_x, spawn_y], dtype=pos.dtype)
        pos_spawned = pos + (spawn_pos[:, None] - pos) * one_hot[None, :]
        active_spawned = jnp.where(one_hot_bool, True, active)
        vel_y_spawned = jnp.where(one_hot_bool, 0.0, vel_y)
        phase_spawned = jnp.where(one_hot_bool, 0, phase)
        frame_spawned = jnp.where(one_hot_bool, 0, frame)
        lane_spawned = jnp.where(one_hot_bool, 0, lane)
        side_spawned = jnp.where(one_hot_bool, spawn_side, side)

        pos = jnp.where(should_spawn, pos_spawned, pos)
        active = jnp.where(should_spawn, active_spawned, active)
        vel_y = jnp.where(should_spawn, vel_y_spawned, vel_y)
        phase = jnp.where(should_spawn, phase_spawned, phase)
        frame = jnp.where(should_spawn, frame_spawned, frame)
        lane = jnp.where(should_spawn, lane_spawned, lane)
        side = jnp.where(should_spawn, side_spawned, side)
        remaining = jnp.where(should_spawn, remaining - 1, remaining)
        spawn_timer = jnp.where(should_spawn, spawn_interval, spawn_timer)

        cycle_dx = self.chasing_meteoroid_cycle_dx
        cycle_dy = self.chasing_meteoroid_cycle_dy
        dy_a = jnp.take(cycle_dy, frame)
        new_y_a = pos[1] + dy_a

        lane_vectors = self.lane_vectors_t2b
        lanes_top_x = self.top_lanes_x
        lane_dx_over_dy = self.lane_dx_over_dy

        lane_x_at_current_y = lanes_top_x[:, None] + lane_dx_over_dy[:, None] * (
            new_y_a[None, :] - float(self.consts.TOP_CLIP)
        )
        dx_dir = side.astype(pos.dtype)
        dx = jnp.take(cycle_dx, frame) * dx_dir
        new_x_a = pos[0] + dx

        new_vel_y = vel_y + self.consts.CHASING_METEOROID_ACCEL
        new_y_b = pos[1] + new_vel_y
        lane_x_at_y = lanes_top_x[:, None] + lane_dx_over_dy[:, None] * (
            new_y_b[None, :] - float(self.consts.TOP_CLIP)
        )
        lane_x_b = jnp.take_along_axis(lane_x_at_y, lane[None, :], axis=0).squeeze(0)
        new_x_b = lane_x_b

        phase_descend = phase == 2
        phase_horizontal = jnp.logical_not(phase_descend)
        new_x = jnp.where(phase_descend, new_x_b, new_x_a)
        new_y = jnp.where(phase_descend, new_y_b, new_y_a)

        player_left = player_x
        player_right = player_x + float(self.consts.PLAYER_SPRITE_SIZE[1])
        align_x = _get_ufo_alignment(new_y_a).astype(new_x_a.dtype)
        aligned_x_a = new_x_a + align_x
        chasing_meteoroid_left = aligned_x_a
        chasing_meteoroid_right = aligned_x_a + float(self.consts.METEOROID_SPRITE_SIZE[1])
        hits_x = jnp.logical_and(chasing_meteoroid_right >= player_left, chasing_meteoroid_left <= player_right)
        player_center = player_x + float(self.consts.PLAYER_SPRITE_SIZE[1]) / 2.0
        bottom_lanes = self.bottom_lanes
        nearest_lane_idx = jnp.argmin(jnp.abs(bottom_lanes - player_center)).astype(jnp.int32)

        # Consider only inner 5 lanes (indices 1-5 in TOP_OF_LANES)
        # playable_lanes_x shape: (5, N)
        playable_lanes_x = lane_x_at_current_y[1:6]

        # Alignment check for all 5 inner lanes
        # dist_to_lanes shape: (5, N)
        dist_to_lanes = jnp.abs(playable_lanes_x - new_x_a[None, :])
        is_aligned = dist_to_lanes <= float(self.consts.CHASING_METEOROID_LANE_ALIGN_THRESHOLD)

        # Valid drop logic:
        # Lane index i (0..4) corresponds to Lanes 1..5
        # Drop if:
        #   Moving Right (side > 0) AND (Lane >= PlayerLane OR Lane == 4 (Last))
        #   Moving Left  (side < 0) AND (Lane <= PlayerLane OR Lane == 0 (Last))
        # Note: PlayerLane is 0..4 relative to inner lanes.
        # "Lane >= PlayerLane" covers "Lane == 4" if PlayerLane <= 4 (always true).

        lane_indices = jnp.arange(5)[:, None] # (5, 1)

        # Broadcase side and player_lane
        # side: (N,), nearest_lane_idx: scalar
        side_broad = side[None, :]
        player_idx_broad = nearest_lane_idx

        should_drop_right = (side_broad > 0) & (lane_indices >= player_idx_broad)
        should_drop_left = (side_broad < 0) & (lane_indices <= player_idx_broad)

        # Force drop at boundaries if somehow passed?
        # Actually, "latest at lane 5" means if we are AT lane 5 (index 4) and moving right, we MUST drop.
        # indices >= player_idx includes 4 (since player_idx <= 4).
        # So checking >= player is sufficient to cover "next lane" and "last lane".

        is_valid_drop_lane = should_drop_right | should_drop_left

        # Valid trigger mask: (5, N)
        trigger_mask = is_aligned & is_valid_drop_lane

        # Check if ANY lane triggers for each meteoroid
        should_descend = jnp.any(trigger_mask, axis=0)

        # Identify WHICH lane to drop on.
        # If multiple align (unlikely), pick the one that triggered.
        # We can use argmax to get the index.
        # If none, argmax returns 0, but should_descend will be False so it doesn't matter.
        target_lane_idx_0_4 = jnp.argmax(trigger_mask, axis=0).astype(jnp.int32)

        # Map back to 1-5
        chosen_lane = target_lane_idx_0_4 + 1

        # State transition
        # If active & phase==0 & should_descend -> Start Phase 2 directly?
        # Or Phase 1 then 2?
        # Original code: Phase 0 -> Phase 1 (Arm) -> Phase 2 (Descend if on lane).
        # Since we confirmed "is_aligned" above, we are "on lane". We can descend immediately.

        start_descend_now = active & (phase == 0) & should_descend

        new_phase = jnp.where(start_descend_now, 2, phase)
        new_lane = jnp.where(start_descend_now, chosen_lane, lane)

        # Update target X to lock onto the chosen lane center perfectly (optional but cleaner)
        # target_lane_x_final = jnp.take_along_axis(lane_x_at_current_y, new_lane[None, :], axis=0).squeeze(0)
        # new_x = jnp.where(start_descend_now, target_lane_x_final, new_x)
        # (For now keeping original movement logic to preserve momentum/physics unless requested otherwise)

        # Legacy compatibility: if phase was 1, check if aligned with *current* lane
        # lane is 1-5. Index is lane-1.
        current_lane_idx = jnp.clip(lane - 1, 0, 4)
        current_lane_x = playable_lanes_x[current_lane_idx, jnp.arange(self.consts.CHASING_METEOROID_MAX)]
        is_on_current_lane = jnp.abs(current_lane_x - new_x_a) <= float(self.consts.CHASING_METEOROID_LANE_ALIGN_THRESHOLD)

        start_descend = start_descend_now | ((phase == 1) & is_on_current_lane)
        new_phase = jnp.where(start_descend, 2, new_phase)

        # When starting descend, initialize velocity
        new_vel_y = jnp.where(start_descend, float(self.consts.CHASING_METEOROID_LANE_SPEED), vel_y)
        # Apply acceleration if already descending
        new_vel_y = jnp.where(phase_descend, vel_y + self.consts.CHASING_METEOROID_ACCEL, new_vel_y)

        new_frame = jnp.where(phase_horizontal, (frame + 1) % 8, frame)
        new_frame = jnp.where(start_descend, 0, new_frame)

        new_pos = jnp.stack([new_x, new_y])
        offscreen = self.enemy_offscreen
        new_pos = jnp.where(active[None, :], new_pos, offscreen[:, None])

        out_of_bounds = jnp.logical_and(
            active,
            jnp.logical_or(new_x < 0.0, new_x > float(self.consts.SCREEN_WIDTH)),
        )
        new_active = jnp.where(out_of_bounds, False, active)
        new_pos = jnp.where(new_active[None, :], new_pos, offscreen[:, None])
        new_vel_y = jnp.where(new_active, new_vel_y, 0.0)
        new_phase = jnp.where(new_active, new_phase, 0)
        new_frame = jnp.where(new_active, new_frame, 0)
        new_lane = jnp.where(new_active, new_lane, 0)
        new_side = jnp.where(new_active, side, 1)

        return (
            new_pos,
            new_active,
            new_vel_y,
            new_phase,
            new_frame,
            new_lane,
            new_side,
            spawn_timer,
            remaining,
            wave_active,
        )

    def _chasing_meteoroid_bullet_collision(
        self,
        chasing_meteoroid_pos: chex.Array,
        chasing_meteoroid_active: chex.Array,
        chasing_meteoroid_vel_y: chex.Array,
        chasing_meteoroid_phase: chex.Array,
        chasing_meteoroid_frame: chex.Array,
        chasing_meteoroid_lane: chex.Array,
        chasing_meteoroid_side: chex.Array,
        player_shot_pos: chex.Array,
        white_ufo_left: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array,
        is_torpedo: chex.Array
    ):
        shot_y = player_shot_pos[1]

        chasing_meteoroid_x = chasing_meteoroid_pos[0] + _get_ufo_alignment(chasing_meteoroid_pos[1]).astype(
            chasing_meteoroid_pos.dtype)
        chasing_meteoroid_y = chasing_meteoroid_pos[1]

        meteoroid_size = self.meteoroid_sprite_size

        is_near = chasing_meteoroid_active & shot_active & (jnp.abs(chasing_meteoroid_y - shot_y) <= 16.0)

        # AABB collision check
        collision_mask = (
                is_near
                & (chasing_meteoroid_x < shot_x + bullet_size[1]) & (shot_x < chasing_meteoroid_x + meteoroid_size[1])
                & (chasing_meteoroid_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0]) & (
                            shot_y < chasing_meteoroid_y + meteoroid_size[0])
        )

        # Meteoroid is only destroyed if it's hit by a torpedo
        hit_mask = collision_mask & is_torpedo

        hit_exists_meteoroid = jnp.any(hit_mask)
        collision_exists = jnp.any(collision_mask)

        hit_index = jnp.argmax(hit_mask)
        hit_one_hot = jax.nn.one_hot(hit_index, self.consts.CHASING_METEOROID_MAX, dtype=chasing_meteoroid_pos.dtype)
        hit_one_hot_bool = hit_one_hot.astype(jnp.bool_)

        offscreen = self.enemy_offscreen
        pos_after_hit = chasing_meteoroid_pos + (offscreen[:, None] - chasing_meteoroid_pos) * hit_one_hot[None, :]
        active_after_hit = jnp.where(hit_one_hot_bool, False, chasing_meteoroid_active)
        vel_y_after_hit = jnp.where(hit_one_hot_bool, 0.0, chasing_meteoroid_vel_y)
        phase_after_hit = jnp.where(hit_one_hot_bool, 0, chasing_meteoroid_phase)
        frame_after_hit = jnp.where(hit_one_hot_bool, 0, chasing_meteoroid_frame)
        lane_after_hit = jnp.where(hit_one_hot_bool, 0, chasing_meteoroid_lane)
        side_after_hit = jnp.where(hit_one_hot_bool, 1, chasing_meteoroid_side)

        chasing_meteoroid_pos = jnp.where(hit_exists_meteoroid, pos_after_hit, chasing_meteoroid_pos)
        chasing_meteoroid_active = jnp.where(hit_exists_meteoroid, active_after_hit, chasing_meteoroid_active)
        chasing_meteoroid_vel_y = jnp.where(hit_exists_meteoroid, vel_y_after_hit, chasing_meteoroid_vel_y)
        chasing_meteoroid_phase = jnp.where(hit_exists_meteoroid, phase_after_hit, chasing_meteoroid_phase)
        chasing_meteoroid_frame = jnp.where(hit_exists_meteoroid, frame_after_hit, chasing_meteoroid_frame)
        chasing_meteoroid_lane = jnp.where(hit_exists_meteoroid, lane_after_hit, chasing_meteoroid_lane)
        chasing_meteoroid_side = jnp.where(hit_exists_meteoroid, side_after_hit, chasing_meteoroid_side)

        # Shot is removed if it hits a meteoroid (blocking behavior)
        player_shot_pos = jnp.where(
            collision_exists,
            self.bullet_offscreen,
            player_shot_pos,
        )

        return (
            chasing_meteoroid_pos,
            chasing_meteoroid_active,
            chasing_meteoroid_vel_y,
            chasing_meteoroid_phase,
            chasing_meteoroid_frame,
            chasing_meteoroid_lane,
            chasing_meteoroid_side,
            player_shot_pos,
            hit_mask,
            hit_exists_meteoroid,
            collision_exists
        )

    def _rejuvenator_step(self, state: BeamriderState, key: chex.Array):
        pos = state.level.rejuvenator_pos
        active = state.level.rejuvenator_active
        dead = state.level.rejuvenator_dead
        frame = state.level.rejuvenator_frame
        lane = state.level.rejuvenator_lane
        mothership_active = state.level.mothership_stage > 0

        rolls = jax.random.uniform(key, shape=(2,))
        spawn_roll = rolls[0]
        spawn_lane = jnp.floor(rolls[1] * 5.0).astype(jnp.int32) + 1

        # Spawning logic: only spawn if not already active
        should_spawn = jnp.logical_and.reduce(jnp.array([
            jnp.logical_not(active),
            jnp.logical_not(mothership_active),
            spawn_roll < self.consts.REJUVENATOR_SPAWN_PROB,
            state.level.white_ufo_left > 0
        ]))

        spawn_x = self.top_lanes_x[spawn_lane]
        spawn_y = float(self.consts.TOP_CLIP)

        pos = jnp.where(should_spawn, jnp.array([spawn_x, spawn_y]), pos)
        lane = jnp.where(should_spawn, spawn_lane, lane)
        active = jnp.where(should_spawn, True, active)
        dead = jnp.where(should_spawn, False, dead)
        frame = jnp.where(should_spawn, 0, frame)

        # Movement logic:
        # Phase 1: pixel moves alternate 2 and 4 frames (dy=1)
        # Phase 2: moves every 2 frames (dy=1)
        # Phase 3: moves every 2 frames, cyclic dy [1, 1, 2]
        # Phase 4: moves every 2 frames, cyclic dy [2, 3]
        # Dead: always every frame (dy based on current stage or 1.0)
        y = pos[1]
        stage = _get_index_rejuvenator(y)

        should_move_normal = jax.lax.switch(
            jnp.clip(stage - 1, 0, 3),
            [
                lambda: (state.steps % 6 == 0) | (state.steps % 6 == 2), # Phase 1
                lambda: (state.steps % 2) == 0,                         # Phase 2
                lambda: (state.steps % 2) == 0,                         # Phase 3
                lambda: (state.steps % 2) == 0,                         # Phase 4
            ]
        )

        should_move = jnp.logical_and(active, jnp.where(dead, True, should_move_normal))

        # dy logic:
        dy = jax.lax.switch(
            jnp.clip(stage - 1, 0, 3),
            [
                lambda: 1.0,                                       # Phase 1
                lambda: 1.0,                                       # Phase 2
                lambda: jnp.take(jnp.array([1.0, 1.0, 2.0]), frame % 3), # Phase 3: 1, 1, 2
                lambda: jnp.take(jnp.array([2.0, 3.0]), frame % 2),     # Phase 4: 2, 3
            ]
        )

        new_y = y + jnp.where(should_move, dy, 0.0)
        new_x = jnp.take(self.top_lanes_x, lane) + jnp.take(self.lane_dx_over_dy, lane) * (
                    new_y - float(self.consts.TOP_CLIP))

        pos = jnp.where(active, jnp.array([new_x, new_y]), pos)
        frame = jnp.where(should_move, frame + 1, frame)

        # Deactivate if off-screen
        off_screen = new_y > self.consts.PLAYER_POS_Y + 1.0
        active = jnp.where(off_screen, False, active)
        offscreen_pos = self.enemy_offscreen
        pos = jnp.where(active, jnp.array([new_x, new_y]), offscreen_pos)

        return pos, active, dead, frame, lane

    def _falling_rock_step(self, state: BeamriderState, key: chex.Array):
        pos = state.level.falling_rock_pos
        active = state.level.falling_rock_active
        lane = state.level.falling_rock_lane
        vel_y = state.level.falling_rock_vel_y
        mothership_active = state.level.mothership_stage > 0

        rolls = jax.random.uniform(key, shape=(2,))
        spawn_roll = rolls[0]
        spawn_lane = jnp.floor(rolls[1] * 5.0).astype(jnp.int32) + 1

        # Spawning logic: Level 2 onwards
        is_level_2_plus = state.sector >= 2
        can_spawn = jnp.logical_and.reduce(jnp.array([
            is_level_2_plus,
            jnp.sum(active, dtype=jnp.int32) < self.consts.FALLING_ROCK_MAX,
            jnp.logical_not(mothership_active),
            state.level.white_ufo_left > 0
        ]))
        should_spawn = jnp.logical_and(can_spawn, spawn_roll < self.consts.FALLING_ROCK_SPAWN_PROB)

        inactive_mask = jnp.logical_not(active)
        slot = jnp.argmax(inactive_mask)
        one_hot = jax.nn.one_hot(slot, self.consts.FALLING_ROCK_MAX, dtype=pos.dtype)
        one_hot_bool = one_hot.astype(jnp.bool_)

        lanes_top_x = self.top_lanes_x
        spawn_x = lanes_top_x[spawn_lane]
        spawn_y = float(self.consts.FALLING_ROCK_SPAWN_Y)
        spawn_pos = jnp.array([spawn_x, spawn_y], dtype=pos.dtype)

        pos = jnp.where(should_spawn, pos + (spawn_pos[:, None] - pos) * one_hot[None, :], pos)
        active = jnp.where(should_spawn, jnp.where(one_hot_bool, True, active), active)
        lane = jnp.where(should_spawn, jnp.where(one_hot_bool, spawn_lane, lane), lane)
        vel_y = jnp.where(should_spawn, jnp.where(one_hot_bool, self.consts.FALLING_ROCK_INIT_VEL, vel_y), vel_y)

        # Movement logic: Stage-based acceleration
        # Slower during sprite 1 (y < 64) and 2 (y < 85)
        y = pos[1]
        accel = jnp.where(y < 64, 0.004,
                          jnp.where(y < 85, 0.008,
                                    self.consts.FALLING_ROCK_ACCEL))

        new_vel_y = vel_y + accel
        new_y = y + new_vel_y

        # Update X to stay centered on lane
        lane_dx_over_dy = self.lane_dx_over_dy

        target_lane_dx_over_dy = jnp.take(lane_dx_over_dy, lane)
        target_lanes_top_x = jnp.take(lanes_top_x, lane)
        new_x = target_lanes_top_x + target_lane_dx_over_dy * (new_y - float(self.consts.TOP_CLIP))

        pos = jnp.where(active[None, :], jnp.stack([new_x, new_y]), pos)
        vel_y = jnp.where(active, new_vel_y, vel_y)

        # Deactivate if off-screen
        off_screen = new_y > self.consts.FALLING_ROCK_BOTTOM_CLIP
        active = jnp.where(off_screen, False, active)
        offscreen_pos = self.enemy_offscreen_falling
        pos = jnp.where(active[None, :], pos, offscreen_pos)
        vel_y = jnp.where(active, vel_y, 0.0)

        return pos, active, lane, vel_y

    def _coin_step(self, state: BeamriderState, key: chex.Array):
        pos = state.level.coin_pos
        active = state.level.coin_active
        timer = state.level.coin_timer
        side = state.level.coin_side
        spawn_count = state.level.coin_spawn_count
        mothership_active = state.level.mothership_stage > 0

        rolls = jax.random.uniform(key, shape=(2,))

        # Spawning logic: Sector 4 onwards
        is_sector_4_plus = state.sector >= 4
        can_spawn = jnp.logical_and.reduce(jnp.array([
            is_sector_4_plus,
            jnp.sum(active, dtype=jnp.int32) < self.consts.COIN_MAX,
            jnp.logical_not(mothership_active),
            state.level.white_ufo_left > 0,
        ]))

        should_spawn = jnp.logical_and(can_spawn, rolls[0] < self.consts.COIN_SPAWN_PROB)

        # 50/50 chance for side choice: 0 for Left, 1 for Right
        spawn_side_idx = (rolls[1] < 0.5).astype(jnp.int32)

        spawn_x = jnp.where(spawn_side_idx == 0, self.consts.COIN_SPAWN_X_LEFT, self.consts.COIN_SPAWN_X_RIGHT)
        spawn_y = self.consts.COIN_SPAWN_Y
        spawn_pos = jnp.array([spawn_x, spawn_y], dtype=pos.dtype)

        # Find first inactive slot
        inactive_mask = jnp.logical_not(active)
        slot = jnp.argmax(inactive_mask)
        one_hot = jax.nn.one_hot(slot, self.consts.COIN_MAX, dtype=pos.dtype)
        one_hot_bool = one_hot.astype(jnp.bool_)

        pos = jnp.where(should_spawn, pos + (spawn_pos[:, None] - pos) * one_hot[None, :], pos)
        active = jnp.where(should_spawn, jnp.where(one_hot_bool, True, active), active)
        side = jnp.where(should_spawn, jnp.where(one_hot_bool, spawn_side_idx, side), side)
        timer = jnp.where(should_spawn, jnp.where(one_hot_bool, 0, timer), timer)
        spawn_count = jnp.where(should_spawn, spawn_count + 1, spawn_count)

        # Movement logic: every second frame
        should_move = (state.steps % 2 == 0)

        # side == 0 (Left start) -> moves Right (DX > 0)
        # side == 1 (Right start) -> moves Left (DX < 0)
        dx = jnp.where(side == 0, self.consts.COIN_SPEED_X, -self.consts.COIN_SPEED_X)
        dy = self.consts.COIN_SPEED_Y

        new_x = pos[0] + jnp.where(should_move, dx, 0.0)
        new_y = pos[1] + jnp.where(should_move, dy, 0.0)

        pos = jnp.where(active[None, :], jnp.stack([new_x, new_y]), pos)
        timer = jnp.where(active, timer + 1, timer) # timer increments every frame for animation

        # Deactivate if off-screen (Y >= 95)
        off_screen = pos[1] >= self.consts.COIN_EXIT_Y
        active = jnp.where(off_screen, False, active)
        offscreen_pos = self.enemy_offscreen_coins
        pos = jnp.where(active[None, :], pos, offscreen_pos)

        return pos, active, timer, side, spawn_count

    def _coin_bullet_collision(
        self,
        coin_pos: chex.Array,
        coin_active: chex.Array,
        player_shot_pos: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array
    ):
        shot_y = player_shot_pos[1]

        coin_x_screen = coin_pos[0] + _get_ufo_alignment(coin_pos[1]).astype(coin_pos.dtype)
        coin_y = coin_pos[1]

        is_near = coin_active & shot_active & (jnp.abs(coin_y - shot_y) <= 16.0)

        coin_size = self.coin_sprite_size

        # AABB collision check
        hit_mask = (
                is_near
                & (coin_x_screen < shot_x + bullet_size[1]) & (shot_x < coin_x_screen + coin_size[1])
                & (coin_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0]) & (
                            shot_y < coin_y + coin_size[0])
        )
        hit_exists = jnp.any(hit_mask)

        return hit_mask, hit_exists

    def _falling_rock_bullet_collision(
        self,
        falling_rock_pos: chex.Array,
        falling_rock_active: chex.Array,
        player_shot_pos: chex.Array,
        white_ufo_left: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array,
        is_torpedo: chex.Array
    ):
        shot_y = player_shot_pos[1]

        rock_x = falling_rock_pos[0] + _get_ufo_alignment(falling_rock_pos[1]).astype(falling_rock_pos.dtype)
        rock_y = falling_rock_pos[1]

        is_near = falling_rock_active & shot_active & (jnp.abs(rock_y - shot_y) <= 16.0)

        rock_indices = jnp.clip(_get_index_falling_rock(rock_y) - 1, 0, len(self.consts.FALLING_ROCK_SPRITE_SIZES) - 1)
        rock_sizes = jnp.take(self.falling_rock_sprite_sizes, rock_indices, axis=0)

        # AABB collision check
        hit_mask = (
                is_near
                & (rock_x < shot_x + bullet_size[1]) & (shot_x < rock_x + rock_sizes[:, 1])
                & (rock_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0]) & (
                            shot_y < rock_y + rock_sizes[:, 0])
        )
        hit_exists_rock = jnp.any(hit_mask)

        # Rock is only destroyed by torpedo
        rock_should_die = hit_mask & is_torpedo

        offscreen = self.enemy_offscreen_falling
        pos = jnp.where(rock_should_die[None, :], offscreen, falling_rock_pos)
        active = jnp.where(rock_should_die, False, falling_rock_active)

        player_shot_pos = jnp.where(
            hit_exists_rock,
            self.bullet_offscreen,
            player_shot_pos,
        )

        return pos, active, player_shot_pos, rock_should_die, hit_exists_rock

    def _lane_blocker_step(self, state: BeamriderState, key: chex.Array):
        pos = state.level.lane_blocker_pos
        active = state.level.lane_blocker_active
        lane = state.level.lane_blocker_lane
        vel_y = state.level.lane_blocker_vel_y
        phase = state.level.lane_blocker_phase
        hold_timer = state.level.lane_blocker_timer
        mothership_active = state.level.mothership_stage > 0

        rolls = jax.random.uniform(key, shape=(2,))
        spawn_roll = rolls[0]

        lane_idx = jnp.floor(rolls[1] * 3.0).astype(jnp.int32)
        middle_lanes = self.middle_lane_spawn
        spawn_lane = middle_lanes[lane_idx]

        is_level_10_plus = state.sector >= self.consts.LANE_BLOCKER_START_LEVEL
        can_spawn = jnp.logical_and.reduce(jnp.array([
            is_level_10_plus,
            jnp.sum(active, dtype=jnp.int32) < self.consts.LANE_BLOCKER_MAX,
            jnp.logical_not(mothership_active),
            state.level.white_ufo_left > 0
        ]))
        should_spawn = jnp.logical_and(can_spawn, spawn_roll < self.consts.LANE_BLOCKER_SPAWN_PROB)

        # Find first inactive slot
        inactive_mask = jnp.logical_not(active)
        slot = jnp.argmax(inactive_mask)
        one_hot = jax.nn.one_hot(slot, self.consts.LANE_BLOCKER_MAX, dtype=pos.dtype)
        one_hot_bool = one_hot.astype(jnp.bool_)

        lanes_top_x = self.top_lanes_x
        spawn_x = lanes_top_x[spawn_lane]
        spawn_y = float(self.consts.LANE_BLOCKER_SPAWN_Y)
        spawn_pos = jnp.array([spawn_x, spawn_y], dtype=pos.dtype)

        pos = jnp.where(should_spawn, pos + (spawn_pos[:, None] - pos) * one_hot[None, :], pos)
        active = jnp.where(should_spawn, jnp.where(one_hot_bool, True, active), active)
        lane = jnp.where(should_spawn, jnp.where(one_hot_bool, spawn_lane, lane), lane)
        vel_y = jnp.where(should_spawn, jnp.where(one_hot_bool, self.consts.LANE_BLOCKER_INIT_VEL, vel_y), vel_y)
        phase = jnp.where(should_spawn, jnp.where(one_hot_bool, int(LaneBlockerState.DESCEND), phase), phase)
        hold_timer = jnp.where(should_spawn, jnp.where(one_hot_bool, 0, hold_timer), hold_timer)

        y = pos[1]
        bottom_y = float(self.consts.LANE_BLOCKER_BOTTOM_Y)

        descend = active & (phase == int(LaneBlockerState.DESCEND))
        hold = active & (phase == int(LaneBlockerState.HOLD))
        sink = active & (phase == int(LaneBlockerState.SINK))
        retreat = active & (phase == int(LaneBlockerState.RETREAT))

        accel = jnp.where(y < 64, 0.004,
                jnp.where(y < 85, 0.008,
                self.consts.FALLING_ROCK_ACCEL))
        new_vel_y = vel_y + accel
        new_y_descend = y + new_vel_y
        reached_bottom = new_y_descend >= bottom_y
        y_descend = jnp.where(reached_bottom, bottom_y, new_y_descend)
        vel_descend = jnp.where(reached_bottom, 0.0, new_vel_y)
        phase_descend = jnp.where(reached_bottom, int(LaneBlockerState.HOLD), int(LaneBlockerState.DESCEND))
        hold_timer_descend = jnp.where(reached_bottom, self.consts.LANE_BLOCKER_HOLD_FRAMES, hold_timer)

        hold_timer_next = jnp.maximum(hold_timer - 1, 0)
        start_sink = hold_timer_next == 0
        phase_hold = jnp.where(start_sink, int(LaneBlockerState.SINK), int(LaneBlockerState.HOLD))

        sink_step = (state.steps % self.consts.LANE_BLOCKER_SINK_INTERVAL) == 0
        sink_dy = jnp.where(sink_step, 1.0, 0.0)
        y_sink = y + sink_dy

        lane_vectors = self.lane_vectors_t2b
        retreat_speed = lane_vectors[:, 1] * self.consts.WHITE_UFO_SPEED_FACTOR * self.consts.WHITE_UFO_RETREAT_SPEED_MULT
        retreat_speed = retreat_speed * self.consts.LANE_BLOCKER_RETREAT_SPEED_MULT
        lane_retreat_speed = jnp.take(retreat_speed, lane)
        y_retreat = y - lane_retreat_speed

        new_y = jnp.where(descend, y_descend, y)
        new_y = jnp.where(hold, bottom_y, new_y)
        new_y = jnp.where(sink, y_sink, new_y)
        new_y = jnp.where(retreat, y_retreat, new_y)

        new_vel_y = vel_y
        new_vel_y = jnp.where(descend, vel_descend, new_vel_y)
        new_vel_y = jnp.where(hold | sink | retreat, 0.0, new_vel_y)

        new_phase = phase
        new_phase = jnp.where(descend, phase_descend, new_phase)
        new_phase = jnp.where(hold, phase_hold, new_phase)
        new_phase = jnp.where(sink, int(LaneBlockerState.SINK), new_phase)
        new_phase = jnp.where(retreat, int(LaneBlockerState.RETREAT), new_phase)

        new_timer = hold_timer
        new_timer = jnp.where(descend, hold_timer_descend, new_timer)
        new_timer = jnp.where(hold, hold_timer_next, new_timer)
        new_timer = jnp.where(sink | retreat, 0, new_timer)

        lane_dx_over_dy = self.lane_dx_over_dy
        target_lane_dx_over_dy = jnp.take(lane_dx_over_dy, lane)
        target_lanes_top_x = jnp.take(self.top_lanes_x, lane)
        new_x = target_lanes_top_x + target_lane_dx_over_dy * (new_y - float(self.consts.TOP_CLIP))

        offscreen_pos = self.enemy_offscreen_lane_blocker
        retreat_done = retreat & (new_y <= float(self.consts.LANE_BLOCKER_SPAWN_Y))
        sink_done = sink & ((new_y - bottom_y) >= float(self.consts.LANE_BLOCKER_HEIGHT))
        done = retreat_done | sink_done

        active = jnp.where(done, False, active)
        new_phase = jnp.where(done, int(LaneBlockerState.DESCEND), new_phase)
        new_timer = jnp.where(done, 0, new_timer)
        new_vel_y = jnp.where(done, 0.0, new_vel_y)

        pos = jnp.where(active[None, :], jnp.stack([new_x, new_y]), offscreen_pos)
        new_vel_y = jnp.where(active, new_vel_y, 0.0)

        return pos, active, lane, new_vel_y, new_phase, new_timer

    def _lane_blocker_bullet_collision(
        self,
        lane_blocker_pos: chex.Array,
        lane_blocker_active: chex.Array,
        lane_blocker_phase: chex.Array,
        lane_blocker_timer: chex.Array,
        lane_blocker_vel_y: chex.Array,
        player_shot_pos: chex.Array,
        white_ufo_left: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array,
        is_torpedo: chex.Array
    ):
        shot_y = player_shot_pos[1]

        blocker_x = lane_blocker_pos[0] + _get_ufo_alignment(lane_blocker_pos[1]).astype(lane_blocker_pos.dtype)
        blocker_y = lane_blocker_pos[1]

        is_near = lane_blocker_active & shot_active & (jnp.abs(blocker_y - shot_y) <= 16.0)

        blocker_indices = jnp.clip(_get_index_lane_blocker(blocker_y) - 1, 0, len(self.consts.LANE_BLOCKER_SPRITE_SIZES) - 1)
        blocker_indices = jnp.where(blocker_indices == 2, 3, blocker_indices)
        blocker_sizes = jnp.take(self.lane_blocker_sprite_sizes, blocker_indices, axis=0)

        hit_mask = (
                is_near
                & (blocker_x < shot_x + bullet_size[1]) & (shot_x < blocker_x + blocker_sizes[:, 1])
                & (blocker_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0]) & (
                            shot_y < blocker_y + blocker_sizes[:, 0])
        )
        hit_exists = jnp.any(hit_mask)

        blocker_destroyed = hit_mask & is_torpedo
        blocker_retreat = hit_mask & jnp.logical_not(is_torpedo)

        offscreen = self.enemy_offscreen_lane_blocker
        pos = jnp.where(blocker_destroyed[None, :], offscreen, lane_blocker_pos)
        active = jnp.where(blocker_destroyed, False, lane_blocker_active)

        phase = jnp.where(blocker_retreat, int(LaneBlockerState.RETREAT), lane_blocker_phase)
        phase = jnp.where(blocker_destroyed, int(LaneBlockerState.DESCEND), phase)
        timer = jnp.where(blocker_retreat, 0, lane_blocker_timer)
        timer = jnp.where(blocker_destroyed, 0, timer)
        vel_y = jnp.where(blocker_retreat, 0.0, lane_blocker_vel_y)
        vel_y = jnp.where(blocker_destroyed, 0.0, vel_y)

        player_shot_pos = jnp.where(
            hit_exists,
            self.bullet_offscreen,
            player_shot_pos,
        )

        return pos, active, phase, timer, vel_y, player_shot_pos, blocker_destroyed, hit_exists

    def _enemy_shot_bullet_collision(
        self,
        enemy_shot_pos: chex.Array,
        enemy_shot_timer: chex.Array,
        player_shot_pos: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array,
        is_torpedo: chex.Array
    ):
        shot_y = player_shot_pos[1]
        enemy_shot_y = enemy_shot_pos[1, :]
        shot_on_screen = enemy_shot_y <= float(self.consts.BOTTOM_CLIP)

        is_near = shot_on_screen & shot_active & (jnp.abs(enemy_shot_y - shot_y) <= 16.0)

        enemy_shot_x = enemy_shot_pos[0, :] + _get_ufo_alignment(enemy_shot_pos[1, :])
        sprite_idx = (jnp.floor_divide(enemy_shot_timer, 4) % 2).astype(jnp.int32)
        enemy_shot_sizes = jnp.take(self.enemy_shot_sprite_sizes, sprite_idx, axis=0)

        hit_mask = (
                is_near
                & (enemy_shot_x < shot_x + bullet_size[1]) & (shot_x < enemy_shot_x + enemy_shot_sizes[:, 1])
                & (enemy_shot_y - self.consts.ENEMY_HITBOX_TOP_EXTENSION < shot_y + bullet_size[0]) & (
                            shot_y < enemy_shot_y + enemy_shot_sizes[:, 0])
        )

        # Only destroyed by torpedo
        hit_mask_torpedo = hit_mask & is_torpedo
        hit_exists = jnp.any(hit_mask_torpedo)

        return hit_mask_torpedo, hit_exists

    def _mothership_step(self, state: BeamriderState, white_ufo_left: chex.Array, enemy_explosion_frame: chex.Array, is_hit: chex.Array):
        """Spawn and move the mothership once all white UFOs are cleared."""
        stage = state.level.mothership_stage
        timer = state.level.mothership_timer
        pos_x = state.level.mothership_position
        sector = state.sector

        is_ltr = (sector % 2) != 0

        def idle_logic():
            explosions_finished = jnp.all(enemy_explosion_frame == 0)
            start = (white_ufo_left == 0) & explosions_finished
            # Start at stage 1, timer 1
            return jnp.where(start, 1, 0), jnp.where(start, 1, 0), pos_x.astype(jnp.float32)

        def emergence_logic():
            next_timer = timer + 1
            finished = next_timer > 15

            # Calculate pos_x based on timer (2..15)
            s = jnp.clip((timer - 1) // 2, 0, 6)
            rel_x = jnp.take(self.mothership_anim_x, s)
            calculated_pos = jnp.where(is_ltr, rel_x.astype(jnp.float32), (160 - 16 - rel_x + 8).astype(jnp.float32))

            return jnp.where(finished, 2, 1), jnp.where(finished, 1, next_timer), calculated_pos

        def moving_logic():
            # Interval 2, 4, 2, 4...
            # timer=2: move (after 2)
            # timer=6: move (after 4)
            # timer=8: move (after 2)
            # timer=12: move (after 4)
            # should_move if timer % 6 in {2, 0}
            should_move = (timer % 6 == 2) | (timer % 6 == 0)
            dx = jnp.where(is_ltr, 1.0, -1.0)
            next_pos_x = pos_x + jnp.where(should_move, dx, 0.0)

            stable_rel_x = self.mothership_anim_x[6]
            target_x = jnp.where(is_ltr, 160.0 - 16.0 - stable_rel_x + 8.0, stable_rel_x)
            reached = jnp.where(is_ltr, next_pos_x >= target_x, next_pos_x <= target_x)

            next_stage = jnp.where(reached, 3, 2)
            next_timer = jnp.where(reached, 1, timer + 1)

            # Transition to explosion if hit
            final_stage = jnp.where(is_hit, 5, next_stage)
            final_timer = jnp.where(is_hit, 0, next_timer)

            return final_stage, final_timer, next_pos_x

        def descending_logic():
            next_timer = timer + 1
            finished = next_timer > 15

            # Calculate pos_x based on timer (1..14)
            s = jnp.clip(6 - (timer - 1) // 2, 0, 6)
            rel_x = jnp.take(self.mothership_anim_x, s)
            # During descending, we are at the opposite side from where we started
            # If we started LTR (Left), we are now at Right.
            calculated_pos = jnp.where(is_ltr, (160 - 16 - rel_x + 8).astype(jnp.float32), rel_x.astype(jnp.float32))

            return jnp.where(finished, 4, 3), jnp.where(finished, 0, next_timer), calculated_pos

        def done_logic():
            return 0, 0, self.mothership_offscreen

        def exploding_logic():
            # 9 steps * 8 frames = 72 frames total
            duration = 9 * self.consts.MOTHERSHIP_EXPLOSION_STEP_DURATION
            finished = timer >= duration
            return jnp.where(finished, 4, 5), timer + 1, pos_x

        new_stage, new_timer, new_pos = jax.lax.switch(
            stage.astype(jnp.int32),
            [idle_logic, emergence_logic, moving_logic, descending_logic, done_logic, exploding_logic]
        )

        # Advance sector when mothership finishes descending (3->4) OR finishes exploding (5->4)
        sector_advance = (new_stage == 4)

        return new_pos, new_timer, new_stage, sector_advance



    def _line_step(self, state: BeamriderState):
        counter = state.level.blue_line_counter
        standby_phase = state.level.standby_phase
        standby_timer = state.level.standby_timer
        standby_accum = state.level.standby_accumulator
        death_timer = state.level.death_timer
        total_decel_duration = float(self.consts.DEATH_DURATION + self.consts.STANDBY_DECEL_DURATION)
        decel_timer = jnp.where(
            standby_phase == int(StandbyPhase.DECEL),
            self.consts.DEATH_DURATION + standby_timer,
            jnp.where(death_timer > 0, self.consts.DEATH_DURATION - death_timer, standby_timer),
        )
        decel_active = (standby_phase == int(StandbyPhase.DECEL)) | (
            (standby_phase == int(StandbyPhase.NONE)) & (death_timer > 0)
        )
        line_phase = jnp.where(decel_active, int(StandbyPhase.DECEL), standby_phase)

        def get_inc_normal(_):
            return 1, 0.0

        def get_inc_decel(_):
            # Speed linearly decreases from 1.0 to 0.0 over the combined decel duration.
            speed = 1.0 - (decel_timer.astype(jnp.float32) / total_decel_duration)
            speed = jnp.maximum(speed, 0.0)

            new_accum = standby_accum + speed
            inc = new_accum.astype(jnp.int32)
            rem_accum = new_accum - inc.astype(jnp.float32)
            return inc, rem_accum

        def get_inc_wait(_):
            return 0, 0.0

        inc, next_accum = jax.lax.switch(
            line_phase,
            [get_inc_normal, get_inc_decel, get_inc_wait, get_inc_normal],
            operand=None
        )

        next_counter = counter + inc

        is_init = next_counter < len(BLUE_LINE_INIT_TABLE)

        def get_init_pos(c):
            return BLUE_LINE_INIT_TABLE[jnp.minimum(c, len(BLUE_LINE_INIT_TABLE) - 1)]

        def get_loop_pos(c):
            loop_idx = (c - len(BLUE_LINE_INIT_TABLE)) % len(BLUE_LINE_LOOP_TABLE)
            return BLUE_LINE_LOOP_TABLE[loop_idx]

        positions = jax.lax.cond(is_init, get_init_pos, get_loop_pos, next_counter)

        return positions, next_counter, next_accum

    def _bullet_infos(self, state: BeamriderState):
        shot_frame = state.level.player_shot_frame
        bullet_type = state.level.bullet_type

        is_laser = bullet_type == self.consts.LASER_ID
        max_frames = jnp.where(is_laser, LASER_PROJECTILE_FRAMES, TORPEDO_PROJECTILE_FRAMES)
        return (shot_frame >= 0) & (shot_frame < max_frames)

    def _projectile_resolved(self, state: BeamriderState):
        """Check if the active projectile just finished its lifecycle (horizon)."""
        shot_frame = state.level.player_shot_frame
        bullet_type = state.level.bullet_type
        is_laser = bullet_type == self.consts.LASER_ID
        max_frames = jnp.where(is_laser, LASER_PROJECTILE_FRAMES, TORPEDO_PROJECTILE_FRAMES)
        return (shot_frame >= 0) & (shot_frame >= (max_frames - 1))

    def _resolve_player_projectile(
        self,
        state: BeamriderState,
        player_shot_frame: chex.Array,
        shooting_cooldown: chex.Array,
        bullet_hit_any: chex.Array,
    ) -> Tuple[chex.Array, chex.Array]:
        """Apply ALE projectile teardown rules after movement/collision handling."""
        projectile_at_horizon = self._projectile_resolved(state)
        projectile_resolved_now = projectile_at_horizon | bullet_hit_any
        player_shot_frame = jnp.where(
            projectile_resolved_now,
            jnp.array(-1, dtype=player_shot_frame.dtype),
            player_shot_frame,
        )
        shooting_cooldown = jnp.where(
            bullet_hit_any,
            self.consts.PLAYER_SHOT_RECOVERY,
            shooting_cooldown,
        )
        return player_shot_frame, shooting_cooldown

    def _bouncer_dedicated_step(self, state: BeamriderState, key: chex.Array):
        level = state.level
        pos = level.bouncer_pos
        vel = level.bouncer_vel
        lane_idx = level.bouncer_lane
        step_index = level.bouncer_step_index
        state_id = level.bouncer_state
        timer = level.bouncer_timer
        active = level.bouncer_active
        mothership_active = level.mothership_stage > 0

        def switching_logic(p, l_idx, s_idx, direction):
            is_odd = (s_idx % 2) != 0
            dy = jnp.where(is_odd, 1.0, 0.0)

            target_lane = jnp.where(l_idx == -1, 1,
                                    jnp.where(l_idx == 7, 5,
                                              jnp.clip(l_idx + direction.astype(jnp.int32), 0, 6)))

            lanes_top_x = self.top_lanes_x
            lane_dx_over_dy = self.lane_dx_over_dy

            target_x = lanes_top_x[target_lane] + lane_dx_over_dy[target_lane] * (p[1] - float(self.consts.TOP_CLIP))

            dist_x = target_x - p[0]
            dx = jnp.clip(dist_x, -self.consts.BOUNCER_SWITCH_SPEED_X, self.consts.BOUNCER_SWITCH_SPEED_X)

            finished_switching = jnp.abs(dist_x) < 1.0

            next_state = jnp.where(finished_switching, int(BouncerState.DOWN), int(BouncerState.SWITCHING))
            next_s_idx = jnp.where(finished_switching, 0, s_idx + 1)
            next_lane = jnp.where(finished_switching, target_lane, l_idx)

            return dx, dy, next_state, next_s_idx, next_lane

        def lane_logic(p, l_idx, s_idx, is_down):
            speed = self.bouncer_speed_pattern[s_idx % 4]

            lane_vectors = self.lane_vectors_t2b
            safe_lane = jnp.clip(l_idx, 0, 6)
            vec = lane_vectors[safe_lane]

            vy = speed.astype(jnp.float32)
            vx = vy * (vec[0] / vec[1])

            vy = jnp.where(is_down, vy, -vy)
            vx = jnp.where(is_down, vx, -vx)

            can_bounce = (safe_lane > 0) & (safe_lane < 6)
            limit_y = jnp.where(can_bounce, float(self.consts.PLAYER_POS_Y), 220.0)

            hit_bottom = (p[1] >= limit_y) & is_down
            hit_top = (p[1] <= self.consts.BOUNCER_SPAWN_HEIGHT) & (jnp.logical_not(is_down))

            next_state = jnp.where(is_down,
                                   jnp.where(hit_bottom, int(BouncerState.UP), int(BouncerState.DOWN)),
                                   jnp.where(hit_top, int(BouncerState.SWITCHING), int(BouncerState.UP)))

            next_s_idx = jnp.where(hit_top & (jnp.logical_not(is_down)), 0, s_idx + 1)
            next_state = jnp.where(jnp.logical_not(can_bounce) & is_down, int(BouncerState.DOWN), next_state)

            return vx, vy, next_state, next_s_idx, l_idx

        def move_active(_):
            direction = jnp.where(timer == 0, jnp.sign(vel[0]), timer.astype(jnp.float32))
            direction = jnp.where(direction == 0, 1.0, direction)
            direction = jnp.sign(direction)

            is_switching = state_id == int(BouncerState.SWITCHING)
            is_down = state_id == int(BouncerState.DOWN)

            dx_s, dy_s, ns_s, ni_s, nl_s = switching_logic(pos, lane_idx, step_index, direction)
            dx_l, dy_l, ns_l, ni_l, nl_l = lane_logic(pos, lane_idx, step_index, is_down)

            final_dx = jnp.where(is_switching, dx_s, dx_l)
            final_dy = jnp.where(is_switching, dy_s, dy_l)
            final_state = jnp.where(is_switching, ns_s, ns_l)
            final_s_idx = jnp.where(is_switching, ni_s, ni_l)
            final_lane = jnp.where(is_switching, nl_s, nl_l)

            new_pos = pos + jnp.array([final_dx, final_dy])

            should_deactivate = jnp.logical_or(
                new_pos[1] > float(self.consts.BOTTOM_CLIP) + 5.0,
                jnp.logical_or(new_pos[0] < 0, new_pos[0] > float(self.consts.SCREEN_WIDTH))
            )

            return (
                new_pos,
                jnp.array([final_dx, final_dy]),
                final_state,
                timer,
                jnp.logical_not(should_deactivate),
                final_lane,
                final_s_idx
            )

        def spawn_inactive(_):
            rolls = jax.random.uniform(key, shape=(2,))

            # Average every 5 seconds = 1/150 chance per step
            spawn_prob = 1.0 / 150.0

            should_spawn = (rolls[0] < spawn_prob) & (state.sector >= self.consts.BOUNCER_START_LEVEL)
            should_spawn = jnp.logical_and(should_spawn, jnp.logical_not(mothership_active))

            side_left = rolls[1] < 0.5
            spawn_x = jnp.where(side_left, 5.0, 155.0)
            spawn_y = self.consts.BOUNCER_SPAWN_HEIGHT
            spawn_dir = jnp.where(side_left, 1.0, -1.0)
            spawn_lane = jnp.where(side_left, -1, 7)

            return (
                jnp.where(should_spawn, jnp.array([spawn_x, spawn_y]), self.enemy_offscreen),
                jnp.where(should_spawn, jnp.array([spawn_dir, 0.0]), jnp.zeros(2, dtype=jnp.float32)),
                jnp.where(should_spawn, int(BouncerState.SWITCHING), int(BouncerState.SWITCHING)),
                jnp.where(should_spawn, spawn_dir.astype(jnp.int32), 0),
                should_spawn,
                jnp.where(should_spawn, spawn_lane, 0),
                jnp.where(should_spawn, 0, 0)
            )

        return jax.lax.cond(active, move_active, spawn_inactive, operand=None)

    @partial(jax.jit, static_argnums=(0,))
    def render(self, state: BeamriderState):
        return self.renderer.render(state)

    def action_space(self) -> spaces.Discrete:
        return spaces.Discrete(len(self.action_set))

    def _get_info(self, state: BeamriderState) -> BeamriderInfo:
        return BeamriderInfo(
            score=state.score,
            sector=state.sector,
        )

    def _get_reward(
        self, previous_state: BeamriderState, state: BeamriderState
    ) -> float:
        return (state.score - previous_state.score).astype(jnp.float32)

    def _get_done(self, state: BeamriderState) -> bool:
        return jnp.logical_or(state.lives <= 0, state.sector > 14)

    def _kamikaze_step(self, state: BeamriderState, key: chex.Array):
        pos = state.level.kamikaze_pos
        active = state.level.kamikaze_active[0]
        lane = state.level.kamikaze_lane[0]
        vel_y = state.level.kamikaze_vel_y[0]
        tracking = state.level.kamikaze_tracking[0]
        spawn_timer = state.level.kamikaze_spawn_timer[0]
        mothership_active = state.level.mothership_stage > 0

        # Spawning logic: Sector 12 onwards, every 250 frames
        is_level_12_plus = state.sector >= self.consts.KAMIKAZE_START_SECTOR

        # Advance timer if in sector 12+ and not currently active
        spawn_timer = jnp.where(is_level_12_plus & jnp.logical_not(active),
                                spawn_timer + 1,
                                0)

        should_spawn = is_level_12_plus & jnp.logical_not(active) & (spawn_timer >= self.consts.KAMIKAZE_SPAWN_INTERVAL)
        should_spawn = jnp.logical_and(should_spawn, jnp.logical_not(mothership_active))

        roll = jax.random.uniform(key)
        spawn_lane = jnp.floor(roll * 5.0).astype(jnp.int32) + 1

        spawn_x = self.top_lanes_x[spawn_lane]
        spawn_y = float(self.consts.KAMIKAZE_START_Y)

        pos = jnp.where(should_spawn, jnp.array([[spawn_x], [spawn_y]]), pos)
        active = jnp.where(should_spawn, True, active)
        lane = jnp.where(should_spawn, spawn_lane, lane)
        vel_y = jnp.where(should_spawn, self.consts.LANE_BLOCKER_INIT_VEL, vel_y)
        tracking = jnp.where(should_spawn, True, tracking)
        spawn_timer = jnp.where(should_spawn, 0, spawn_timer)

        y = pos[1, 0]

        # Acceleration like Alien Blocker
        accel = jnp.where(y < 64, 0.004,
                jnp.where(y < 85, 0.008,
                self.consts.FALLING_ROCK_ACCEL))

        new_vel_y = vel_y + accel
        dy = new_vel_y
        new_y = y + dy

        # Tracking logic: starts at 60y
        player_x = state.level.player_pos
        player_lane = jnp.argmin(jnp.abs(self.bottom_lanes - player_x)) + 1 # 1-5

        should_track = active & (new_y >= self.consts.KAMIKAZE_TRACK_Y) & tracking

        lane_dx_over_dy = self.lane_dx_over_dy

        # Current lane position
        current_lane_x = self.top_lanes_x[lane] + lane_dx_over_dy[lane] * (new_y - float(self.consts.TOP_CLIP))

        # Target lane position
        target_lane_x = self.top_lanes_x[player_lane] + lane_dx_over_dy[player_lane] * (new_y - float(self.consts.TOP_CLIP))

        lateral_dist = target_lane_x - pos[0, 0]
        dx_dir = jnp.sign(lateral_dist)
        dx_lateral = 2.0 * dy * dx_dir

        # If we are close enough to the target lane, snap to it and stop tracking
        reached_lane = jnp.abs(lateral_dist) <= jnp.abs(dx_lateral)

        new_x = jnp.where(should_track,
                          jnp.where(reached_lane, target_lane_x, pos[0, 0] + dx_lateral),
                          current_lane_x)

        # Update lane index if reached
        lane = jnp.where(should_track & reached_lane, player_lane, lane)
        tracking = jnp.where(should_track & reached_lane, False, tracking)

        # Deactivate if off-screen
        off_screen = new_y > self.consts.PLAYER_POS_Y + 5.0
        active = jnp.where(off_screen, False, active)

        offscreen_pos = self.kamikaze_offscreen
        final_pos = jnp.where(active, jnp.array([[new_x], [new_y]]), offscreen_pos)

        return final_pos, jnp.array([active]), jnp.array([lane]), jnp.array([new_vel_y]), jnp.array([tracking]), jnp.array([spawn_timer])

    def _kamikaze_bullet_collision(
        self,
        kamikaze_pos: chex.Array,
        kamikaze_active: chex.Array,
        player_shot_pos: chex.Array,
        shot_x: chex.Array,
        shot_active: chex.Array,
        bullet_size: chex.Array,
        is_torpedo: chex.Array
    ):
        shot_y = player_shot_pos[1]

        kamikaze_x = kamikaze_pos[0, 0] + _get_ufo_alignment(kamikaze_pos[1, 0]).astype(kamikaze_pos.dtype)
        kamikaze_y = kamikaze_pos[1, 0]

        is_near = kamikaze_active[0] & shot_active & (jnp.abs(kamikaze_y - shot_y) <= 16.0)

        kamikaze_indices = jnp.clip(_get_index_kamikaze(kamikaze_y) - 1, 0, 3)
        kamikaze_sizes = jnp.take(self.lane_blocker_sprite_sizes, kamikaze_indices, axis=0)

        # AABB collision check
        hit_mask = (
                is_near
                & (kamikaze_x < shot_x + bullet_size[1]) & (shot_x < kamikaze_x + kamikaze_sizes[1])
                & (kamikaze_y < shot_y + bullet_size[0]) & (shot_y < kamikaze_y + kamikaze_sizes[0])
        )
        
        # Kamikaze is destroyed only by torpedo
        destroyed = hit_mask & is_torpedo
        
        offscreen = self.kamikaze_offscreen
        new_pos = jnp.where(destroyed, offscreen, kamikaze_pos)
        new_active = jnp.where(destroyed, False, kamikaze_active[0])
        
        # Shot is always removed if it hits (blocking behavior)
        new_player_shot_pos = jnp.where(
            hit_mask,
            self.bullet_offscreen,
            player_shot_pos,
        )

        return new_pos, jnp.array([new_active]), new_player_shot_pos, jnp.array([destroyed]), jnp.array([hit_mask])

    def action_space(self) -> spaces.Discrete:
        return spaces.Discrete(len(self.action_set))

    def observation_space(self) -> spaces.Dict:
        return spaces.Dict({
            "player": spaces.get_object_space(n=None, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "player_shots": spaces.get_object_space(n=1, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "white_ufo": spaces.get_object_space(n=3, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "enemy_shots": spaces.get_object_space(n=9, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "chasing_meteoroids": spaces.get_object_space(n=self.consts.CHASING_METEOROID_MAX, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "falling_rocks": spaces.get_object_space(n=self.consts.FALLING_ROCK_MAX, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "lane_blockers": spaces.get_object_space(n=self.consts.LANE_BLOCKER_MAX, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "coins": spaces.get_object_space(n=self.consts.COIN_MAX, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "kamikaze": spaces.get_object_space(n=self.consts.KAMIKAZE_MAX, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "rejuvenator": spaces.get_object_space(n=None, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "bouncer": spaces.get_object_space(n=None, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "mothership": spaces.get_object_space(n=None, screen_size=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH)),
            "shooting_cd": spaces.Box(low=0.0, high=255.0, shape=(), dtype=jnp.float32),
            "torpedoes_left": spaces.Box(low=0.0, high=3.0, shape=(), dtype=jnp.float32),
            "white_ufo_left": spaces.Box(low=0.0, high=100.0, shape=(), dtype=jnp.float32),
            "lives": spaces.Box(low=0.0, high=255.0, shape=(), dtype=jnp.float32),
            "score": spaces.Box(low=0.0, high=1e7, shape=(), dtype=jnp.float32),
            "sector": spaces.Box(low=1.0, high=15.0, shape=(), dtype=jnp.float32),
            "shooting_delay": spaces.Box(low=0.0, high=255.0, shape=(), dtype=jnp.float32),
            "bullet_type": spaces.Box(low=0.0, high=2.0, shape=(), dtype=jnp.float32),
            "shot_type_pending": spaces.Box(low=0.0, high=2.0, shape=(), dtype=jnp.float32),
            "standby_phase": spaces.Box(low=0.0, high=3.0, shape=(), dtype=jnp.float32),
            "death_timer": spaces.Box(low=0.0, high=120.0, shape=(), dtype=jnp.float32),
            "white_ufo_pattern_id": spaces.Box(low=0.0, high=9.0, shape=(3,), dtype=jnp.float32),
            "white_ufo_pattern_timer": spaces.Box(low=0.0, high=255.0, shape=(3,), dtype=jnp.float32),
            "mothership_timer": spaces.Box(low=0.0, high=255.0, shape=(), dtype=jnp.float32),
            "mothership_stage": spaces.Box(low=0.0, high=5.0, shape=(), dtype=jnp.float32),
            "rejuvenator_dead": spaces.Box(low=0.0, high=1.0, shape=(), dtype=jnp.float32),
        })

    def image_space(self) -> spaces.Box:
        return spaces.Box(low=0, high=255, shape=(self.consts.SCREEN_HEIGHT, self.consts.SCREEN_WIDTH, 3), dtype=jnp.uint8)

class BeamriderRenderer(JAXGameRenderer):
    def __init__(self, consts=None, config: render_utils.RendererConfig = None):
        self.consts = consts or BeamriderConstants()
        super().__init__(self.consts, config)
        
        # Use injected config if provided, else default
        if config is None:
            self.config = render_utils.RendererConfig(
                game_dimensions=(210, 160),
                channels=3,
            )
        else:
            self.config = config

        self.jr = render_utils.JaxRenderingUtils(self.config)

        # 1. Create procedural assets:
        # background_sprite = self._create_background_sprite()
        # player_sprite = self._create_player_sprite()

        #2 Update asset config to include sprites 
        asset_config = self._get_asset_config()
        sprite_path = os.path.join(render_utils.get_base_sprite_dir(), "beamrider")

        # Sparse overlays / lane dots do not survive shared cubic or plain nearest
        # RGBA/ID downscaling. Anchor exact palette colors, then rebuild those
        # rasters with detail-preserving nearest sampling.
        if self.config.downscale:
            asset_config = asset_config + self._native_downscale_palette_anchors(sprite_path)

        # 3. Make a single call to the setup function
        (
            self.PALETTE,
            self.SHAPE_MASKS,
            self.BACKGROUND,
            self.COLOR_TO_ID,
            self.FLIP_OFFSETS
        ) = self.jr.load_and_setup_assets(asset_config, sprite_path)

        if self.config.downscale:
            self._fix_native_downscale_masks(sprite_path)

        self._enemy_explosion_sprite_seq = jnp.array(
            [0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5],
            dtype=jnp.int32,
        )
        self._enemy_explosion_y_offsets = jnp.array(
            [0, 0, 0, 0, -1, -1, -1, -1, -2, -2, -2, -2, -3, -3, -3, -3, -4, -4, -4, -4, -5],
            dtype=jnp.int32,
        )
        self._coin_anim_seq = jnp.array(self.consts.COIN_ANIM_SEQ, dtype=jnp.int32)
        self._mothership_explosion_seq = jnp.array(self.consts.MOTHERSHIP_EXPLOSION_SEQUENCE, dtype=jnp.int32)
        self._torpedo_icon_thresholds = jnp.array([3, 2, 1], dtype=jnp.int32)
        self._torpedo_icon_ys = jnp.array([128, 136, 144], dtype=jnp.int32)

        self._lane_blocker_height = self.SHAPE_MASKS["lane_blocker"][0].shape[0]
        self._lane_blocker_row_idx = jnp.arange(self._lane_blocker_height)

        self._mothership_mask_height = self.SHAPE_MASKS["mothership"].shape[0]
        self._mothership_y_indices = jnp.arange(self._mothership_mask_height)[:, None]

    # def _create_player_sprite(self) -> jnp.ndarray:
    #     """Procedurally creates an RGBA sprite for the background"""
    #     player_color_rgba = (214, 239, 30, 0.7) # e.g., (236, 236, 236, 255)
    #     player_dimensions = (self.consts.PLAYER_SPRITE_SIZE[0], self.consts.PLAYER_SPRITE_SIZE[1], 4)
    #     player_sprite = jnp.tile(jnp.array(player_color_rgba, dtype=jnp.uint8), (*player_dimensions[:2], 1))
    #     return player_sprite
    
    def _get_asset_config(self) -> list:
        """Returns the declarative manifest of all assets for the game, including both wall sprites."""
        return [
            {'name': 'background_sprite', 'type': 'background', 'file': 'new_background.npy'},
            {'name': 'player_sprite', 'type': 'group', 'files': list(map(lambda i: f'Player/Player_{i}.npy', range(1, 17)))},
            {'name': 'purple_player', 'type': 'single', 'file': 'Purple_player_standby.npy'},
            {'name': 'dead_player', 'type': 'single', 'file': 'Dead_Player.npy'},
            {'name': 'white_ufo', 'type': 'group', 'files': ['White_Ufo_Stage_1.npy', 'White_Ufo_Stage_2.npy', 'White_Ufo_Stage_3.npy', 'White_Ufo_Stage_4.npy', 'White_Ufo_Stage_5.npy', 'White_Ufo_Stage_6.npy', 'White_Ufo_Stage_7.npy']},
            {'name': 'coin', 'type': 'group', 'files': ['Coin/Coin1.npy', 'Coin/Coin2.npy', 'Coin/Coin3.npy', 'Coin/Coin4.npy']},
            {'name': 'bouncer', 'type': 'single', 'file': 'Bouncer.npy'},
            {'name': 'enemy_explosion', 'type': 'group', 'files': [
                'White_Ufo_Explosion/White_Ufo_Explosion_1.npy',
                'White_Ufo_Explosion/White_Ufo_Explosion_2.npy',
                'White_Ufo_Explosion/White_Ufo_Explosion_3.npy',
                'White_Ufo_Explosion/White_Ufo_Explosion_4.npy',
                'White_Ufo_Explosion/White_Ufo_Explosion_5.npy',
                'White_Ufo_Explosion/White_Ufo_Explosion_6.npy',
            ]},
            {'name': 'chasing_meteoroid', 'type': 'single', 'file': 'Chasing_Meteoroid.npy'},
            {'name': 'laser_sprite', 'type': 'single', 'file': 'Laser.npy'},
            {'name': 'bullet_sprite', 'type': 'group', 'files': ['Laser.npy', 'Torpedo/Torpedo_3.npy', 'Torpedo/Torpedo_2.npy', 'Torpedo/Torpedo_1.npy']},
            {'name': 'enemy_shot', 'type': 'group', 'files': ['Enemy_Shot/Enemy_Shot_Vertical.npy', 'Enemy_Shot/Enemy_Shot_Horizontal.npy']},
            {'name': 'rejuvenator', 'type': 'group', 'files': list(map(lambda i: f'Rejuvenator/Rejuvenator_{i}.npy', range(1, 5))) + ['Rejuvenator/Rejuvenator_Dead.npy']},
            {'name': 'falling_rocks', 'type': 'group', 'files': ['Falling Rocks/Rock_1.npy', 'Falling Rocks/Rock_2.npy', 'Falling Rocks/Rock_3.npy', 'Falling Rocks/Rock_4.npy']},
            {'name': 'lane_blocker', 'type': 'group', 'files': [
                'AlienBlocker/AlienBlocker_1.npy',
                'AlienBlocker/AlienBlocker_2.npy',
                'AlienBlocker/AlienBlocker_3.npy',
                'AlienBlocker/AlienBlocker_4.npy',
            ]},
            {'name': 'kamikaze', 'type': 'group', 'files': [
                'Kamikaze/Kamikaze_1.npy',
                'Kamikaze/Kamikaze_2.npy',
                'Kamikaze/Kamikaze_3.npy',
                'Kamikaze/Kamikaze_4.npy',
            ]},
            {'name': 'blue_line', 'type': 'single', 'file': 'blue_line.npy'},
            {'name': 'torpedos_left', 'type': 'single', 'file': 'torpedos_left.npy'},
            {'name': 'green_numbers', 'type': 'digits', 'pattern': 'green_nums/green_{}.npy'},
            {'name': 'yellow_numbers', 'type': 'digits', 'pattern': 'yellow_nums/yellow_{}.npy'},
            {'name': 'live', 'type': 'single', 'file': 'lives.npy'},
            {'name': 'mothership', 'type': 'single', 'file': 'Mothership.npy'},
            {'name': 'mothership_explosion', 'type': 'group', 'files': [
                'Mothership/Mothership_explosion1.npy',
                'Mothership/Mothership_explosion2.npy',
                'Mothership/Mothership_explosion3.npy',
            ]},
            {'name': 'yellow_background', 'type': 'single', 'file': 'colored_backgrounds/Yellow_background.npy'},
            {'name': 'light_orange_background', 'type': 'single', 'file': 'colored_backgrounds/LightOrange_background.npy'},
            {'name': 'middle_orange_background', 'type': 'single', 'file': 'colored_backgrounds/MiddleOrange_background.npy'},
            {'name': 'dark_orange_background', 'type': 'single', 'file': 'colored_backgrounds/DarkOrange_background.npy'},
            {'name': 'red_background', 'type': 'single', 'file': 'colored_backgrounds/Red_background.npy'},
            {'name': 'white_background', 'type': 'single', 'file': 'colored_backgrounds/White_background.npy'},
            {'name': 'lila_background', 'type': 'single', 'file': 'colored_backgrounds/Lila_background.npy'},
            {'name': 'blood_orange_background', 'type': 'single', 'file': 'colored_backgrounds/BloodOrange_background.npy'},
        ]

    # Flash overlays + sparse sprites that need nearest ID masks under native downscaling.
    _NATIVE_DOWNSCALE_COLORED_BACKGROUNDS = (
        ('yellow_background', 'colored_backgrounds/Yellow_background.npy'),
        ('light_orange_background', 'colored_backgrounds/LightOrange_background.npy'),
        ('middle_orange_background', 'colored_backgrounds/MiddleOrange_background.npy'),
        ('dark_orange_background', 'colored_backgrounds/DarkOrange_background.npy'),
        ('red_background', 'colored_backgrounds/Red_background.npy'),
        ('white_background', 'colored_backgrounds/White_background.npy'),
        ('lila_background', 'colored_backgrounds/Lila_background.npy'),
        ('blood_orange_background', 'colored_backgrounds/BloodOrange_background.npy'),
    )
    _NATIVE_DOWNSCALE_SPRITE_GROUPS = (
        (
            'bullet_sprite',
            (
                'Laser.npy',
                'Torpedo/Torpedo_3.npy',
                'Torpedo/Torpedo_2.npy',
                'Torpedo/Torpedo_1.npy',
            ),
            'laser_sprite',  # also expose first frame as the single laser asset
        ),
        (
            'falling_rocks',
            (
                'Falling Rocks/Rock_1.npy',
                'Falling Rocks/Rock_2.npy',
                'Falling Rocks/Rock_3.npy',
                'Falling Rocks/Rock_4.npy',
            ),
            None,
        ),
        (
            'white_ufo',
            (
                'White_Ufo_Stage_1.npy',
                'White_Ufo_Stage_2.npy',
                'White_Ufo_Stage_3.npy',
                'White_Ufo_Stage_4.npy',
                'White_Ufo_Stage_5.npy',
                'White_Ufo_Stage_6.npy',
                'White_Ufo_Stage_7.npy',
            ),
            None,
        ),
        (
            'rejuvenator',
            (
                'Rejuvenator/Rejuvenator_1.npy',
                'Rejuvenator/Rejuvenator_2.npy',
                'Rejuvenator/Rejuvenator_3.npy',
                'Rejuvenator/Rejuvenator_4.npy',
                'Rejuvenator/Rejuvenator_Dead.npy',
            ),
            None,
        ),
    )

    def _native_downscale_palette_anchors(self, sprite_path: str) -> list:
        """1x1 swatches so sparse sprite / flash colors stay in COLOR_TO_ID after cubic load."""
        colors = set()
        rels = [rel for _, files, _ in self._NATIVE_DOWNSCALE_SPRITE_GROUPS for rel in files]
        rels += [rel for _, rel in self._NATIVE_DOWNSCALE_COLORED_BACKGROUNDS]
        for rel in rels:
            rgba = np.asarray(self.jr.loadFrame(os.path.join(sprite_path, rel)))
            opaque = rgba[rgba[..., 3] > 128][..., :3]
            for rgb in np.unique(opaque, axis=0):
                colors.add((int(rgb[0]), int(rgb[1]), int(rgb[2])))

        anchors = []
        for i, (r, g, b) in enumerate(sorted(colors)):
            pixel = jnp.array([[[r, g, b, 255]]], dtype=jnp.uint8)
            anchors.append({'name': f'_palette_anchor_{i}', 'type': 'procedural', 'data': pixel})
        return anchors

    def _nearest_downscale_rgba(self, rgba: jnp.ndarray) -> jnp.ndarray:
        """Nearest / max-alpha block downscale for sparse sprites (setup-time only)."""
        sprite_np = np.asarray(rgba)
        original_h, original_w = sprite_np.shape[:2]
        scaled_h = max(1, int(round(original_h * self.config.height_scaling)))
        scaled_w = max(1, int(round(original_w * self.config.width_scaling)))
        if (scaled_h, scaled_w) == (original_h, original_w):
            return jnp.asarray(sprite_np)

        out = np.zeros((scaled_h, scaled_w, sprite_np.shape[2]), dtype=sprite_np.dtype)
        for y in range(scaled_h):
            y0 = int(y * original_h / scaled_h)
            y1 = max(y0 + 1, int((y + 1) * original_h / scaled_h))
            for x in range(scaled_w):
                x0 = int(x * original_w / scaled_w)
                x1 = max(x0 + 1, int((x + 1) * original_w / scaled_w))
                block = sprite_np[y0:y1, x0:x1]
                opaque = block[..., 3] > 128
                if np.any(opaque):
                    out[y, x] = block.reshape(-1, sprite_np.shape[2])[np.argmax(opaque)]
                else:
                    cy = min(original_h - 1, int(round((y + 0.5) * original_h / scaled_h - 0.5)))
                    cx = min(original_w - 1, int(round((x + 0.5) * original_w / scaled_w - 0.5)))
                    out[y, x] = sprite_np[cy, cx]
        return jnp.asarray(out)

    def _downscale_id_mask_preserve_detail(self, id_mask: jnp.ndarray) -> jnp.ndarray:
        """Nearest downscale that keeps sparse lane-dot IDs instead of the fill color."""
        mask_np = np.asarray(id_mask)
        original_h, original_w = mask_np.shape
        target_h, target_w = self.config.downscale[0], self.config.downscale[1]

        # Majority color is the sector fill (black normally, flash color during overlays).
        vals, counts = np.unique(mask_np, return_counts=True)
        fill_id = int(vals[np.argmax(counts)])

        out = np.empty((target_h, target_w), dtype=mask_np.dtype)
        for y in range(target_h):
            y0 = int(y * original_h / target_h)
            y1 = max(y0 + 1, int((y + 1) * original_h / target_h))
            for x in range(target_w):
                x0 = int(x * original_w / target_w)
                x1 = max(x0 + 1, int((x + 1) * original_w / target_w))
                block = mask_np[y0:y1, x0:x1].reshape(-1)
                detail = block[block != fill_id]
                out[y, x] = detail[0] if detail.size else fill_id
        return jnp.asarray(out)

    def _raster_from_rgba_preserve_detail(self, rgba: jnp.ndarray) -> jnp.ndarray:
        """Full-res palette ID mask, then detail-preserving downscale to native size."""
        id_mask = self.jr._create_id_mask(rgba, self.COLOR_TO_ID)
        return self._downscale_id_mask_preserve_detail(id_mask)

    def _replace_sprite_group_masks(self, sprite_path: str, mask_name: str, files: tuple, alias_first: Optional[str]) -> None:
        sprites = [
            self._nearest_downscale_rgba(self.jr.loadFrame(os.path.join(sprite_path, rel)))
            for rel in files
        ]
        padded, offsets = self.jr.pad_to_match(sprites)
        masks = [self.jr._create_id_mask(frame, self.COLOR_TO_ID) for frame in padded]
        self.SHAPE_MASKS[mask_name] = jnp.stack(masks)
        self.FLIP_OFFSETS[mask_name] = offsets[0]
        if alias_first is not None:
            self.SHAPE_MASKS[alias_first] = masks[0]

    def _fix_native_downscale_masks(self, sprite_path: str) -> None:
        """Replace cubic-damaged backgrounds and sparse sprite masks under native downscale."""
        # Lane dots are single pixels; plain nearest ID resize drops most of them.
        bg_rgba = self.jr.loadFrame(os.path.join(sprite_path, 'new_background.npy'))
        self.BACKGROUND = self._raster_from_rgba_preserve_detail(bg_rgba)

        for name, rel in self._NATIVE_DOWNSCALE_COLORED_BACKGROUNDS:
            rgba = self.jr.loadFrame(os.path.join(sprite_path, rel))
            self.SHAPE_MASKS[name] = self._raster_from_rgba_preserve_detail(rgba)

        for mask_name, files, alias_first in self._NATIVE_DOWNSCALE_SPRITE_GROUPS:
            self._replace_sprite_group_masks(sprite_path, mask_name, files, alias_first)
    
    @partial(jax.jit, static_argnums=(0,))
    def render(self, state:BeamriderState) -> chex.Array:
        raster = self.jr.create_object_raster(self.BACKGROUND)
        raster = self._render_colored_background(raster, state)
        raster = self._render_blue_lines(raster, state)
        raster = self._render_player_and_bullet(raster, state)
        raster = self._render_enemy_shots(raster, state)
        raster = self._render_white_ufos(raster, state)
        raster = self._render_bouncer(raster, state)
        raster = self._render_chasing_meteoroids(raster, state)
        raster = self._render_falling_rocks(raster, state)
        raster = self._render_lane_blockers(raster, state)
        raster = self._render_kamikaze(raster, state)
        raster = self._render_coins(raster, state)
        raster = self._render_rejuvenator(raster, state)
        raster = self._render_hud(raster, state)
        raster = self._render_mothership(raster, state)
        return self.jr.render_from_palette(raster, self.PALETTE)

    def _render_colored_background(self, raster, state):
        flash_timer = state.level.background_flash_timer
        death_timer = state.level.death_timer
        standby_phase = state.level.standby_phase
        mothership_stage = state.level.mothership_stage
        mothership_timer = state.level.mothership_timer
        blue_line_counter = state.level.blue_line_counter
        
        # Flash sequence (UFO destruction)
        is_yellow_flash = (flash_timer == 16) | (flash_timer == 15)
        is_light_orange_flash = (flash_timer == 12) | (flash_timer == 11)
        is_middle_orange_flash = (flash_timer == 10) | (flash_timer == 9)
        is_dark_orange_flash = (flash_timer == 8) | (flash_timer == 7)
        is_red_flash = (flash_timer >= 1) & (flash_timer <= 6)

        # Death sequence
        # Happens only during StandbyPhase.NONE (the actual dying animation)
        is_dying = (standby_phase == 0) & (death_timer > 0)
        death_idx = 120 - death_timer
        
        is_yellow_death = is_dying & (((death_idx >= 3) & (death_idx <= 6)) | ((death_idx >= 35) & (death_idx <= 38)))
        is_white_death = is_dying & (death_idx >= 11) & (death_idx <= 14)
        is_lila_death = is_dying & (((death_idx >= 19) & (death_idx <= 22)) | ((death_idx >= 51) & (death_idx <= 54)))
        is_blood_orange_death = is_dying & (death_idx >= 27) & (death_idx <= 30)
        is_red_death = is_dying & (((death_idx >= 43) & (death_idx <= 46)) | ((death_idx >= 59) & (death_idx <= 62)))
        is_mothership_flash = (mothership_stage == 5) & (mothership_timer < 2)

        # Startup/Resume sequence (starts at idx 118)
        # 2 steps purple (118, 119), 2 normal (120, 121), 2 blood orange (122, 123), 4 normal (124-127), 2 white (128, 129)
        is_lila_startup = (blue_line_counter == 118) | (blue_line_counter == 119)
        is_blood_orange_startup = (blue_line_counter == 122) | (blue_line_counter == 123)
        is_white_startup = (blue_line_counter == 128) | (blue_line_counter == 129)
        
        def render_color(r, mask_name):
            mask = self.SHAPE_MASKS[mask_name]
            return self.jr.render_at(r, 0, 0, mask)

        conditions = jnp.array([
            is_yellow_flash | is_yellow_death,
            is_light_orange_flash,
            is_middle_orange_flash,
            is_dark_orange_flash,
            is_red_flash | is_red_death,
            is_white_death | is_mothership_flash | is_white_startup,
            is_lila_death | is_lila_startup,
            is_blood_orange_death | is_blood_orange_startup
        ])

        bg_index = jnp.where(jnp.any(conditions), jnp.argmax(conditions) + 1, 0)

        return jax.lax.switch(
            bg_index,
            [
                lambda r: r,
                lambda r: render_color(r, "yellow_background"),
                lambda r: render_color(r, "light_orange_background"),
                lambda r: render_color(r, "middle_orange_background"),
                lambda r: render_color(r, "dark_orange_background"),
                lambda r: render_color(r, "red_background"),
                lambda r: render_color(r, "white_background"),
                lambda r: render_color(r, "lila_background"),
                lambda r: render_color(r, "blood_orange_background")
            ],
            raster
        )

    def _render_kamikaze(self, raster, state):
        kamikaze_masks = self.SHAPE_MASKS["kamikaze"]
        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]
        
        explosion_frame = state.level.kamikaze_explosion_frame[0]
        active = state.level.kamikaze_active[0]

        def render_explosion(r_in):
            sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
            sprite = explosion_masks[sprite_idx]
            x_pos = state.level.kamikaze_explosion_pos[0][0] + _get_ufo_alignment(
                state.level.kamikaze_explosion_pos[1][0]
            )
            y_pos = state.level.kamikaze_explosion_pos[1][0] + y_offset
            return self.jr.render_at_clipped(r_in, x_pos, y_pos, sprite)

        def render_kamikaze(r_in):
            def render_active(r_inner):
                sprite_idx = _get_index_kamikaze(state.level.kamikaze_pos[1][0]) - 1
                sprite_idx = jnp.clip(sprite_idx, 0, 3)
                sprite = kamikaze_masks[sprite_idx]
                x_pos = state.level.kamikaze_pos[0][0] + _get_ufo_alignment(
                    state.level.kamikaze_pos[1][0]
                )
                y_pos = state.level.kamikaze_pos[1][0]
                return self.jr.render_at_clipped(r_inner, x_pos, y_pos, sprite)
            
            return jax.lax.cond(active, render_active, lambda r: r, r_in)

        raster = jax.lax.cond(
            explosion_frame > 0,
            render_explosion,
            render_kamikaze,
            raster,
        )
        return raster

    def _render_coins(self, raster, state):
        coin_masks = self.SHAPE_MASKS["coin"]
        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]
        is_init = self._is_init(state)
        
        def body_fun(raster, idx):
            active = state.level.coin_active[idx] & jnp.logical_not(is_init)
            timer = state.level.coin_timer[idx]
            pos = state.level.coin_pos[:, idx]
            explosion_frame = state.level.coin_explosion_frame[idx]

            def render_explosion(r_in):
                sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
                sprite = explosion_masks[sprite_idx]
                x_pos = state.level.coin_explosion_pos[0][idx] + _get_ufo_alignment(
                    state.level.coin_explosion_pos[1][idx])
                y_pos = state.level.coin_explosion_pos[1][idx] + y_offset
                return self.jr.render_at_clipped(r_in, x_pos, y_pos, sprite)

            def render_coin(r_in):
                # Animation sequence: (3, 2, 1, 0, 1, 2)
                anim_idx = (timer // 4) % self._coin_anim_seq.shape[0]
                sprite_idx = self._coin_anim_seq[anim_idx]
                mask = coin_masks[sprite_idx]
                
                # Adjust X for screen position
                x_pos = pos[0] + _get_ufo_alignment(pos[1])
                return jax.lax.cond(active, lambda r: self.jr.render_at_clipped(r, x_pos, pos[1], mask), lambda r: r,
                                    r_in)

            return jax.lax.cond(explosion_frame > 0, render_explosion, render_coin, raster), None

        raster, _ = jax.lax.scan(body_fun, raster, jnp.arange(self.consts.COIN_MAX))
        return raster

    def _render_falling_rocks(self, raster, state):
        falling_rock_masks = self.SHAPE_MASKS["falling_rocks"]
        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]
        is_init = self._is_init(state)

        def body_fun(idx, r_in):
            is_active = state.level.falling_rock_active[idx] & jnp.logical_not(is_init)
            explosion_frame = state.level.falling_rock_explosion_frame[idx]

            def render_explosion(r):
                sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
                sprite = explosion_masks[sprite_idx]
                x_pos = state.level.falling_rock_explosion_pos[0][idx] + _get_ufo_alignment(
                    state.level.falling_rock_explosion_pos[1][idx]
                )
                y_pos = state.level.falling_rock_explosion_pos[1][idx] + y_offset
                return self.jr.render_at(r, x_pos, y_pos, sprite)

            def render_rock(r):
                sprite_idx = _get_index_falling_rock(state.level.falling_rock_pos[1][idx]) - 1
                sprite = falling_rock_masks[sprite_idx]
                x_pos = state.level.falling_rock_pos[0][idx] + _get_ufo_alignment(
                    state.level.falling_rock_pos[1][idx]
                )
                y_pos = state.level.falling_rock_pos[1][idx]
                return self.jr.render_at(r, x_pos, y_pos, sprite)

            return jax.lax.cond(
                explosion_frame > 0,
                render_explosion,
                lambda r1: jax.lax.cond(is_active, render_rock, lambda r2: r2, r1),
                r_in
            )

        raster = jax.lax.fori_loop(0, self.consts.FALLING_ROCK_MAX, body_fun, raster)
        return raster

    def _render_lane_blockers(self, raster, state):
        lane_blocker_masks = self.SHAPE_MASKS["lane_blocker"]
        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]
        is_init = self._is_init(state)

        def body_fun(idx, r_in):
            is_active = state.level.lane_blocker_active[idx] & jnp.logical_not(is_init)
            explosion_frame = state.level.lane_blocker_explosion_frame[idx]

            def render_explosion(r):
                sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
                sprite = explosion_masks[sprite_idx]
                x_pos = state.level.lane_blocker_explosion_pos[0][idx] + _get_ufo_alignment(
                    state.level.lane_blocker_explosion_pos[1][idx])
                y_pos = state.level.lane_blocker_explosion_pos[1][idx] + y_offset
                return self.jr.render_at(r, x_pos, y_pos, sprite)

            def render_blocker(r):
                sprite_idx = _get_index_lane_blocker(state.level.lane_blocker_pos[1][idx]) - 1
                sprite_idx = jnp.clip(sprite_idx, 0, lane_blocker_masks.shape[0] - 1)
                base_sprite = lane_blocker_masks[sprite_idx]

                x_pos = state.level.lane_blocker_pos[0][idx] + _get_ufo_alignment(state.level.lane_blocker_pos[1][idx])
                y_pos = state.level.lane_blocker_pos[1][idx]

                clip_rows = jnp.maximum(0, jnp.round(y_pos - self.consts.LANE_BLOCKER_BOTTOM_Y).astype(jnp.int32))
                is_sinking = state.level.lane_blocker_phase[idx] == int(LaneBlockerState.SINK)

                visible_rows = jnp.maximum(0, self._lane_blocker_height - clip_rows)
                row_mask = self._lane_blocker_row_idx < visible_rows
                transparent = jnp.array(self.jr.TRANSPARENT_ID, dtype=base_sprite.dtype)

                clipped_sprite = jnp.where(row_mask[:, None], base_sprite, transparent)
                final_sprite = jnp.where(is_sinking, clipped_sprite, base_sprite)

                return self.jr.render_at(r, x_pos, y_pos, final_sprite)

            return jax.lax.cond(
                explosion_frame > 0,
                render_explosion,
                lambda r1: jax.lax.cond(is_active, render_blocker, lambda r2: r2, r1),
                r_in
            )

        return jax.lax.fori_loop(0, self.consts.LANE_BLOCKER_MAX, body_fun, raster)

    def _render_rejuvenator(self, raster, state):
        rejuv_pos = state.level.rejuvenator_pos
        is_active = state.level.rejuvenator_active & jnp.logical_not(self._is_init(state))
        dead = state.level.rejuvenator_dead
        explosion_frame = state.level.rejuvenator_explosion_frame

        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]
        rejuv_masks = self.SHAPE_MASKS["rejuvenator"]

        def render_explosion(r_in):
            sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
            sprite = explosion_masks[sprite_idx]
            x_pos = state.level.rejuvenator_explosion_pos[0] + _get_ufo_alignment(
                state.level.rejuvenator_explosion_pos[1]
            )
            y_pos = state.level.rejuvenator_explosion_pos[1] + y_offset
            return self.jr.render_at_clipped(r_in, x_pos, y_pos, sprite)

        def render_active_rejuv(r_in):
            def draw_rejuv(r):
                stage = _get_index_rejuvenator(rejuv_pos[1])
                # stage 1..4 maps to masks 0..3, dead state is mask index 4
                sprite_idx = jnp.where(dead, 4, jnp.clip(stage - 1, 0, 3))
                mask = rejuv_masks[sprite_idx]

                return self.jr.render_at_clipped(r, rejuv_pos[0], rejuv_pos[1], mask)

            return jax.lax.cond(is_active, draw_rejuv, lambda r: r, r_in)

        return jax.lax.cond(
            explosion_frame > 0,
            render_explosion,
            render_active_rejuv,
            raster,
        )

    def _is_init(self, state: BeamriderState) -> jnp.bool_:
        return state.level.blue_line_counter < len(BLUE_LINE_INIT_TABLE)

    def _render_blue_lines(self, raster, state):
        """Draw the scrolling foreground lines."""

        blue_line_mask = self.SHAPE_MASKS["blue_line"]

        def body_fun(raster, idx):
            y_pos = state.level.line_positions[idx]

            def draw(r):
                return self.jr.render_at_clipped(r, 8, y_pos, blue_line_mask)

            return jax.lax.cond(y_pos >= 0, draw, lambda r: r, raster), None

        raster, _ = jax.lax.scan(body_fun, raster, jnp.arange(7))
        return raster

    def _render_hud(self, raster, state):
        raster = self._render_torpedo_icons(raster, state)
        raster = self._render_white_ufo_counter(raster, state)
        raster = self._render_score(raster, state)
        raster = self._render_sector(raster, state)
        raster = self._render_lives(raster, state)
        return raster

    def _render_torpedo_icons(self, raster, state):
        """Render the torpedo inventory indicator on the HUD."""

        torpedo_mask = self.SHAPE_MASKS["torpedos_left"]
        thresholds = self._torpedo_icon_thresholds
        ys = self._torpedo_icon_ys

        def body_fun(raster, idx):
            threshold = thresholds[idx]
            y = ys[idx]

            def draw(r):
                return self.jr.render_at(r, y, 32, torpedo_mask)

            return jax.lax.cond(state.level.torpedoes_left >= threshold, draw, lambda r: r, raster), None

        raster, _ = jax.lax.scan(body_fun, raster, jnp.arange(3))
        return raster

    def _render_white_ufo_counter(self, raster, state):
        # Hide counter if mothership animation is active or during SECTOR_DONE phase
        is_mothership = state.level.mothership_stage > 0
        is_sector_done = state.level.standby_phase == int(StandbyPhase.SECTOR_DONE)
        should_hide = jnp.logical_or(is_mothership, is_sector_done)
        
        ufos_left_digits = self.jr.int_to_digits(state.level.white_ufo_left, max_digits=2)
        ufos_left_masks = self.SHAPE_MASKS["green_numbers"]
        is_double_digit = state.level.white_ufo_left >= 10
        start_index = jnp.where(is_double_digit, 0, 1)
        numbers_to_render = jnp.where(is_double_digit, 2, 1)
        
        final_numbers_to_render = jnp.where(should_hide, 0, numbers_to_render)
        
        return self.jr.render_label_selective(
            raster, 19, 32, ufos_left_digits, ufos_left_masks, start_index, final_numbers_to_render, spacing=6
        )

    def _render_score(self, raster, state):
        yellow_digits = self.jr.int_to_digits(state.score, max_digits=6)
        score_masks = self.SHAPE_MASKS["yellow_numbers"]
        return self.jr.render_label_selective(
            raster, 61, 10, yellow_digits, score_masks, 0, 6, spacing=8, max_digits_to_render=6
        )

    def _render_sector(self, raster, state):
        sector_digits = self.jr.int_to_digits(state.sector, max_digits=2)
        score_masks = self.SHAPE_MASKS["yellow_numbers"]
        return self.jr.render_label_selective(
            raster, 93, 21, sector_digits, score_masks, 0, 2, spacing=8, max_digits_to_render=2
        )

    def _render_lives(self, raster, state):
        hp_mask = self.SHAPE_MASKS["live"]
        death_timer = state.level.death_timer
        is_dead = death_timer > 0
        
        # Flashing logic: 8 frames on, 8 frames off.
        flash_visible = (death_timer // 8) % 2 == 0
        
        max_visible_lives = max(self.consts.MAX_LIVES - 1, 0)

        def body_fun(raster, idx):
            # Normal logic: render if idx < state.lives - 1 (Bonus HP display)
            
            # Flashing logic: if is_dead, we are about to lose a life.
            # We want to flash the icon that represents the life we are losing.
            # The icon disappearing is at index state.lives - 2.
            
            is_last_life = (idx == state.lives - 2)
            should_flash = jnp.logical_and(is_dead, is_last_life)
            
            visible_normally = (state.lives - 1) > idx
            
            # If flashing, visibility depends on flash_visible.
            # If not flashing, depends on visible_normally.
            
            is_visible = jnp.where(
                should_flash,
                jnp.logical_and(visible_normally, flash_visible),
                visible_normally
            )

            # Icons start at x=32, spaced by 9 pixels
            def draw(r):
                pos_x = 32 + (idx * 9)
                return self.jr.render_at(r, pos_x, 183, hp_mask)

            return jax.lax.cond(is_visible, draw, lambda r: r, raster), None

        raster, _ = jax.lax.scan(body_fun, raster, jnp.arange(max_visible_lives))
        return raster

    def _render_player_and_bullet(self, raster, state):
        player_masks = self.SHAPE_MASKS["player_sprite"]
        dead_player_mask = self.SHAPE_MASKS["dead_player"]
        purple_player_mask = self.SHAPE_MASKS["purple_player"]
        player_screen_x = _get_player_screen_x(state.level.player_pos)
        
        # Determine which mask to use
        is_dead = state.level.death_timer > 0
        is_init = state.level.blue_line_counter < len(BLUE_LINE_INIT_TABLE)
        
        standby_phase = state.level.standby_phase
        standby_timer = state.level.standby_timer
        is_wait = standby_phase == int(StandbyPhase.WAIT)
        
        def render_alive(r):
            sprite_idx = jnp.where(is_init, 9, ((state.steps // 2) + 1) % 16)
            mask = player_masks[sprite_idx]
            
            # Standby Override
            use_purple = is_wait & ((standby_timer // self.consts.STANDBY_BLINK_DURATION) % 2 == 1)
            use_p10 = is_wait & jnp.logical_not(use_purple)
            
            mask = jnp.where(use_purple, purple_player_mask, mask)
            mask = jnp.where(use_p10, player_masks[9], mask)
            
            return self.jr.render_at(r, player_screen_x, self.consts.PLAYER_POS_Y, mask)

        def render_dead(r):
            return self.jr.render_at(r, player_screen_x, self.consts.PLAYER_POS_Y, dead_player_mask)

        # render player
        raster = jax.lax.cond(is_dead, render_dead, render_alive, raster)

        is_bullet_active = state.level.player_shot_pos[1] < 500.0

        def draw_bullet(r):
            bullet_mask = self.SHAPE_MASKS["bullet_sprite"][
                _get_index_bullet(state.level.player_shot_pos[1], state.level.bullet_type, self.consts.LASER_ID)
            ]
            shot_x_screen = _get_player_shot_screen_x(
                state.level.player_shot_pos,
                state.level.player_shot_vel,
                state.level.bullet_type,
                self.consts.LASER_ID,
            )
            return self.jr.render_at(
                r,
                shot_x_screen,
                state.level.player_shot_pos[1],
                bullet_mask,
            )

        raster = jax.lax.cond(is_bullet_active, draw_bullet, lambda r_in: r_in, raster)
        return raster

    def _render_enemy_shots(self, raster, state):
        enemy_shot_masks = self.SHAPE_MASKS["enemy_shot"]
        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]

        def body_fun(idx, r_in):
            explosion_frame = state.level.enemy_shot_explosion_frame[idx]
            y_pos_raw = state.level.enemy_shot_pos[1][idx]

            is_active = y_pos_raw <= self.consts.BOTTOM_CLIP

            def render_explosion(r):
                sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
                sprite = explosion_masks[sprite_idx]
                x_pos = state.level.enemy_shot_explosion_pos[0][idx] + _get_ufo_alignment(
                    state.level.enemy_shot_explosion_pos[1][idx]
                )
                y_pos = state.level.enemy_shot_explosion_pos[1][idx] + y_offset
                return self.jr.render_at(r, x_pos, y_pos, sprite)

            def render_shot(r):
                timer = state.level.enemy_shot_timer[idx]
                sprite_idx = (jnp.floor_divide(timer, 4) % 2).astype(jnp.int32)
                x_pos = state.level.enemy_shot_pos[0][idx] + _get_ufo_alignment(y_pos_raw)
                return self.jr.render_at(r, x_pos, y_pos_raw, enemy_shot_masks[sprite_idx])

            return jax.lax.cond(
                explosion_frame > 0,
                render_explosion,
                lambda r1: jax.lax.cond(is_active, render_shot, lambda r2: r2, r1),
                r_in
            )

        raster = jax.lax.fori_loop(0, 9, body_fun, raster)
        return raster

    def _render_white_ufos(self, raster, state):
        white_ufo_masks = self.SHAPE_MASKS["white_ufo"]
        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]
        
        is_init = state.level.blue_line_counter < len(BLUE_LINE_INIT_TABLE)
        if_hide = is_init
        
        def body_fun(idx, r_in):
            explosion_frame = state.level.ufo_explosion_frame[idx]
            y_pos_raw = state.level.white_ufo_pos[1][idx]
            is_on_screen = y_pos_raw >= 0.0
            is_normal_active = jnp.logical_not(if_hide) & is_on_screen & (explosion_frame == 0)
            is_exploding = explosion_frame > 0

            def render_explosion(r):
                sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
                sprite = explosion_masks[sprite_idx]
                x_pos = state.level.ufo_explosion_pos[0][idx] + _get_ufo_alignment(
                    state.level.ufo_explosion_pos[1][idx]
                )
                y_pos = state.level.ufo_explosion_pos[1][idx] + y_offset
                return self.jr.render_at(r, x_pos, y_pos, sprite)

            def render_ufo(r):
                y_pos_raw = state.level.white_ufo_pos[1][idx]
                sprite_idx = _get_index_ufo(y_pos_raw) - 1
                sprite = white_ufo_masks[sprite_idx]
                x_pos = state.level.white_ufo_pos[0][idx] + _get_ufo_alignment(y_pos_raw)
                return self.jr.render_at(r, x_pos, y_pos_raw, sprite)

            return jax.lax.cond(
                is_exploding,
                render_explosion,
                lambda r1: jax.lax.cond(is_normal_active, render_ufo, lambda r2: r2, r1),
                r_in
            )

        raster = jax.lax.fori_loop(0, 3, body_fun, raster)
        return raster

    def _render_bouncer(self, raster, state):
        bouncer_mask = self.SHAPE_MASKS["bouncer"]
        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]
        explosion_frame = state.level.bouncer_explosion_frame

        def render_explosion(r_in):
            sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
            sprite = explosion_masks[sprite_idx]
            x_pos = state.level.bouncer_explosion_pos[0] + _get_ufo_alignment(
                state.level.bouncer_explosion_pos[1]
            )
            y_pos = state.level.bouncer_explosion_pos[1] + y_offset
            return self.jr.render_at_clipped(r_in, x_pos, y_pos, sprite)

        def render_active_bouncer(r_in):
            is_active = state.level.bouncer_active
            def draw_bouncer(r_draw):
                y_pos = state.level.bouncer_pos[1]
                x_pos = state.level.bouncer_pos[0] + _get_ufo_alignment(y_pos)
                return self.jr.render_at_clipped(r_draw, x_pos, y_pos, bouncer_mask)
            return jax.lax.cond(is_active, draw_bouncer, lambda r_skip: r_skip, r_in)

        return jax.lax.cond(
            explosion_frame > 0,
            render_explosion,
            render_active_bouncer,
            raster,
        )

    def _render_chasing_meteoroids(self, raster, state):
        meteoroid_mask = self.SHAPE_MASKS["chasing_meteoroid"]
        explosion_masks = self.SHAPE_MASKS["enemy_explosion"]
        is_init = self._is_init(state)

        def body_fun(raster, idx):
            explosion_frame = state.level.chasing_meteoroid_explosion_frame[idx]

            def render_explosion(r_in):
                sprite_idx, y_offset = self._get_enemy_explosion_visuals(explosion_frame)
                sprite = explosion_masks[sprite_idx]
                x_pos = state.level.chasing_meteoroid_explosion_pos[0][idx] + _get_ufo_alignment(
                    state.level.chasing_meteoroid_explosion_pos[1][idx]
                )
                y_pos = state.level.chasing_meteoroid_explosion_pos[1][idx] + y_offset
                return self.jr.render_at_clipped(r_in, x_pos, y_pos, sprite)

            def render_meteoroid(r_in):
                is_active = state.level.chasing_meteoroid_active[idx] & jnp.logical_not(is_init)

                # Schritt 3: Rendering komplett überspringen, wenn inaktiv
                def draw(r):
                    y_pos = state.level.chasing_meteoroid_pos[1][idx]
                    x_pos = state.level.chasing_meteoroid_pos[0][idx] + _get_ufo_alignment(y_pos)
                    return self.jr.render_at_clipped(r, x_pos, y_pos, meteoroid_mask)

                return jax.lax.cond(is_active, draw, lambda r: r, r_in)

            new_raster = jax.lax.cond(
                explosion_frame > 0,
                render_explosion,
                render_meteoroid,
                raster,
            )
            return new_raster, None

        raster, _ = jax.lax.scan(body_fun, raster, jnp.arange(self.consts.CHASING_METEOROID_MAX))
        return raster

    def _render_mothership(self, raster, state):
        stage = state.level.mothership_stage
        timer = state.level.mothership_timer
        pos_x = state.level.mothership_position
        
        mask = self.SHAPE_MASKS["mothership"]

        def render_none(r):
            return r

        def render_clipping(r, num_lines):
            # Clip the mask to only show top num_lines
            h, w = mask.shape
            y_indices = jnp.arange(h)[:, None]
            # Scale num_lines to match the current mask height
            active_rows = y_indices * self.consts.MOTHERSHIP_HEIGHT < num_lines * h
            effective_mask = jnp.where(active_rows, mask, self.jr.TRANSPARENT_ID)
            y = self.consts.MOTHERSHIP_EMERGE_Y - num_lines
            return self.jr.render_at_clipped(r, pos_x, y, effective_mask)

        def render_emergence(r):
            num_lines = jnp.clip(timer // 2, 0, self.consts.MOTHERSHIP_HEIGHT)
            return jax.lax.cond(num_lines > 0, 
                               lambda r_: render_clipping(r_, num_lines),
                               lambda r_: r_, r)

        def render_moving(r):
            return self.jr.render_at_clipped(r, pos_x, self.consts.MOTHERSHIP_EMERGE_Y - self.consts.MOTHERSHIP_HEIGHT, mask)

        def render_descending(r):
            s = jnp.clip(6 - (timer - 1) // 2, 0, 6)
            num_lines = s + 1
            return render_clipping(r, num_lines)

        def render_exploding(r):
            explosion_masks = self.SHAPE_MASKS["mothership_explosion"]
            step_duration = self.consts.MOTHERSHIP_EXPLOSION_STEP_DURATION
            step_idx = timer // step_duration
            step_idx = jnp.clip(step_idx, 0, 8)
            sprite_idx = self._mothership_explosion_seq[step_idx]
            exp_mask = explosion_masks[sprite_idx]
            y = self.consts.MOTHERSHIP_EMERGE_Y - self.consts.MOTHERSHIP_HEIGHT
            return self.jr.render_at_clipped(r, pos_x, y, exp_mask)

        return jax.lax.switch(
            stage.astype(jnp.int32),
            [render_none, render_emergence, render_moving, render_descending, render_none, render_exploding],
            raster
        )

    def _get_enemy_explosion_visuals(self, frame: chex.Array) -> Tuple[chex.Array, chex.Array]:
        clamped = jnp.clip(frame - 1, 0, self._enemy_explosion_sprite_seq.shape[0] - 1)
        sprite_idx = self._enemy_explosion_sprite_seq[clamped]
        y_offset = self._enemy_explosion_y_offsets[clamped]
        return sprite_idx, y_offset
